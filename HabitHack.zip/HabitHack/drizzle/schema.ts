import { sqliteTable, text, integer, primaryKey } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const taskGroups = sqliteTable("task_groups", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  color: text("color").notNull(),
});

export const insertTaskGroupSchema = createInsertSchema(taskGroups).pick({
  userId: true,
  name: true,
  color: true,
});

export const tasks = sqliteTable("tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id),
  groupId: integer("group_id").references(() => taskGroups.id),
  title: text("title").notNull(),
  isCompleted: integer("is_completed", { mode: "boolean" }).default(false),
  isRecurring: integer("is_recurring", { mode: "boolean" }).default(false),
  date: text("date").notNull(), // YYYY-MM-DD format
  estimatedTime: integer("estimated_time"), // in minutes
  actualTime: integer("actual_time"), // in minutes
  startTime: text("start_time"), // HH:MM format
  endTime: text("end_time"), // HH:MM format
  reflection: text("reflection"),
  recurrencePattern: text("recurrence_pattern"), // JSON string for RecurrencePattern
  parentTaskId: text("parent_task_id"),
  rewardId: text("reward_id"),
  order: integer("order"),
  completedAt: text("completed_at"),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  userId: true,
  groupId: true,
  title: true,
  isCompleted: true,
  isRecurring: true,
  date: true,
  estimatedTime: true,
  actualTime: true,
  startTime: true,
  endTime: true,
  reflection: true,
  recurrencePattern: true,
  parentTaskId: true,
  rewardId: true,
  order: true,
  completedAt: true,
});

export const rewards = sqliteTable("rewards", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  isPenalty: integer("is_penalty", { mode: "boolean" }).default(false),
  rarity: integer("rarity").default(1), // 1: normal, 2: rare, 3: super rare
  emoji: text("emoji"),
  usedInTask: integer("used_in_task", { mode: "boolean" }).default(false),
  originalRewardId: text("original_reward_id"),
});

export const insertRewardSchema = createInsertSchema(rewards).pick({
  userId: true,
  title: true,
  description: true,
  isPenalty: true,
  rarity: true,
  emoji: true,
  usedInTask: true,
  originalRewardId: true,
});

export const achievements = sqliteTable("achievements", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  isUnlocked: integer("is_unlocked", { mode: "boolean" }).default(false),
  unlockedAt: text("unlocked_at"),
  icon: text("icon"),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  userId: true,
  title: true,
  description: true,
  isUnlocked: true,
  unlockedAt: true,
  icon: true,
});

export const gachaHistory = sqliteTable("gacha_history", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id),
  rewardId: text("reward_id"),
  date: text("date").notNull(), // YYYY-MM-DD format
  weekCompletionRate: integer("week_completion_rate"), // percentage
  usedInTask: integer("used_in_task", { mode: "boolean" }).default(false),
});

export const insertGachaHistorySchema = createInsertSchema(gachaHistory).pick({
  userId: true,
  rewardId: true,
  date: true,
  weekCompletionRate: true,
  usedInTask: true,
});

export const userStats = sqliteTable("user_stats", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id).unique(),
  streak: integer("streak").default(0),
  gachaThreshold: integer("gacha_threshold").default(80), // percentage
  weeklyData: text("weekly_data"), // JSON string for weekly data
  gachaDay: integer("gacha_day").default(0), // 0=日曜, 1=月曜, ... 6=土曜
  lastGachaDayChange: text("last_gacha_day_change"), // YYYY-MM-DD format
  showGachaDayChangeWarning: integer("show_gacha_day_change_warning", { mode: "boolean" }).default(true),
  lastThresholdChange: text("last_threshold_change"), // YYYY-MM-DD format
  showThresholdChangeWarning: integer("show_threshold_change_warning", { mode: "boolean" }).default(true),
  gachaCount: integer("gacha_count").default(0),
  maxGachaCount: integer("max_gacha_count").default(1),
  lastGachaCountChange: text("last_gacha_count_change"), // YYYY-MM-DD format
  showGachaCountChangeWarning: integer("show_gacha_count_change_warning", { mode: "boolean" }).default(true),
  gachaMode: text("gacha_mode").default("fixed"), // 'fixed' | 'random'
  lastGachaModeChange: text("last_gacha_mode_change"), // YYYY-MM-DD format
  showGachaModeChangeWarning: integer("show_gacha_mode_change_warning", { mode: "boolean" }).default(true),
  maxDiceValue: integer("max_dice_value").default(6),
  hasDiceRolled: integer("has_dice_rolled", { mode: "boolean" }).default(false),
  lastDiceRoll: text("last_dice_roll"), // YYYY-MM-DD format
});

export const insertUserStatsSchema = createInsertSchema(userStats).pick({
  userId: true,
  streak: true,
  gachaThreshold: true,
  weeklyData: true,
  gachaDay: true,
  lastGachaDayChange: true,
  showGachaDayChangeWarning: true,
  lastThresholdChange: true,
  showThresholdChangeWarning: true,
  gachaCount: true,
  maxGachaCount: true,
  lastGachaCountChange: true,
  showGachaCountChangeWarning: true,
  gachaMode: true,
  lastGachaModeChange: true,
  showGachaModeChangeWarning: true,
  maxDiceValue: true,
  hasDiceRolled: true,
  lastDiceRoll: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type TaskGroup = typeof taskGroups.$inferSelect;
export type InsertTaskGroup = z.infer<typeof insertTaskGroupSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type GachaHistory = typeof gachaHistory.$inferSelect;
export type InsertGachaHistory = z.infer<typeof insertGachaHistorySchema>;

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;

// Client-side schema
export type RecurrencePattern = {
  type: 'daily' | 'weekly' | 'monthly';
  interval: number; // 毎日=1, 2日ごと=2など
  weekdays?: number[]; // 週次の場合、曜日を指定 (0=日曜, 1=月曜, ...)
  endDate?: string; // 終了日（任意）YYYY-MM-DD形式
  occurrences?: number; // 繰り返し回数（任意）
};

export type TaskLocal = {
  id: string;
  groupId: string | null;
  title: string;
  isCompleted: boolean;
  isRecurring: boolean;
  date: string;
  estimatedTime?: number;
  actualTime?: number;
  startTime?: string;
  endTime?: string;
  reflection?: string;
  recurrencePattern?: RecurrencePattern; // 周期タスクの場合の詳細設定
  parentTaskId?: string; // 親タスクのID（周期タスクから生成されたタスクの場合）
  rewardId?: string; // タスクに関連付けられた報酬・罰ゲームのID
  order?: number; // タスクの表示順序
  completedAt?: string; // タスクが完了した時刻（ISO文字列形式）
};

export type TaskGroupLocal = {
  id: string;
  name: string;
  color: string;
};

export type RewardLocal = {
  id: string;
  title: string;
  description?: string;
  isPenalty: boolean;
  rarity: number;
  emoji?: string;
  usedInTask?: boolean; // タスクに使用されたかどうか
  originalRewardId?: string; // 元のrewardIdを保持（ガチャ履歴からのインスタンス生成時）
};

export type GachaHistoryLocal = {
  id: string;
  rewardId: string;
  date: string;
  weekCompletionRate: number;
  usedInTask?: boolean; // タスクに使用されたかどうか
};

export type UserStatsLocal = {
  streak: number;
  gachaThreshold: number;
  weeklyData: {
    date: string;
    completionRate: number;
  }[];
  gachaDay: number; // 0=日曜, 1=月曜, ... 6=土曜
  lastGachaDayChange?: string; // 最後にガチャ曜日を変更した日（形式: YYYY-MM-DD）
  showGachaDayChangeWarning: boolean; // ガチャ曜日変更時に確認を表示するかどうか
  lastThresholdChange?: string; // 最後にガチャ閾値（達成基準）を変更した日（形式: YYYY-MM-DD）
  showThresholdChangeWarning: boolean; // ガチャ閾値変更時に確認を表示するかどうか
  gachaCount: number; // 現在のガチャ残り回数
  maxGachaCount: number; // 週に獲得できる最大ガチャ回数（設定値）
  lastGachaCountChange?: string; // 最後にガチャ回数を変更した日（形式: YYYY-MM-DD）
  showGachaCountChangeWarning: boolean; // ガチャ回数変更時に確認を表示するかどうか
  gachaMode: 'fixed' | 'random'; // ガチャモード: 固定値またはランダム
  lastGachaModeChange?: string; // 最後にガチャモードを変更した日（形式: YYYY-MM-DD）
  showGachaModeChangeWarning: boolean; // ガチャモード変更時に確認を表示するかどうか
  maxDiceValue: number; // サイコロの最大値（ランダムモード用）
  hasDiceRolled: boolean; // 今週サイコロを振ったかどうか（ランダムモード用）
  lastDiceRoll?: string; // 最後にサイコロを振った日（形式: YYYY-MM-DD）
};

export type AchievementLocal = {
  id: string;
  title: string;
  description?: string;
  isUnlocked: boolean;
  unlockedAt?: string;
  icon?: string;
};