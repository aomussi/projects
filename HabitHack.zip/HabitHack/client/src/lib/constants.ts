import { TaskGroupLocal, RewardLocal } from "@shared/schema";

export const DEFAULT_TASK_GROUPS: TaskGroupLocal[] = [
  { id: "1", name: "仕事", color: "#3B82F6" },  // blue-500
  { id: "2", name: "学習", color: "#8B5CF6" },  // violet-500
  { id: "3", name: "家事", color: "#10B981" },  // emerald-500
  { id: "4", name: "趣味", color: "#EF4444" },  // red-500
];

export const DEFAULT_REWARDS: RewardLocal[] = [
  { id: "1", title: "映画鑑賞", description: "好きな映画を観る時間", isPenalty: false, rarity: 1, emoji: "🎬" },
  { id: "2", title: "ゲーム1時間", description: "好きなゲームを1時間プレイする", isPenalty: false, rarity: 1, emoji: "🎮" },
  { id: "3", title: "お菓子購入", description: "好きなお菓子を一つ買う", isPenalty: false, rarity: 1, emoji: "🍬" },
  { id: "4", title: "カフェでリラックス", description: "カフェでゆっくり過ごす", isPenalty: false, rarity: 2, emoji: "☕" },
  { id: "5", title: "本を購入", description: "読みたかった本を一冊買う", isPenalty: false, rarity: 2, emoji: "📚" },
  { id: "6", title: "特別なディナー", description: "ちょっといいレストランで食事", isPenalty: false, rarity: 3, emoji: "🍽️" },
  { id: "7", title: "掃除", description: "部屋の掃除をする", isPenalty: true, rarity: 1, emoji: "🧹" },
  { id: "8", title: "早起き", description: "明日は30分早く起きる", isPenalty: true, rarity: 1, emoji: "⏰" },
  { id: "9", title: "SNS禁止", description: "24時間SNSの使用禁止", isPenalty: true, rarity: 2, emoji: "📵" },
];

export const DEFAULT_ACHIEVEMENTS = [
  { 
    id: "1", 
    title: "始めの一歩", 
    description: "最初のタスクを完了",
    isUnlocked: false,
    icon: "👣"
  },
  { 
    id: "2", 
    title: "継続は力なり", 
    description: "3日連続でタスクを完了",
    isUnlocked: false,
    icon: "🔄"
  },
  { 
    id: "3", 
    title: "時間管理の達人", 
    description: "タイマーを使って10個のタスクを完了",
    isUnlocked: false,
    icon: "⏱️"
  },
  { 
    id: "4", 
    title: "完璧な一日", 
    description: "1日のタスクを100%完了",
    isUnlocked: false,
    icon: "✨"
  },
  { 
    id: "5", 
    title: "整理整頓", 
    description: "すべてのタスクをグループに分類",
    isUnlocked: false,
    icon: "📋"
  },
  { 
    id: "6", 
    title: "ラッキーセブン", 
    description: "7日連続でタスクを完了",
    isUnlocked: false,
    icon: "🍀"
  },
  { 
    id: "7", 
    title: "達成王", 
    description: "週間ガチャで超レア報酬を獲得",
    isUnlocked: false,
    icon: "👑"
  },
];

export const colors = [
  { name: "青", value: "#3B82F6" },  // blue-500
  { name: "紫", value: "#8B5CF6" },  // violet-500
  { name: "緑", value: "#10B981" },  // emerald-500
  { name: "赤", value: "#EF4444" },  // red-500
  { name: "黄", value: "#F59E0B" },  // amber-500
  { name: "ピンク", value: "#EC4899" },  // pink-500
  { name: "オレンジ", value: "#F97316" },  // orange-500
  { name: "青緑", value: "#06B6D4" },  // cyan-500
];
