import { format, addDays, subDays, parse, isToday, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, getDay, addMonths, addWeeks, isAfter, isBefore, setDate, getDate, subWeeks } from 'date-fns';
import { ja } from 'date-fns/locale';

export function formatDate(date: Date): string {
  return format(date, 'yyyy年M月d日（EEE）', { locale: ja });
}

export function formatSimpleDate(date: Date): string {
  return format(date, 'yyyy-MM-dd');
}

export function formatYearMonth(date: Date): string {
  return format(date, 'yyyy年M月', { locale: ja });
}

export function parseDate(dateString: string): Date {
  return parse(dateString, 'yyyy-MM-dd', new Date());
}

export function getNextDay(dateString: string): string {
  const date = parseDate(dateString);
  return formatSimpleDate(addDays(date, 1));
}

export function getPreviousDay(dateString: string): string {
  const date = parseDate(dateString);
  return formatSimpleDate(subDays(date, 1));
}

export function getToday(): string {
  return formatSimpleDate(new Date());
}

export function isCurrentDay(dateString: string): boolean {
  const date = parseDate(dateString);
  return isToday(date);
}

export function getWeekdays(): string[] {
  return ['月', '火', '水', '木', '金', '土', '日'];
}

export function getCurrentWeekDates(date: Date): Date[] {
  const start = startOfWeek(date, { weekStartsOn: 1 }); // Start from Monday
  const end = endOfWeek(date, { weekStartsOn: 1 }); // End on Sunday
  
  return eachDayOfInterval({ start, end });
}

export function getWeekDaysForDates(dates: Date[]): string[] {
  return dates.map(date => format(date, 'EEE', { locale: ja }));
}

export function isSameDate(date1: string, date2: string): boolean {
  return isSameDay(parseDate(date1), parseDate(date2));
}

export function getDaysInMonth(year: number, month: number): Date[] {
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);
  
  return eachDayOfInterval({ start: startDate, end: endDate });
}

export function getCalendarDaysWithPadding(year: number, month: number): (Date | null)[] {
  const days = getDaysInMonth(year, month);
  const firstDayOfMonth = days[0];
  
  // Get the day of the week (0 = Sunday, 1 = Monday, etc.)
  let dayOfWeek = getDay(firstDayOfMonth);
  // Adjust for Monday as first day (0 = Monday, 6 = Sunday)
  dayOfWeek = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  
  const previousMonthPadding: null[] = Array(dayOfWeek).fill(null);
  
  // Calculate days needed for next month padding
  const totalDaysShown = Math.ceil((days.length + dayOfWeek) / 7) * 7;
  const nextMonthPaddingCount = totalDaysShown - days.length - dayOfWeek;
  const nextMonthPadding: null[] = Array(nextMonthPaddingCount).fill(null);
  
  return [...previousMonthPadding, ...days, ...nextMonthPadding];
}

export function getDayOfWeekIndex(date: Date): number {
  // Returns 0-6 index where 0 is Monday and 6 is Sunday
  const day = getDay(date);
  return day === 0 ? 6 : day - 1;
}

/**
 * 周期パターンに基づいて次の日付を計算
 */
export function getNextOccurrence(baseDate: Date, type: 'daily' | 'weekly' | 'monthly', interval: number, weekdays?: number[]): Date {
  let nextDate = new Date(baseDate);
  
  switch (type) {
    case 'daily':
      // 毎日または数日ごと
      nextDate = addDays(baseDate, interval);
      break;
      
    case 'weekly':
      // 毎週または数週ごと
      if (weekdays && weekdays.length > 0) {
        // 指定曜日で次の日を計算
        const currentDayOfWeek = getDay(baseDate); // 0=日曜, 1=月曜, ...
        
        // 今週の残りの曜日で次のものを探す
        const nextWeekday = weekdays.find(day => day > currentDayOfWeek);
        
        if (nextWeekday !== undefined) {
          // 今週の残りの曜日がある場合
          nextDate = addDays(baseDate, nextWeekday - currentDayOfWeek);
        } else {
          // 今週の残りの曜日がない場合、次の週へ
          const daysUntilFirstDay = 7 - currentDayOfWeek + weekdays[0];
          nextDate = addDays(baseDate, daysUntilFirstDay + (interval - 1) * 7);
        }
      } else {
        // 曜日指定がない場合、単純に週数を加算
        nextDate = addWeeks(baseDate, interval);
      }
      break;
      
    case 'monthly':
      // 毎月または数ヶ月ごと
      nextDate = addMonths(baseDate, interval);
      
      // 元の日付の日を保持
      const originalDay = getDate(baseDate);
      if (originalDay !== getDate(nextDate)) {
        // 月末調整（例：3/31 → 4/30）
        nextDate = setDate(nextDate, originalDay);
      }
      break;
  }
  
  return nextDate;
}

/**
 * ガチャ日を基準にした週間統計の日付範囲を取得する
 * @param referenceDate 基準日（通常は今日）
 * @param gachaDay ガチャ曜日（0=日曜、1=月曜...6=土曜）
 * @returns [開始日, 終了日] の配列。開始日は「前回のガチャ日の翌日」、終了日は「今回のガチャ日」
 */
export function getGachaWeekDateRange(referenceDate: Date, gachaDay: number): [Date, Date] {
  const currentDay = getDay(referenceDate); // 0=日曜、1=月曜...6=土曜

  // 今週のガチャ日の日付を計算
  let currentGachaDate: Date;
  
  if (currentDay === gachaDay) {
    // 今日がガチャ日の場合、今日が「今週のガチャ日」
    currentGachaDate = new Date(referenceDate);
  } else if (currentDay < gachaDay) {
    // 今週のガチャ日はまだ来ていない場合、今週の後ろの方にあるガチャ日
    const daysUntilGachaDay = gachaDay - currentDay;
    currentGachaDate = addDays(referenceDate, daysUntilGachaDay);
  } else {
    // 今週のガチャ日はすでに過ぎている場合、直近の過去のガチャ日
    const daysSinceGachaDay = currentDay - gachaDay;
    currentGachaDate = subDays(referenceDate, daysSinceGachaDay);
  }
  
  // 前回のガチャ日（現在のガチャ日から1週間前）
  const previousGachaDate = subWeeks(currentGachaDate, 1);
  
  // 集計期間の開始日（前回のガチャ日の翌日）
  const startDate = addDays(previousGachaDate, 1);
  
  // 集計期間の終了日（現在のガチャ日）
  const endDate = currentGachaDate;
  
  return [startDate, endDate];
}

/**
 * ガチャ日を基準にした週間の日付を配列で取得する
 * @param referenceDate 基準日（通常は今日）
 * @param gachaDay ガチャ曜日（0=日曜、1=月曜...6=土曜）
 * @returns 前回のガチャ日の翌日～今回のガチャ日までの日付配列
 */
export function getGachaWeekDates(referenceDate: Date, gachaDay: number): Date[] {
  const [startDate, endDate] = getGachaWeekDateRange(referenceDate, gachaDay);
  return eachDayOfInterval({ start: startDate, end: endDate });
}

/**
 * 周期パターンに基づいて指定日数分のタスク日付を生成
 */
export function generateRecurringDates(
  startDate: Date, 
  pattern: {
    type: 'daily' | 'weekly' | 'monthly';
    interval: number;
    weekdays?: number[];
    endDate?: string;
    occurrences?: number;
  }, 
  maxOccurrences: number = 10 // デフォルトは最大10個まで生成
): string[] {
  const result: string[] = [];
  let currentDate = new Date(startDate);
  let count = 0;
  
  // 終了日の設定
  const endDate = pattern.endDate ? parseDate(pattern.endDate) : null;
  // 繰り返し回数の設定（指定がなければmaxOccurrencesを使用）
  const totalOccurrences = pattern.occurrences || maxOccurrences;
  
  while (count < totalOccurrences) {
    // 最初の日付は含めない（既に作成済みのタスク）
    if (count > 0) {
      const dateStr = formatSimpleDate(currentDate);
      result.push(dateStr);
    }
    
    // 次の日付を計算
    currentDate = getNextOccurrence(currentDate, pattern.type, pattern.interval, pattern.weekdays);
    
    // 終了日のチェック
    if (endDate && isAfter(currentDate, endDate)) {
      break;
    }
    
    count++;
  }
  
  return result;
}
