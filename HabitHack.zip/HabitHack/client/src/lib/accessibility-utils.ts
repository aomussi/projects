/**
 * アクセシビリティ関連のユーティリティ関数を提供するモジュール
 */

/**
 * アクセシビリティ属性を追加するためのユーティリティ関数
 * 既存のpropsとa11y属性を適切にマージします
 * 
 * @param props 元のコンポーネントのprops
 * @param ariaProps 追加するaria属性
 * @returns マージされたprops
 */
export function withA11yProps<T extends Record<string, any>>(
  props: T,
  ariaProps: Record<string, string | undefined>
): T {
  // 元のpropsを優先し、存在しない場合のみariaPropsを使用
  const mergedProps = { ...ariaProps, ...props } as T;
  
  // undefined値を持つプロパティを削除
  Object.keys(mergedProps).forEach(key => {
    if (mergedProps[key] === undefined) {
      delete mergedProps[key];
    }
  });
  
  return mergedProps;
}

/**
 * アクセシビリティツリーから要素を隠す属性を追加
 * 視覚的に表示されているが、スクリーンリーダーでは無視すべき装飾的要素向け
 */
export const decorativeProps = {
  'aria-hidden': 'true',
  role: 'presentation',
};

/**
 * スクリーンリーダー専用テキスト用のクラス
 * 視覚的には非表示だが、スクリーンリーダーには読み上げられるテキスト用
 */
export const srOnlyClass = 'sr-only';

/**
 * スクリーンリーダー専用要素の作成
 * @param text スクリーンリーダーに読み上げられるテキスト
 * @returns JSX要素
 */
// 注意: このコンポーネントはTSXファイルでのみ使用可能
// .tsxファイルに移動する場合は以下のコメントを解除
/*
export function SrOnly({ text }: { text: string }) {
  return <span className={srOnlyClass}>{text}</span>;
}
*/