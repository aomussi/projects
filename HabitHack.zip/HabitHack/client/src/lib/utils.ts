import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
}

export function getCompletionRate(total: number, completed: number): number {
  if (total === 0) return 0;
  return Math.round((completed / total) * 100);
}

export function calculateWeeklyCompletionRate(dailyRates: number[]): number {
  if (dailyRates.length === 0) return 0;
  const sum = dailyRates.reduce((acc, rate) => acc + rate, 0);
  return Math.round(sum / dailyRates.length);
}

export function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// レア度に基づくガチャの選択は行わず、全てのレア度を対象にするためダミー関数化
export function getGachaRewardRarity(_completionRate: number): number {
  // 常に全てのレア度を対象とするため、固定値を返す
  // この関数は後続でのフィルタリングのために互換性維持のために残す
  return 0; // 0を返すことで後続のフィルタリングでは使用されなくなる
}

export function formatTime(minutes: number): string {
  if (minutes < 60) {
    return `${minutes}分`;
  }
  
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (mins === 0) {
    return `${hours}時間`;
  }
  
  return `${hours}時間${mins}分`;
}

export function formatTimeHHMM(date: Date): string {
  return date.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit', hour12: false });
}
