import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { TabBar } from '@/components/TabBar';
import { GachaModal } from '@/components/GachaModal';
import { GachaResultModal } from '@/components/GachaResultModal';
import { RewardDetailModal } from '../components/RewardDetailModal';
import { cn } from '@/lib/utils';
import { getToday } from '@/lib/dates';
import { useToast } from '@/hooks/use-toast';
import { RewardLocal } from '../../../shared/schema';

export default function Gacha() {
  const { toast } = useToast();
  const { 
    rewards, 
    gachaHistory, 
    canGachaThisWeek,
    daysUntilGacha,
    weeklyAverageCompletionRate,
    userStats,
    addGachaHistory,
    getCollectedRewards,
    rollDice,
    canRollDice,
    canRollDiceToday
  } = useAppContext();

  const [gachaModalOpen, setGachaModalOpen] = useState(false);
  const [resultModalOpen, setResultModalOpen] = useState(false);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [resultReward, setResultReward] = useState<RewardLocal | null>(null);
  const [detailReward, setDetailReward] = useState<RewardLocal | null>(null);

  // Get collected rewards (未使用のみ)
  const collectedRewards = getCollectedRewards();

  // Group rewards by type (reward vs penalty)
  const myRewards = collectedRewards.filter(reward => !reward.isPenalty);
  const myPenalties = collectedRewards.filter(reward => reward.isPenalty);

  // Handle clicking on a reward item
  const handleRewardClick = (reward: RewardLocal) => {
    setDetailReward(reward);
    setDetailModalOpen(true);
  };

  const handleGachaResult = (rewardId: string) => {
    const reward = rewards.find(r => r.id === rewardId);
    if (reward) {
      setResultReward(reward);
      setResultModalOpen(true);
    }

    // Record gacha history
    addGachaHistory({
      rewardId,
      date: getToday(),
      weekCompletionRate: weeklyAverageCompletionRate
    });
  };

  const getStatusMessage = () => {
    if (weeklyAverageCompletionRate >= userStats.gachaThreshold) {
      return "目標達成! ガチャを回して報酬をゲットしよう";
    } else {
      return `目標未達成... (目標: ${userStats.gachaThreshold}%)`;
    }
  };

  const getRewardRarityClass = (rarity: number) => {
    switch (rarity) {
      case 3:
        return "bg-purple-100 text-purple-800";
      case 2:
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-yellow-100 text-yellow-800";
    }
  };

  return (
    <div className="max-w-md mx-auto pb-24">
      <header className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="p-4">
          <h1 className="text-xl font-bold text-primary">ガチャ</h1>
        </div>
      </header>

      <div className="p-4">
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="text-center mb-4">
              <div className={cn(
                "inline-block p-4 rounded-full mb-3",
                weeklyAverageCompletionRate >= userStats.gachaThreshold
                  ? "bg-yellow-100"
                  : "bg-gray-100"
              )}>
                <span className="text-5xl">🎲</span>
              </div>
              <h2 className="text-xl font-bold">週間ガチャ</h2>
              <div className="text-sm text-gray-500 mb-2">今週の達成率: {weeklyAverageCompletionRate}%</div>
              <div className={cn(
                "inline-block px-3 py-1 rounded-full text-sm",
                weeklyAverageCompletionRate >= userStats.gachaThreshold
                  ? "bg-yellow-100 text-yellow-800"
                  : "bg-gray-100 text-gray-800"
              )}>
                {getStatusMessage()}
              </div>
            </div>

            {/* ランダムモードでサイコロを振れる場合はサイコロボタンを表示 */}
            {userStats.gachaMode === 'random' && canGachaThisWeek && canRollDiceToday && !userStats.hasDiceRolled && (
              <Button 
                className="w-full mb-2 bg-amber-500 hover:bg-amber-600"
                onClick={() => {
                  const result = rollDice();
                  toast({
                    title: `サイコロを振りました！出目: ${result}`,
                    description: `今週は${result}回ガチャを引くことができます`,
                  });
                }}
              >
                🎲 サイコロを振る
              </Button>
            )}
            
            <Button 
              className="w-full mb-2"
              onClick={() => setGachaModalOpen(true)}
              disabled={
                !canGachaThisWeek || 
                (userStats.gachaMode === 'random' && 
                 !userStats.hasDiceRolled && 
                 canRollDiceToday)
              }
            >
              {!canGachaThisWeek 
                ? `ガチャまであと${daysUntilGacha}日`
                : userStats.gachaMode === 'random' && !userStats.hasDiceRolled && canRollDiceToday
                  ? 'まずサイコロを振ってください'
                  : `ガチャを回す (残り${userStats.gachaCount}回)`
              }
            </Button>

            <div className="text-center text-sm text-gray-500 mb-1">
              目標達成率{userStats.gachaThreshold}%以上で報酬アイテム、未満で罰ゲームが出現します。
            </div>
            <div className="text-center text-xs text-blue-600 mb-1">
              各レア度の確率はアイテム数に応じて変動します。
            </div>
            
            {canGachaThisWeek && (
              <div className="text-center text-xs text-blue-600 font-medium">
                今週は残り{userStats.gachaCount}回ガチャを引けます
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">所持アイテム</CardTitle>
          </CardHeader>
          <CardContent>
            {collectedRewards.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className="text-4xl mb-2">🎁</div>
                <p>ガチャでアイテムを獲得しよう</p>
              </div>
            ) : (
              <div className="space-y-6">
                {myRewards.length > 0 && (
                  <div>
                    <h3 className="font-medium mb-2 text-green-600">報酬アイテム</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {myRewards.map(reward => (
                        <div 
                          key={reward.id} 
                          className="bg-gray-50 p-3 rounded-lg cursor-pointer hover:bg-gray-100"
                          onClick={() => handleRewardClick(reward)}
                        >
                          <div className="flex items-center mb-1">
                            <span className="text-2xl mr-2">{reward.emoji || "🎁"}</span>
                            <div className={cn(
                              "text-xs px-1 py-0.5 rounded",
                              getRewardRarityClass(reward.rarity)
                            )}>
                              {reward.rarity === 3 ? "超レア" : reward.rarity === 2 ? "レア" : "通常"}
                            </div>
                          </div>
                          <div className="font-medium">{reward.title}</div>
                          {reward.description && (
                            <div className="text-xs text-gray-500 mt-1">{reward.description}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {myPenalties.length > 0 && (
                  <div>
                    <h3 className="font-medium mb-2 text-red-600">罰ゲーム</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {myPenalties.map(penalty => (
                        <div 
                          key={penalty.id} 
                          className="bg-gray-50 p-3 rounded-lg cursor-pointer hover:bg-gray-100"
                          onClick={() => handleRewardClick(penalty)}
                        >
                          <div className="flex items-center mb-1">
                            <span className="text-2xl mr-2">{penalty.emoji || "⚠️"}</span>
                            <div className="text-xs px-1 py-0.5 rounded bg-red-100 text-red-800">
                              罰ゲーム
                            </div>
                          </div>
                          <div className="font-medium">{penalty.title}</div>
                          {penalty.description && (
                            <div className="text-xs text-gray-500 mt-1">{penalty.description}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <GachaModal 
        open={gachaModalOpen}
        onOpenChange={setGachaModalOpen}
        onResult={handleGachaResult}
      />

      {resultReward && (
        <GachaResultModal
          open={resultModalOpen}
          onOpenChange={setResultModalOpen}
          reward={resultReward}
          onSkip={() => {
            // 結果モーダルを閉じる
            setResultModalOpen(false);
            
            // 残りガチャ回数がある場合のみガチャモーダルを再度開く
            if (userStats.gachaCount > 0) {
              setGachaModalOpen(true);
            }
          }}
        />
      )}

      {detailReward && (
        <RewardDetailModal 
          open={detailModalOpen}
          onOpenChange={setDetailModalOpen}
          reward={detailReward}
        />
      )}

      <TabBar />
    </div>
  );
}