import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useAppContext } from '@/context/app-context';
import { TabBar } from '@/components/tab-bar';
import { BarChart, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar, Line, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { getWeekdays, getCurrentWeekDates, formatSimpleDate, formatDate } from '@/lib/dates';
import { formatTime, formatTimeHHMM } from '@/lib/utils';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Clock, Info, CalendarClock, Trash2, Edit, Check, X } from 'lucide-react';

export default function Statistics() {
  const { 
    tasks,
    weeklyData,
    taskGroups,
    userStats,
    getUnlockedAchievements,
    updateTask
  } = useAppContext();
  
  const [activeTab, setActiveTab] = useState('weekly');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editingComment, setEditingComment] = useState('');

  // コメント編集関数
  const startEditComment = (taskId: string, currentComment: string) => {
    setEditingTaskId(taskId);
    setEditingComment(currentComment || '');
  };

  const saveComment = (taskId: string) => {
    updateTask(taskId, { reflection: editingComment });
    setEditingTaskId(null);
    setEditingComment('');
  };

  const cancelEdit = () => {
    setEditingTaskId(null);
    setEditingComment('');
  };
  
  // Get completed tasks
  const completedTasks = tasks.filter(task => task.isCompleted);
  const totalTasksCount = tasks.length;
  const completedTasksCount = completedTasks.length;
  const overallCompletionRate = totalTasksCount > 0 
    ? Math.round((completedTasksCount / totalTasksCount) * 100) 
    : 0;
  
  // Get current week data
  const currentWeekDates = getCurrentWeekDates(new Date());
  const weekDays = getWeekdays();
  
  // Prepare data for weekly chart
  const weeklyChartData = weekDays.map((day, index) => {
    const dateStr = formatSimpleDate(currentWeekDates[index]);
    const dayData = weeklyData.find(data => data.date === dateStr);
    return {
      day,
      completionRate: dayData?.completionRate || 0
    };
  });
  
  // Prepare data for group distribution chart
  const groupTaskCounts = taskGroups.map(group => {
    const count = tasks.filter(task => task.groupId === group.id).length;
    return {
      name: group.name,
      value: count,
      color: group.color
    };
  });
  
  // Filter out groups with no tasks
  const filteredGroupData = groupTaskCounts.filter(group => group.value > 0);
  
  // Get unlocked achievements
  const unlockedAchievements = getUnlockedAchievements();
  const achievementProgress = Math.round((unlockedAchievements.length / 7) * 100);
  
  return (
    <div className="max-w-md mx-auto pb-24">
      <header className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="p-4">
          <h1 className="text-xl font-bold text-primary">統計</h1>
        </div>
      </header>
      
      <div className="p-4">
        <Tabs defaultValue="weekly" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="weekly">週間</TabsTrigger>
            <TabsTrigger value="tasks">タスク</TabsTrigger>
            <TabsTrigger value="history">履歴</TabsTrigger>
            <TabsTrigger value="achievements">実績</TabsTrigger>
          </TabsList>
          
          <TabsContent value="weekly" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">週間達成率</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar 
                        dataKey="completionRate" 
                        name="達成率" 
                        fill="hsl(var(--chart-1))" 
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>平均達成率</span>
                    <span className="font-medium">{userStats.streak} 日連続達成中</span>
                  </div>
                  <Progress value={overallCompletionRate} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="tasks" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">タスク分析</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-100 p-3 rounded-lg text-center">
                    <div className="text-3xl font-bold text-primary">{completedTasksCount}</div>
                    <div className="text-sm text-gray-500">完了タスク</div>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg text-center">
                    <div className="text-3xl font-bold text-primary">{overallCompletionRate}%</div>
                    <div className="text-sm text-gray-500">全体達成率</div>
                  </div>
                </div>
                
                <h3 className="font-medium mb-2">グループ別分布</h3>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={filteredGroupData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {filteredGroupData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="history" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">タスク履歴</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* 完了タスク一覧を完了時刻の降順で表示（最新のものが上に来るように） */}
                  {[...completedTasks]
                    .sort((a, b) => {
                      // 完了時刻がある場合はそれを使用して降順ソート
                      if (a.completedAt && b.completedAt) {
                        return new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime();
                      }
                      // 片方しか完了時刻がない場合は、完了時刻のあるものを優先
                      if (a.completedAt) return -1;
                      if (b.completedAt) return 1;
                      // どちらも完了時刻がない場合（古いデータ）は配列内の順序を反転（最新のタスクが最初に追加されるため）
                      return -1;
                    })
                    .map((task) => {
                      // タスクグループ情報
                      const taskGroup = task.groupId 
                        ? taskGroups.find(group => group.id === task.groupId) 
                        : null;
                        
                      // 報酬タスクかどうか
                      const isRewardTask = !!task.rewardId;
                      
                      return (
                        <div key={task.id} className="bg-gray-50 p-3 rounded-lg shadow-sm border-l-4 border-green-500">
                          <div className="flex justify-between items-start">
                            <div className="font-medium">{task.title}</div>
                            <div className="flex flex-col items-end gap-1">
                              <Badge variant="outline" className="text-xs">
                                {formatDate(new Date(task.date))}
                              </Badge>
                              {task.completedAt && (
                                <div className="text-xs text-gray-500">
                                  完了: {formatDate(new Date(task.completedAt))} {formatTimeHHMM(new Date(task.completedAt))}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-2 mt-2">
                            {/* タスクグループ */}
                            {taskGroup && (
                              <Badge variant="secondary" className="text-xs">
                                {taskGroup.name}
                              </Badge>
                            )}
                            
                            {/* 周期タスク */}
                            {task.isRecurring && (
                              <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800 hover:bg-blue-100">
                                周期タスク
                              </Badge>
                            )}
                            
                            {/* 報酬タスク */}
                            {isRewardTask && (
                              <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-800 hover:bg-amber-100">
                                報酬タスク
                              </Badge>
                            )}
                          </div>
                          
                          {/* 実行時間情報 */}
                          {(task.actualTime || task.estimatedTime) && (
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                              {task.actualTime && (
                                <div className="flex items-center">
                                  <Clock className="h-3 w-3 mr-1" />
                                  <span>実行: {formatTime(task.actualTime)}</span>
                                </div>
                              )}
                              
                              {task.estimatedTime && (
                                <div className="flex items-center">
                                  <CalendarClock className="h-3 w-3 mr-1" />
                                  <span>予定: {formatTime(task.estimatedTime)}</span>
                                </div>
                              )}
                            </div>
                          )}
                          
                          {/* 振り返りコメント */}
                          <div className="mt-2">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center text-blue-600">
                                <Info className="h-3 w-3 mr-1" />
                                <span className="text-sm font-medium">振り返り</span>
                              </div>
                              {editingTaskId !== task.id && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 px-2 text-xs"
                                  onClick={() => startEditComment(task.id, task.reflection || '')}
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  編集
                                </Button>
                              )}
                            </div>
                            
                            {editingTaskId === task.id ? (
                              <div className="space-y-2">
                                <Textarea
                                  value={editingComment}
                                  onChange={(e) => setEditingComment(e.target.value)}
                                  placeholder="タスクの振り返りを記入してください..."
                                  className="min-h-[60px] text-sm"
                                />
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() => saveComment(task.id)}
                                    className="h-7 px-3 text-xs"
                                  >
                                    <Check className="h-3 w-3 mr-1" />
                                    保存
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={cancelEdit}
                                    className="h-7 px-3 text-xs"
                                  >
                                    <X className="h-3 w-3 mr-1" />
                                    キャンセル
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div className="p-2 bg-white rounded border-l-2 border-blue-400 text-sm">
                                {task.reflection ? (
                                  <p className="text-gray-700">{task.reflection}</p>
                                ) : (
                                  <p className="text-gray-400 italic">振り返りコメントはありません</p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })
                  }
                  
                  {/* 完了タスクがない場合 */}
                  {completedTasks.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <div className="text-4xl mb-2">📝</div>
                      <p>完了したタスクはありません</p>
                      <p className="text-sm">タスクを完了すると、ここに履歴が表示されます</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="achievements" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">実績</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>獲得実績</span>
                    <span>{unlockedAchievements.length}/7</span>
                  </div>
                  <Progress value={achievementProgress} className="h-2" />
                </div>
                
                <div className="space-y-3">
                  {unlockedAchievements.map(achievement => (
                    <div key={achievement.id} className="bg-gray-100 p-3 rounded-lg flex items-center">
                      <div className="text-2xl mr-3">{achievement.icon}</div>
                      <div>
                        <div className="font-medium">{achievement.title}</div>
                        <div className="text-xs text-gray-500">{achievement.description}</div>
                      </div>
                    </div>
                  ))}
                  
                  {unlockedAchievements.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <div className="text-4xl mb-2">🏆</div>
                      <p>まだ実績がありません</p>
                      <p className="text-sm">タスクを完了して実績を獲得しましょう</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <TabBar />
    </div>
  );
}
