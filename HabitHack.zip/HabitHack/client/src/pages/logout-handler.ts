import { useAuth } from "@/hooks/use-auth";

// この関数は動的importを通じて呼び出されます
export function handleLogout() {
  try {
    // 直接API呼び出しでログアウト（フックが使えない場合のフォールバック）
    fetch('/api/logout', {
      method: 'POST',
      credentials: 'include'
    })
    .then(() => {
      console.log('ログアウト成功');
      // リダイレクト
      window.location.href = '/auth';
    })
    .catch(err => {
      console.error('ログアウト失敗', err);
    });
  } catch (error) {
    console.error('ログアウト処理エラー:', error);
  }
}