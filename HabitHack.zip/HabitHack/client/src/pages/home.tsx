import React, { useState } from 'react';
import { useAppContext } from '@/context/app-context';
import { DailyProgress } from '../components/DailyProgress';
import { TaskInput } from '../components/TaskInput';
import { TaskList } from '../components/TaskList';
import { WeeklyProgress } from '../components/WeeklyProgress';
import { TabBar } from '../components/TabBar';
import { Button } from '@/components/ui/button';
import { CalendarModal } from '../components/CalendarModal';
import { ChevronLeft, ChevronRight, Calendar, BarChart2, Settings } from 'lucide-react';
import { formatDate, getNextDay, getPreviousDay, getToday } from '@/lib/dates';

export default function Home() {
  const { currentDate, setCurrentDate } = useAppContext();
  const [calendarOpen, setCalendarOpen] = useState(false);
  
  // Handle date navigation
  const goToNextDay = () => {
    setCurrentDate(getNextDay(currentDate));
  };
  
  const goToPreviousDay = () => {
    setCurrentDate(getPreviousDay(currentDate));
  };
  
  const goToToday = () => {
    setCurrentDate(getToday());
  };
  
  // Format the current date for display
  let formattedDate = '';
  try {
    // 日付形式の文字列（yyyy-MM-dd）ならparseしてフォーマット
    if (currentDate && typeof currentDate === 'string' && currentDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
      formattedDate = formatDate(new Date(currentDate));
    } else {
      // 問題がある場合、今日の日付を表示
      formattedDate = formatDate(new Date());
    }
  } catch (error) {
    console.error('日付のフォーマットエラー:', error);
    formattedDate = formatDate(new Date());
  }
  
  return (
    <div className="max-w-md mx-auto pb-24">
      {/* Header */}
      <header className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="p-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-primary">タスク管理</h1>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCalendarOpen(true)}
              aria-label="カレンダー表示"
            >
              <Calendar className="h-5 w-5 text-gray-600" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={goToToday}
              aria-label="今日"
              className="text-xs"
            >
              今日
            </Button>
          </div>
        </div>
        
        {/* Date Navigation */}
        <div className="px-4 pb-2 flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            onClick={goToPreviousDay}
            className="text-gray-500"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <div className="font-medium">{formattedDate}</div>
          <Button
            variant="ghost"
            size="icon"
            onClick={goToNextDay}
            className="text-gray-500"
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="p-4">
        {/* Daily Progress */}
        <DailyProgress />
        
        {/* Task Input */}
        <TaskInput />
        
        {/* Task List */}
        <TaskList />
        
        {/* Weekly Progress */}
        <WeeklyProgress />
      </div>
      
      {/* Calendar Modal */}
      <CalendarModal open={calendarOpen} onOpenChange={setCalendarOpen} />
      
      {/* Tab Bar */}
      <TabBar />
    </div>
  );
}
