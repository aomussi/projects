import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { Redirect } from "wouter";

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("login");
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  });
  const [registerData, setRegisterData] = useState({
    username: "",
    password: "",
    confirmPassword: "",
  });

  // ユーザーが既にログインしている場合はホームページにリダイレクト
  console.log('Auth page - User state:', user ? 'Logged in' : 'Not logged in');
  if (user) {
    console.log('Redirecting to home page');
    return <Redirect to="/" />;
  }

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(loginData);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (registerData.password !== registerData.confirmPassword) {
      alert("パスワードが一致しません");
      return;
    }
    
    registerMutation.mutate({
      username: registerData.username,
      password: registerData.password,
    });
  };

  return (
    <div className="flex min-h-screen">
      <div className="w-full lg:w-1/2 p-8 flex items-center justify-center">
        <div className="w-full max-w-md border border-gray-200 rounded-lg shadow-sm overflow-hidden">
          <div className="tabs-container">
            <div className="tab-list w-full grid grid-cols-2 border-b border-gray-200">
              <button 
                className={`py-3 px-4 font-medium text-center ${activeTab === 'login' ? 'bg-white text-blue-600 border-b-2 border-blue-600' : 'bg-gray-50 text-gray-700'}`} 
                onClick={() => setActiveTab('login')}
              >
                ログイン
              </button>
              <button 
                className={`py-3 px-4 font-medium text-center ${activeTab === 'register' ? 'bg-white text-blue-600 border-b-2 border-blue-600' : 'bg-gray-50 text-gray-700'}`} 
                onClick={() => setActiveTab('register')}
              >
                新規登録
              </button>
            </div>
            
            {/* ログインコンテンツ */}
            {activeTab === 'login' && (
              <div className="p-4">
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-2">ログイン</h2>
                  <p className="text-sm text-gray-500">
                    アカウント情報を入力してログインしてください
                  </p>
                </div>
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-username">ユーザー名</Label>
                    <Input
                      id="login-username"
                      type="text"
                      placeholder="username"
                      required
                      value={loginData.username}
                      onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="login-password">パスワード</Label>
                    <Input
                      id="login-password"
                      type="password"
                      required
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full mt-4" 
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "ログイン中..." : "ログイン"}
                  </Button>
                </form>
              </div>
            )}
            
            {/* 新規登録コンテンツ */}
            {activeTab === 'register' && (
              <div className="p-4">
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-2">新規登録</h2>
                  <p className="text-sm text-gray-500">
                    新しいアカウントを作成してはじめましょう
                  </p>
                </div>
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-username">ユーザー名</Label>
                    <Input
                      id="register-username"
                      type="text"
                      placeholder="username"
                      required
                      value={registerData.username}
                      onChange={(e) => setRegisterData({ ...registerData, username: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-password">パスワード</Label>
                    <Input
                      id="register-password"
                      type="password"
                      required
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-confirm-password">パスワード（確認）</Label>
                    <Input
                      id="register-confirm-password"
                      type="password"
                      required
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full mt-4" 
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "登録中..." : "登録する"}
                  </Button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-r from-blue-400 to-indigo-600 p-12 flex-col justify-center">
        <div className="max-w-xl mx-auto text-white">
          <h1 className="text-4xl font-bold mb-6">タスク管理とガチャシステムでモチベーションアップ！</h1>
          <p className="text-xl mb-8">
            タスクの達成率に応じてガチャを回し、報酬やペナルティを得る新しいタスク管理アプリです。
            日常のタスクをゲーム感覚で楽しく管理しましょう。
          </p>
          <ul className="space-y-2 text-lg">
            <li>✓ タスク達成でガチャを獲得</li>
            <li>✓ 進捗状況をグラフで可視化</li>
            <li>✓ タスクの繰り返し設定が可能</li>
            <li>✓ タイマー機能付き</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
