import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useAppContext } from '@/context/app-context';
import { TabBar } from '@/components/tab-bar';
import { Checkbox } from '@/components/ui/checkbox';
import { useLocation } from 'wouter';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter, 
  DialogClose,
  DialogDescription
} from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { colors } from '@/lib/constants';
import { X, Plus, Trash2, Edit, Save } from 'lucide-react';

export default function Settings() {
  const { 
    userStats,
    updateUserStats,
    taskGroups,
    addTaskGroup,
    updateTaskGroup,
    deleteTaskGroup,
    rewards,
    addReward,
    updateReward,
    deleteReward,
    gachaDay,
    changeGachaDay,
    canChangeGachaDay,
    changeThreshold,
    canChangeThreshold,
    changeGachaCount,
    canChangeGachaCount,
    changeGachaMode,
    canChangeGachaMode,
    changeDiceValue,
    canRollDice,
    canRollDiceToday,
    rollDice,
    resetAllData,
  } = useAppContext();
  
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Gacha day change confirmation state
  const [gachaDayChangeDialogOpen, setGachaDayChangeDialogOpen] = useState(false);
  const [selectedGachaDay, setSelectedGachaDay] = useState<number | null>(null);
  const [hideGachaDayChangeWarning, setHideGachaDayChangeWarning] = useState(false);
  
  // Gacha threshold change confirmation state
  const [thresholdChangeDialogOpen, setThresholdChangeDialogOpen] = useState(false);
  const [thresholdModalOpen, setThresholdModalOpen] = useState(false);
  const [selectedThreshold, setSelectedThreshold] = useState<number | null>(null);
  const [tempThreshold, setTempThreshold] = useState(userStats.gachaThreshold);
  const [hideThresholdChangeWarning, setHideThresholdChangeWarning] = useState(false);
  
  // Gacha count change confirmation state
  const [gachaCountChangeDialogOpen, setGachaCountChangeDialogOpen] = useState(false);
  const [gachaCountModalOpen, setGachaCountModalOpen] = useState(false);
  const [selectedGachaCount, setSelectedGachaCount] = useState<number | null>(null);
  
  // ダイスに関する状態
  const [tempDiceValue, setTempDiceValue] = useState(userStats.maxDiceValue);
  const [diceValueModalOpen, setDiceValueModalOpen] = useState(false);
  const [diceRolling, setDiceRolling] = useState(false);
  const [rolledValue, setRolledValue] = useState<number | null>(null);
  
  // ガチャモード変更に関する状態
  const [selectedGachaMode, setSelectedGachaMode] = useState<'fixed' | 'random' | null>(null);
  const [gachaModeChangeDialogOpen, setGachaModeChangeDialogOpen] = useState(false);
  const [hideGachaModeChangeWarning, setHideGachaModeChangeWarning] = useState(!userStats.showGachaModeChangeWarning);
  const [tempGachaCount, setTempGachaCount] = useState(userStats.maxGachaCount);
  const [hideGachaCountChangeWarning, setHideGachaCountChangeWarning] = useState(false);
  
  // Reset confirmation state
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  
  // Group management state
  const [groupModalOpen, setGroupModalOpen] = useState(false);
  const [groupFormMode, setGroupFormMode] = useState<'add' | 'edit'>('add');
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [groupName, setGroupName] = useState('');
  const [groupColor, setGroupColor] = useState(colors[0].value);
  
  // Reward management state
  const [rewardModalOpen, setRewardModalOpen] = useState(false);
  const [rewardFormMode, setRewardFormMode] = useState<'add' | 'edit'>('add');
  const [editingRewardId, setEditingRewardId] = useState<string | null>(null);
  const [rewardTitle, setRewardTitle] = useState('');
  const [rewardDescription, setRewardDescription] = useState('');
  const [rewardEmoji, setRewardEmoji] = useState('🎁');
  const [rewardRarity, setRewardRarity] = useState(1);
  const [isPenalty, setIsPenalty] = useState(false);
  
  // Handle threshold change
  const handleThresholdChange = (value: number[]) => {
    const newThreshold = value[0];
    
    // 同じ値を選択した場合、何もしない
    if (newThreshold === userStats.gachaThreshold) return;
    
    // 変更できない場合はエラーメッセージ
    if (!canChangeThreshold) {
      toast({
        title: "達成基準（目標値）を変更できません",
        description: "前回の変更から1週間経過するとまた変更できます",
        variant: "destructive"
      });
      return;
    }
    
    // 警告表示をスキップする設定になっている場合は直接変更
    if (!userStats.showThresholdChangeWarning) {
      const success = changeThreshold(newThreshold);
      if (success) {
        toast({
          title: `達成基準を${newThreshold}%に変更しました`,
          description: "この値を超えたときにガチャが引けるようになります",
        });
      }
      return;
    }
    
    // 確認ダイアログを表示
    setSelectedThreshold(newThreshold);
    setThresholdChangeDialogOpen(true);
  };
  
  // Group management functions
  const openAddGroupModal = () => {
    setGroupFormMode('add');
    setGroupName('');
    setGroupColor(colors[0].value);
    setEditingGroupId(null);
    setGroupModalOpen(true);
  };
  
  const openEditGroupModal = (group: typeof taskGroups[0]) => {
    setGroupFormMode('edit');
    setGroupName(group.name);
    setGroupColor(group.color);
    setEditingGroupId(group.id);
    setGroupModalOpen(true);
  };
  
  const handleSaveGroup = () => {
    if (!groupName.trim()) {
      toast({
        title: "グループ名を入力してください",
        variant: "destructive"
      });
      return;
    }
    
    if (groupFormMode === 'add') {
      addTaskGroup({
        name: groupName.trim(),
        color: groupColor
      });
      toast({
        title: "グループを追加しました"
      });
    } else {
      if (editingGroupId) {
        updateTaskGroup(editingGroupId, {
          name: groupName.trim(),
          color: groupColor
        });
        toast({
          title: "グループを更新しました"
        });
      }
    }
    
    setGroupModalOpen(false);
  };
  
  const handleDeleteGroup = (id: string) => {
    deleteTaskGroup(id);
    toast({
      title: "グループを削除しました"
    });
  };
  
  // Reward management functions
  const openAddRewardModal = () => {
    setRewardFormMode('add');
    setRewardTitle('');
    setRewardDescription('');
    setRewardEmoji('🎁');
    setRewardRarity(1);
    setIsPenalty(false);
    setEditingRewardId(null);
    setRewardModalOpen(true);
  };
  
  const openEditRewardModal = (reward: typeof rewards[0]) => {
    setRewardFormMode('edit');
    setRewardTitle(reward.title);
    setRewardDescription(reward.description || '');
    setRewardEmoji(reward.emoji || '🎁');
    setRewardRarity(reward.rarity);
    setIsPenalty(reward.isPenalty);
    setEditingRewardId(reward.id);
    setRewardModalOpen(true);
  };
  
  const handleSaveReward = () => {
    if (!rewardTitle.trim()) {
      toast({
        title: "タイトルを入力してください",
        variant: "destructive"
      });
      return;
    }
    
    if (rewardFormMode === 'add') {
      addReward({
        title: rewardTitle.trim(),
        description: rewardDescription.trim() || undefined,
        emoji: rewardEmoji,
        rarity: rewardRarity,
        isPenalty
      });
      toast({
        title: `${isPenalty ? '罰ゲーム' : '報酬'}を追加しました`
      });
    } else {
      if (editingRewardId) {
        updateReward(editingRewardId, {
          title: rewardTitle.trim(),
          description: rewardDescription.trim() || undefined,
          emoji: rewardEmoji,
          rarity: rewardRarity,
          isPenalty
        });
        toast({
          title: `${isPenalty ? '罰ゲーム' : '報酬'}を更新しました`
        });
      }
    }
    
    setRewardModalOpen(false);
  };
  
  const handleDeleteReward = (id: string) => {
    deleteReward(id);
    toast({
      title: "報酬/罰ゲームを削除しました"
    });
  };
  
  // Get emojis for selection
  const rewardEmojis = ['🎁', '🎬', '🎮', '🍬', '☕', '📚', '🍽️', '🎯', '🎨', '🎸', '🎧'];
  const penaltyEmojis = ['🧹', '⏰', '📵', '📝', '🏃', '💪', '🚫', '⚠️'];
  
  return (
    <div className="max-w-md mx-auto pb-24">
      <header className="bg-white sticky top-0 z-10 shadow-sm">
        <div className="p-4">
          <h1 className="text-xl font-bold text-primary">設定</h1>
        </div>
      </header>
      
      <div className="p-4">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">ガチャ設定</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <Label htmlFor="threshold">達成基準（目標値）</Label>
                  <span className="text-sm font-medium">{userStats.gachaThreshold}%</span>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <p className="text-xs text-gray-500">
                    ※達成率がこの値を超えると、ガチャで報酬が獲得できます
                    <span className="block mt-1 text-amber-600">※1週間に1回まで変更可能です</span>
                    {!canChangeThreshold && (
                      <span className="block mt-1 text-red-500">（前回の変更から1週間経過していないため、現在変更できません）</span>
                    )}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedThreshold(userStats.gachaThreshold);
                      setThresholdModalOpen(true);
                    }}
                    disabled={!canChangeThreshold}
                  >
                    <Edit className="h-4 w-4 mr-1" /> 変更
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>ガチャ曜日設定</Label>
                <div className="flex flex-wrap gap-2">
                  {['日', '月', '火', '水', '木', '金', '土'].map((day, idx) => (
                    <Button
                      key={idx}
                      type="button"
                      variant={gachaDay === idx ? "default" : "outline"}
                      className={`w-10 h-10 rounded-full ${!canChangeGachaDay && gachaDay !== idx ? 'opacity-50 cursor-not-allowed' : ''}`}
                      onClick={() => {
                        // 同じ曜日を選択した場合は何もしない
                        if (gachaDay === idx) return;
                        
                        // 変更できない場合はエラーメッセージ
                        if (!canChangeGachaDay) {
                          toast({
                            title: "ガチャ曜日を変更できません",
                            description: "前回の変更から2週間経過するとまた変更できます",
                            variant: "destructive"
                          });
                          return;
                        }
                        
                        // 警告表示をスキップする設定になっている場合は直接変更
                        if (!userStats.showGachaDayChangeWarning) {
                          const success = changeGachaDay(idx);
                          if (success) {
                            toast({
                              title: `ガチャ曜日を${day}曜日に変更しました`,
                              description: "次回からこの曜日にガチャが引けるようになります",
                            });
                          }
                          return;
                        }
                        
                        // 確認ダイアログを表示
                        setSelectedGachaDay(idx);
                        setGachaDayChangeDialogOpen(true);
                      }}
                      disabled={!canChangeGachaDay && gachaDay !== idx}
                    >
                      {day}
                    </Button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  現在の設定: <span className="font-medium">{['日', '月', '火', '水', '木', '金', '土'][gachaDay]}曜日</span>
                  <span className="block mt-1 text-amber-600">※2週間に1回まで変更可能です</span>
                  {!canChangeGachaDay && (
                    <span className="block mt-1 text-red-500">（前回の変更から2週間経過していないため、現在変更できません）</span>
                  )}
                </p>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <Label htmlFor="gachaMode">ガチャモード</Label>
                  <span className="text-sm font-medium">
                    {userStats.gachaMode === 'fixed' ? '固定値モード' : 'ランダムモード'}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <p className="text-xs text-gray-500">
                    {userStats.gachaMode === 'fixed' 
                      ? '※固定値モード：設定した回数（最大6回）のガチャを引けます' 
                      : '※ランダムモード：サイコロの出目（1～6）の回数だけガチャを引けます'}
                    <span className="block mt-1 text-amber-600">
                      ※ガチャを使用した後は次回ガチャ日までモード変更できません
                    </span>
                    {!canChangeGachaMode && (
                      <span className="block mt-1 text-red-500">
                        （現在モード変更できません）
                      </span>
                    )}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      // 確認ダイアログを表示
                      setSelectedGachaMode(userStats.gachaMode === 'fixed' ? 'random' : 'fixed');
                      setGachaModeChangeDialogOpen(true);
                    }}
                    disabled={!canChangeGachaMode}
                  >
                    <Edit className="h-4 w-4 mr-1" /> 切替
                  </Button>
                </div>
                
                {/* 固定値モード時のみガチャ回数設定を表示 */}
                {userStats.gachaMode === 'fixed' && (
                  <div className="mt-4 ml-4 border-l-2 border-gray-200 pl-4">
                    <div className="flex justify-between mb-2">
                      <Label htmlFor="gachaCount">ガチャ回数</Label>
                      <span className="text-sm font-medium">{userStats.maxGachaCount}回</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <p className="text-xs text-gray-500">
                        ※ガチャ曜日に1週間で獲得できる最大ガチャ回数です
                        <span className="block mt-1 text-amber-600">※1週間に1回まで変更可能です</span>
                        {!canChangeGachaCount && (
                          <span className="block mt-1 text-red-500">（前回の変更から1週間経過していないため、現在変更できません）</span>
                        )}
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setTempGachaCount(userStats.maxGachaCount);
                          setGachaCountModalOpen(true);
                        }}
                        disabled={!canChangeGachaCount}
                      >
                        <Edit className="h-4 w-4 mr-1" /> 変更
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              
              {userStats.gachaMode === 'random' && (
                <div>
                  <div className="flex justify-between mb-2">
                    <Label htmlFor="diceValue">サイコロの最大値</Label>
                    <span className="text-sm font-medium">{userStats.maxDiceValue}</span>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-xs text-gray-500">
                      ※サイコロの出目の最大値です（1～{userStats.maxDiceValue}の範囲で出目が決まります）
                      {canRollDiceToday && (
                        <span className="block mt-1 text-green-600 font-semibold">
                          今日はサイコロを振ることができます！
                        </span>
                      )}
                      {userStats.hasDiceRolled && (
                        <span className="block mt-1">
                          今週の出目: <span className="font-semibold">{userStats.gachaCount}</span>
                        </span>
                      )}
                    </p>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setTempDiceValue(userStats.maxDiceValue);
                          setDiceValueModalOpen(true);
                        }}
                      >
                        <Edit className="h-4 w-4 mr-1" /> 変更
                      </Button>
                      {/* ガチャページでサイコロを振るように変更 */}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Accordion type="single" collapsible className="mb-6">
          <AccordionItem value="taskgroups">
            <AccordionTrigger>
              <h3 className="text-lg font-medium">タスクグループ管理</h3>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pt-2">
                {taskGroups.map(group => (
                  <div 
                    key={group.id} 
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center">
                      <div 
                        className="w-4 h-4 rounded-full mr-3"
                        style={{ backgroundColor: group.color }}
                      ></div>
                      <span>{group.name}</span>
                    </div>
                    <div>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => openEditGroupModal(group)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleDeleteGroup(group.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                
                <Button 
                  variant="outline" 
                  className="w-full mt-2"
                  onClick={openAddGroupModal}
                >
                  <Plus className="h-4 w-4 mr-2" /> 新しいグループを追加
                </Button>
              </div>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="rewards">
            <AccordionTrigger>
              <h3 className="text-lg font-medium">報酬・罰ゲーム管理</h3>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4 pt-2">
                <div>
                  <h4 className="font-medium mb-2 text-green-600">報酬アイテム</h4>
                  <div className="space-y-2">
                    {rewards.filter(r => !r.isPenalty).map(reward => (
                      <div 
                        key={reward.id} 
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center">
                          <span className="text-xl mr-2">{reward.emoji || '🎁'}</span>
                          <div>
                            <div>{reward.title}</div>
                            <div className="text-xs text-gray-500">
                              {reward.rarity === 3 ? '超レア' : reward.rarity === 2 ? 'レア' : '通常'}
                            </div>
                          </div>
                        </div>
                        <div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => openEditRewardModal(reward)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDeleteReward(reward.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2 text-red-600">罰ゲーム</h4>
                  <div className="space-y-2">
                    {rewards.filter(r => r.isPenalty).map(penalty => (
                      <div 
                        key={penalty.id} 
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center">
                          <span className="text-xl mr-2">{penalty.emoji || '⚠️'}</span>
                          <div>
                            <div>{penalty.title}</div>
                            <div className="text-xs text-gray-500">
                              {penalty.rarity === 3 ? '超レア' : penalty.rarity === 2 ? 'レア' : '通常'}
                            </div>
                          </div>
                        </div>
                        <div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => openEditRewardModal(penalty)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDeleteReward(penalty.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-2"
                  onClick={openAddRewardModal}
                >
                  <Plus className="h-4 w-4 mr-2" /> 新しい報酬/罰ゲームを追加
                </Button>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">アプリについて</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-2">
              このアプリは、シンプルさを維持しながら自己管理と継続的なモチベーション維持をバランスよくサポートする個人向けタスク管理アプリです。
            </p>
            <p className="text-sm text-gray-600">
              Version 1.0.0
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">アカウント</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                アカウントからログアウトします。再度ログインする必要があります。
              </p>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  // useAuth フックの logoutMutation を利用
                  import('./logout-handler').then(module => {
                    module.handleLogout();
                  }).catch(err => {
                    console.error('ログアウト処理のロードに失敗', err);
                  });
                }}
              >
                ログアウト
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg text-red-600">データリセット</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                アプリの全てのデータをリセットし、初期状態に戻します。この操作は取り消せません。
              </p>
              <Button 
                variant="destructive" 
                className="w-full"
                onClick={() => setResetConfirmOpen(true)}
              >
                すべての設定をリセット
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Group Edit Modal */}
      <Dialog open={groupModalOpen} onOpenChange={setGroupModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {groupFormMode === 'add' ? 'グループを追加' : 'グループを編集'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="group-name">グループ名</Label>
              <Input
                id="group-name"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="新しいグループ名"
              />
            </div>
            
            <div className="space-y-2">
              <Label>カラー</Label>
              <div className="flex flex-wrap gap-2">
                {colors.map((color) => (
                  <button
                    key={color.value}
                    className="w-8 h-8 rounded-full border-2 flex items-center justify-center"
                    style={{
                      backgroundColor: color.value,
                      borderColor: groupColor === color.value ? 'white' : color.value,
                      boxShadow: groupColor === color.value ? '0 0 0 2px black' : 'none'
                    }}
                    onClick={() => setGroupColor(color.value)}
                    aria-label={`Select ${color.name} color`}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">キャンセル</Button>
            </DialogClose>
            <Button onClick={handleSaveGroup}>
              {groupFormMode === 'add' ? '追加' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reward Edit Modal */}
      <Dialog open={rewardModalOpen} onOpenChange={setRewardModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {rewardFormMode === 'add' ? '報酬/罰ゲームを追加' : '報酬/罰ゲームを編集'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="isPenalty">罰ゲーム</Label>
              <Switch
                id="isPenalty"
                checked={isPenalty}
                onCheckedChange={setIsPenalty}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="reward-title">タイトル</Label>
              <Input
                id="reward-title"
                value={rewardTitle}
                onChange={(e) => setRewardTitle(e.target.value)}
                placeholder="タイトルを入力"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="reward-description">説明（任意）</Label>
              <Input
                id="reward-description"
                value={rewardDescription}
                onChange={(e) => setRewardDescription(e.target.value)}
                placeholder="説明を入力"
              />
            </div>
            
            <div className="space-y-2">
              <Label>絵文字</Label>
              <div className="flex flex-wrap gap-2">
                {(isPenalty ? penaltyEmojis : rewardEmojis).map((emoji) => (
                  <button
                    key={emoji}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-lg ${
                      rewardEmoji === emoji ? 'bg-gray-200' : ''
                    }`}
                    onClick={() => setRewardEmoji(emoji)}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="rarity">レア度</Label>
                <span className="text-sm font-medium">
                  {rewardRarity === 3 ? '超レア' : rewardRarity === 2 ? 'レア' : '通常'}
                </span>
              </div>
              <Slider
                id="rarity"
                min={1}
                max={3}
                step={1}
                value={[rewardRarity]}
                onValueChange={(value) => setRewardRarity(value[0])}
              />
            </div>
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">キャンセル</Button>
            </DialogClose>
            <Button onClick={handleSaveReward}>
              {rewardFormMode === 'add' ? '追加' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* ガチャ曜日変更確認ダイアログ */}
      <AlertDialog open={gachaDayChangeDialogOpen} onOpenChange={setGachaDayChangeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ガチャ曜日の変更確認</AlertDialogTitle>
            <AlertDialogDescription>
              ガチャ曜日を変更すると、次回からはこの曜日になります。<br />
              ガチャ曜日の変更は2週間に1回までしかできません。<br />
              本当に変更してもよろしいですか？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex items-center space-x-2 py-2">
            <Checkbox 
              id="hide-warning" 
              checked={hideGachaDayChangeWarning}
              onCheckedChange={(checked) => {
                setHideGachaDayChangeWarning(checked === true);
              }}
            />
            <label
              htmlFor="hide-warning"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              以降この確認メッセージを表示しない
            </label>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setSelectedGachaDay(null);
            }}>
              キャンセル
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              // 確認ダイアログで「OK」を押した場合の処理
              if (selectedGachaDay !== null) {
                const day = ['日', '月', '火', '水', '木', '金', '土'][selectedGachaDay];
                const success = changeGachaDay(selectedGachaDay);
                if (success) {
                  toast({
                    title: `ガチャ曜日を${day}曜日に変更しました`,
                    description: "次回からこの曜日にガチャが引けるようになります",
                  });
                  
                  // 警告表示の設定を更新
                  if (hideGachaDayChangeWarning) {
                    updateUserStats({
                      ...userStats,
                      showGachaDayChangeWarning: false
                    });
                  }
                }
              }
              setSelectedGachaDay(null);
            }}>
              変更する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* 達成基準変更確認ダイアログ */}
      <AlertDialog open={thresholdChangeDialogOpen} onOpenChange={setThresholdChangeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>達成基準（目標値）の変更確認</AlertDialogTitle>
            <AlertDialogDescription>
              達成基準を変更すると、ガチャ獲得条件が変わります。<br />
              この変更は1週間に1回までしかできません。<br />
              本当に変更してもよろしいですか？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex items-center space-x-2 py-2">
            <Checkbox 
              id="hide-threshold-warning" 
              checked={hideThresholdChangeWarning}
              onCheckedChange={(checked) => {
                setHideThresholdChangeWarning(checked === true);
              }}
            />
            <label
              htmlFor="hide-threshold-warning"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              以降この確認メッセージを表示しない
            </label>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setSelectedThreshold(null);
            }}>
              キャンセル
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              // 確認ダイアログで「OK」を押した場合の処理
              if (selectedThreshold !== null) {
                const success = changeThreshold(selectedThreshold);
                if (success) {
                  toast({
                    title: `達成基準を${selectedThreshold}%に変更しました`,
                    description: "この値を超えたときにガチャが引けるようになります",
                  });
                  
                  // 警告を非表示にする設定を保存
                  if (hideThresholdChangeWarning) {
                    updateUserStats({
                      ...userStats,
                      showThresholdChangeWarning: false
                    });
                  }
                }
                setSelectedThreshold(null);
              }
            }}>
              変更する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* 達成基準変更モーダル */}
      <Dialog open={thresholdModalOpen} onOpenChange={setThresholdModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>達成基準（目標値）の変更</DialogTitle>
            <DialogDescription>
              ガチャを獲得するために必要な達成率を設定します。<br />
              この変更は1週間に1回までしかできません。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="temp-threshold">達成基準</Label>
                <span className="text-sm font-medium">{tempThreshold}%</span>
              </div>
              <Slider
                id="temp-threshold"
                min={50}
                max={100}
                step={5}
                value={[tempThreshold]}
                onValueChange={(value) => setTempThreshold(value[0])}
              />
              <p className="text-xs text-gray-500 mt-1">
                達成率がこの値を超えた週にのみガチャを引けます
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" onClick={() => {
                setTempThreshold(userStats.gachaThreshold); // 変更をキャンセルして元の値に戻す
              }}>
                キャンセル
              </Button>
            </DialogClose>
            <Button onClick={() => {
              // モーダルで「変更する」を押した場合の処理
              if (tempThreshold === userStats.gachaThreshold) {
                setThresholdModalOpen(false);
                return; // 値が変わっていなければ何もしない
              }
              
              // 警告表示をスキップする設定になっている場合は直接変更
              if (!userStats.showThresholdChangeWarning) {
                const success = changeThreshold(tempThreshold);
                if (success) {
                  toast({
                    title: `達成基準を${tempThreshold}%に変更しました`,
                    description: "この値を超えたときにガチャが引けるようになります",
                  });
                }
                setThresholdModalOpen(false);
                return;
              }
              
              // 確認ダイアログを表示
              setSelectedThreshold(tempThreshold);
              setThresholdModalOpen(false);
              setThresholdChangeDialogOpen(true);
            }}>
              変更する
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* リセット確認ダイアログ */}
      <AlertDialog open={resetConfirmOpen} onOpenChange={setResetConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>すべてのデータをリセット</AlertDialogTitle>
            <AlertDialogDescription>
              これによりすべてのタスク、グループ、報酬、ガチャ履歴などがリセットされます。<br />
              この操作は取り消せません。本当に実行しますか？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>
              キャンセル
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                resetAllData();
                toast({
                  title: "すべてのデータをリセットしました",
                  description: "アプリが初期状態に戻りました",
                });
                // ホームページにリダイレクト（Routerを使用）
                setLocation('/');
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              リセットする
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* 達成基準変更モーダル */}
      <Dialog open={thresholdModalOpen} onOpenChange={setThresholdModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>達成基準の変更</DialogTitle>
            <DialogDescription>
              タスク達成率がこの値を超えるとガチャが引けるようになります。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="threshold-slider">達成基準値</Label>
                <span className="text-sm font-medium">{tempThreshold}%</span>
              </div>
              <Slider
                id="threshold-slider"
                min={50}
                max={100}
                step={5}
                value={[tempThreshold]}
                onValueChange={(value) => setTempThreshold(value[0])}
              />
              <p className="text-xs text-gray-500">
                ※50%〜100%の間で設定できます
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => {
                setSelectedThreshold(tempThreshold);
                if (tempThreshold !== userStats.gachaThreshold) {
                  if (userStats.showThresholdChangeWarning) {
                    setThresholdChangeDialogOpen(true);
                  } else {
                    const success = changeThreshold(tempThreshold);
                    if (success) {
                      toast({
                        title: `達成基準を${tempThreshold}%に変更しました`,
                        description: "この値を超えたときにガチャが引けるようになります",
                      });
                    }
                  }
                }
                setThresholdModalOpen(false);
              }}
            >
              変更する
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* ガチャ回数変更モーダル */}
      <Dialog open={gachaCountModalOpen} onOpenChange={setGachaCountModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ガチャ回数の変更</DialogTitle>
            <DialogDescription>
              週に獲得できる最大ガチャ回数を設定します。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="gachaCount-slider">ガチャ回数</Label>
                <span className="text-sm font-medium">{tempGachaCount}回</span>
              </div>
              <Slider
                id="gachaCount-slider"
                min={1}
                max={6}
                step={1}
                value={[tempGachaCount]}
                onValueChange={(value) => setTempGachaCount(value[0])}
              />
              <p className="text-xs text-gray-500">
                ※1回〜6回の間で設定できます
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => {
                setSelectedGachaCount(tempGachaCount);
                if (tempGachaCount !== userStats.maxGachaCount) {
                  if (userStats.showGachaCountChangeWarning) {
                    setGachaCountChangeDialogOpen(true);
                  } else {
                    const success = changeGachaCount(tempGachaCount);
                    if (success) {
                      toast({
                        title: `ガチャ回数を${tempGachaCount}回に変更しました`,
                        description: "次回のガチャ日から適用されます",
                      });
                    }
                  }
                }
                setGachaCountModalOpen(false);
              }}
            >
              変更する
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* ガチャ回数変更確認ダイアログ */}
      <AlertDialog open={gachaCountChangeDialogOpen} onOpenChange={setGachaCountChangeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ガチャ回数の変更確認</AlertDialogTitle>
            <AlertDialogDescription>
              ガチャ回数を変更すると、獲得できる報酬の数が変わります。<br />
              この変更は1週間に1回までしかできません。<br />
              本当に変更してもよろしいですか？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex items-center space-x-2 py-2">
            <Checkbox 
              id="hide-gachaCount-warning" 
              checked={hideGachaCountChangeWarning}
              onCheckedChange={(checked) => {
                setHideGachaCountChangeWarning(checked === true);
              }}
            />
            <label
              htmlFor="hide-gachaCount-warning"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              以降この確認メッセージを表示しない
            </label>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setSelectedGachaCount(null);
            }}>
              キャンセル
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              // 確認ダイアログで「OK」を押した場合の処理
              if (selectedGachaCount !== null) {
                const success = changeGachaCount(selectedGachaCount);
                if (success) {
                  toast({
                    title: `ガチャ回数を${selectedGachaCount}回に変更しました`,
                    description: "次回のガチャ日から適用されます",
                  });
                  
                  // 警告を非表示にする設定を保存
                  if (hideGachaCountChangeWarning) {
                    updateUserStats({
                      ...userStats,
                      showGachaCountChangeWarning: false
                    });
                  }
                }
                setSelectedGachaCount(null);
              }
            }}>
              変更する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* サイコロ最大値変更モーダル */}
      <Dialog open={diceValueModalOpen} onOpenChange={setDiceValueModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>サイコロの最大値変更</DialogTitle>
            <DialogDescription>
              サイコロの出目の最大値を設定します（1～設定値）
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span>サイコロの最大値</span>
                <span className="font-medium">{tempDiceValue}</span>
              </div>
              <Slider
                value={[tempDiceValue]}
                min={1}
                max={6}
                step={1}
                onValueChange={(value) => setTempDiceValue(value[0])}
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>少ない出目</span>
                <span>多い出目</span>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">キャンセル</Button>
            </DialogClose>
            <Button onClick={() => {
              const success = changeDiceValue(tempDiceValue);
              if (success) {
                toast({
                  title: `サイコロの最大値を${tempDiceValue}に変更しました`,
                  description: "次回サイコロを振る時から適用されます",
                });
                setDiceValueModalOpen(false);
              }
            }}>
              変更
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* ガチャモード変更確認ダイアログ */}
      <AlertDialog open={gachaModeChangeDialogOpen} onOpenChange={setGachaModeChangeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ガチャモード変更確認</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedGachaMode === 'fixed' 
                ? 'ランダムモードから固定値モードに変更します。モード変更後はサイコロを振ることができなくなります。'
                : '固定値モードからランダムモードに変更します。モード変更後は毎週サイコロを振って、ガチャ回数が決まります。'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex items-center space-x-2 py-2">
            <Checkbox 
              id="hide-gachaMode-warning" 
              checked={hideGachaModeChangeWarning}
              onCheckedChange={(checked) => {
                setHideGachaModeChangeWarning(checked === true);
              }}
            />
            <label
              htmlFor="hide-gachaMode-warning"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              以降この確認メッセージを表示しない
            </label>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setSelectedGachaMode(null);
            }}>
              キャンセル
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              if (selectedGachaMode) {
                const success = changeGachaMode(selectedGachaMode);
                if (success) {
                  toast({
                    title: `ガチャモードを${selectedGachaMode === 'fixed' ? '固定値モード' : 'ランダムモード'}に変更しました`,
                    description: selectedGachaMode === 'random' ? "次回のガチャ日にサイコロを振ってください" : undefined,
                  });
                  
                  // 警告を非表示にする設定を保存
                  if (hideGachaModeChangeWarning) {
                    updateUserStats({
                      ...userStats,
                      showGachaModeChangeWarning: false
                    });
                  }
                }
                setSelectedGachaMode(null);
              }
            }}>
              変更する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <TabBar />
    </div>
  );
}
