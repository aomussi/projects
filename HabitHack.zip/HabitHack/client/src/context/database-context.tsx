import React, { createContext, useContext, useEffect, useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useDatabaseSync } from '@/hooks/use-database-sync';
import {
  TaskLocal,
  TaskGroupLocal,
  RewardLocal,
  GachaHistoryLocal,
  UserStatsLocal,
  AchievementLocal
} from '@shared/schema';

interface DatabaseContextType {
  // Data from database
  tasks: TaskLocal[];
  taskGroups: TaskGroupLocal[];
  rewards: RewardLocal[];
  gachaHistory: GachaHistoryLocal[];
  userStats: UserStatsLocal | null;
  achievements: AchievementLocal[];
  
  // Loading state
  isLoading: boolean;
  
  // Database operations
  syncToDatabase: () => Promise<void>;
  createTask: (task: Omit<TaskLocal, 'id'>) => Promise<any>;
  createTaskGroup: (group: Omit<TaskGroupLocal, 'id'>) => Promise<any>;
  createReward: (reward: Omit<RewardLocal, 'id'>) => Promise<any>;
  createGachaHistory: (history: Omit<GachaHistoryLocal, 'id'>) => Promise<any>;
  updateUserStats: (stats: Partial<UserStatsLocal>) => Promise<any>;
  updateTask: (id: string, updates: Partial<TaskLocal>) => Promise<any>;
  updateTaskGroup: (id: string, updates: Partial<TaskGroupLocal>) => Promise<any>;
  updateReward: (id: string, updates: Partial<RewardLocal>) => Promise<any>;
  deleteTask: (id: string) => Promise<void>;
  deleteTaskGroup: (id: string) => Promise<void>;
  deleteReward: (id: string) => Promise<void>;
}

const DatabaseContext = createContext<DatabaseContextType | null>(null);

export function DatabaseProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const databaseSync = useDatabaseSync();
  const [hasInitialized, setHasInitialized] = useState(false);

  const syncToDatabase = async () => {
    if (!user) return;
    
    try {
      // Database sync logic will be implemented here
      // For now, we'll just mark as synced
      setHasInitialized(true);
    } catch (error) {
      console.error('Database sync failed:', error);
    }
  };

  useEffect(() => {
    if (user && !hasInitialized) {
      syncToDatabase();
    }
  }, [user, hasInitialized]);

  const contextValue: DatabaseContextType = {
    // Data
    tasks: Array.isArray(databaseSync.tasks) ? databaseSync.tasks : [],
    taskGroups: Array.isArray(databaseSync.taskGroups) ? databaseSync.taskGroups : [],
    rewards: Array.isArray(databaseSync.rewards) ? databaseSync.rewards : [],
    gachaHistory: Array.isArray(databaseSync.gachaHistory) ? databaseSync.gachaHistory : [],
    userStats: databaseSync.userStats || null,
    achievements: Array.isArray(databaseSync.achievements) ? databaseSync.achievements : [],
    
    // Loading state
    isLoading: databaseSync.isLoading,
    
    // Operations
    syncToDatabase,
    createTask: async (task: Omit<TaskLocal, 'id'>) => databaseSync.createTask(task),
    createTaskGroup: async (group: Omit<TaskGroupLocal, 'id'>) => databaseSync.createTaskGroup(group),
    createReward: async (reward: Omit<RewardLocal, 'id'>) => databaseSync.createReward(reward),
    createGachaHistory: async (history: Omit<GachaHistoryLocal, 'id'>) => databaseSync.createGachaHistory(history),
    updateUserStats: async (updates: Partial<UserStatsLocal>) => databaseSync.updateUserStats(updates),
    updateTask: async (id: string, updates: Partial<TaskLocal>) => databaseSync.updateTask({ id, updates }),
    updateTaskGroup: async (id: string, updates: Partial<TaskGroupLocal>) => databaseSync.updateTaskGroup({ id, updates }),
    updateReward: async (id: string, updates: Partial<RewardLocal>) => databaseSync.updateReward({ id, updates }),
    deleteTask: async (id: string) => databaseSync.deleteTask(id),
    deleteTaskGroup: async (id: string) => databaseSync.deleteTaskGroup(id),
    deleteReward: async (id: string) => databaseSync.deleteReward(id),
  };

  return (
    <DatabaseContext.Provider value={contextValue}>
      {children}
    </DatabaseContext.Provider>
  );
}

export function useDatabase() {
  const context = useContext(DatabaseContext);
  if (!context) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
}