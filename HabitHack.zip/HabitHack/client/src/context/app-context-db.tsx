import React, { createContext, useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { useDatabase } from '@/context/database-context';
import { 
  TaskLocal, 
  TaskGroupLocal, 
  RewardLocal, 
  GachaHistoryLocal, 
  UserStatsLocal,
  AchievementLocal,
  RecurrencePattern
} from '@shared/schema';
import { DEFAULT_TASK_GROUPS, DEFAULT_REWARDS, DEFAULT_ACHIEVEMENTS } from '@/lib/constants';
import { generateId, getCompletionRate } from '@/lib/utils';
import { getToday, parseDate, formatSimpleDate, getNextDay } from '@/lib/dates';
import { addDays } from 'date-fns';

interface AppContextType {
  // Current date
  currentDate: string;
  setCurrentDate: (date: string) => void;
  
  // Tasks
  tasks: TaskLocal[];
  addTask: (task: Omit<TaskLocal, 'id'>) => void;
  updateTask: (id: string, updates: Partial<TaskLocal>) => void;
  deleteTask: (id: string, deleteRelated?: boolean) => void;
  completeTask: (id: string) => void;
  uncompleteTask: (id: string) => void;
  moveTaskUp: (id: string) => void;
  moveTaskDown: (id: string) => void;
  reorderTasks: (tasks: TaskLocal[]) => void;
  getTodayTasks: () => TaskLocal[];
  
  // Task Groups
  taskGroups: TaskGroupLocal[];
  addTaskGroup: (group: Omit<TaskGroupLocal, 'id'>) => void;
  updateTaskGroup: (id: string, updates: Partial<TaskGroupLocal>) => void;
  deleteTaskGroup: (id: string) => void;
  
  // Rewards
  rewards: RewardLocal[];
  addReward: (reward: Omit<RewardLocal, 'id'>) => void;
  updateReward: (id: string, updates: Partial<RewardLocal>) => void;
  deleteReward: (id: string) => void;
  getAvailableRewards: () => RewardLocal[];
  
  // Gacha
  gachaHistory: GachaHistoryLocal[];
  addGachaHistory: (history: Omit<GachaHistoryLocal, 'id'>) => void;
  performGacha: () => RewardLocal | null;
  useGachaCount: () => boolean;
  changeGachaThreshold: (newThreshold: number) => boolean;
  canChangeGachaThreshold: boolean;
  changeGachaDay: (newDay: number) => boolean;
  canChangeGachaDay: boolean;
  changeGachaCount: (newCount: number) => boolean;
  canChangeGachaCount: boolean;
  changeGachaMode: (newMode: 'fixed' | 'random') => boolean;
  canChangeGachaMode: boolean;
  rollDice: () => number;
  canRollDice: boolean;
  changeDiceValue: (newValue: number) => boolean;
  canRollDiceToday: boolean;
  
  // User Stats
  userStats: UserStatsLocal;
  updateUserStats: (updates: Partial<UserStatsLocal>) => void;
  weeklyData: {
    date: string;
    completionRate: number;
  }[];
  weeklyAverageCompletionRate: number;
  daysUntilGacha: number;
  gachaWeekDateRange: {
    start: string;
    end: string;
  };
  
  // Achievements
  achievements: AchievementLocal[];
  updateAchievement: (id: string, updates: Partial<AchievementLocal>) => void;
  getUnlockedAchievements: () => AchievementLocal[];
  
  // Active Task for Timer
  activeTaskId: string | null;
  setActiveTaskId: (id: string | null) => void;
  
  // Reset all app data
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentDate, setCurrentDate] = useState<string>(() => getToday());
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);

  // データベース連携フック
  const {
    tasks: dbTasks,
    taskGroups: dbTaskGroups,
    rewards: dbRewards,
    gachaHistory: dbGachaHistory,
    userStats: dbUserStats,
    isLoading,
    createTask,
    updateTask: dbUpdateTask,
    deleteTask: dbDeleteTask,
    createTaskGroup,
    createReward,
    updateUserStats: dbUpdateUserStats,
    createGachaHistory,
  } = useDatabase();

  // デフォルトデータの使用
  const tasks = dbTasks || [];
  const taskGroups = dbTaskGroups || DEFAULT_TASK_GROUPS;
  const rewards = dbRewards || DEFAULT_REWARDS;
  const gachaHistory = dbGachaHistory || [];
  const userStats = dbUserStats || {
    streak: 0,
    gachaThreshold: 80,
    weeklyData: [],
    gachaDay: 0,
    lastGachaDayChange: undefined,
    showGachaDayChangeWarning: true,
    lastThresholdChange: undefined,
    showThresholdChangeWarning: true,
    gachaCount: 1,
    maxGachaCount: 1,
    lastGachaCountChange: undefined,
    showGachaCountChangeWarning: true,
    gachaMode: 'fixed' as const,
    lastGachaModeChange: undefined,
    showGachaModeChangeWarning: true,
    maxDiceValue: 6,
    hasDiceRolled: false,
    lastDiceRoll: undefined,
  };
  const achievements = DEFAULT_ACHIEVEMENTS;

  // Helper functions
  const calculateDaysDiff = (dateStr1: string, dateStr2: string) => {
    const date1 = parseDate(dateStr1);
    const date2 = parseDate(dateStr2);
    return Math.floor((date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24));
  };

  // Task functions
  const addTask = useCallback(async (task: Omit<TaskLocal, 'id'>) => {
    await createTask(task);
  }, [createTask]);

  const updateTask = useCallback(async (id: string, updates: Partial<TaskLocal>) => {
    await dbUpdateTask(id, updates);
  }, [dbUpdateTask]);

  const deleteTask = useCallback(async (id: string, deleteRelated?: boolean) => {
    if (deleteRelated) {
      const relatedTasks = tasks.filter(task => task.parentTaskId === id);
      for (const relatedTask of relatedTasks) {
        await dbDeleteTask(relatedTask.id);
      }
    }
    await dbDeleteTask(id);
  }, [dbDeleteTask, tasks]);

  const completeTask = useCallback(async (id: string) => {
    await updateTask(id, { 
      isCompleted: true,
      completedAt: new Date().toISOString()
    });
  }, [updateTask]);

  const uncompleteTask = useCallback(async (id: string) => {
    await updateTask(id, { 
      isCompleted: false,
      completedAt: undefined
    });
  }, [updateTask]);

  const moveTaskUp = useCallback(async (id: string) => {
    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex > 0) {
      await updateTask(tasks[taskIndex].id, { order: taskIndex - 1 });
      await updateTask(tasks[taskIndex - 1].id, { order: taskIndex });
    }
  }, [tasks, updateTask]);

  const moveTaskDown = useCallback(async (id: string) => {
    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex < tasks.length - 1) {
      await updateTask(tasks[taskIndex].id, { order: taskIndex + 1 });
      await updateTask(tasks[taskIndex + 1].id, { order: taskIndex });
    }
  }, [tasks, updateTask]);

  const reorderTasks = useCallback(async (newTasks: TaskLocal[]) => {
    for (let i = 0; i < newTasks.length; i++) {
      await updateTask(newTasks[i].id, { order: i });
    }
  }, [updateTask]);

  const getTodayTasks = useCallback(() => {
    return tasks.filter(task => task.date === currentDate);
  }, [tasks, currentDate]);

  // Task Group functions
  const addTaskGroup = useCallback(async (group: Omit<TaskGroupLocal, 'id'>) => {
    await createTaskGroup(group);
  }, [createTaskGroup]);

  const updateTaskGroup = useCallback((id: string, updates: Partial<TaskGroupLocal>) => {
    console.warn('updateTaskGroup not implemented');
  }, []);

  const deleteTaskGroup = useCallback((id: string) => {
    console.warn('deleteTaskGroup not implemented');
  }, []);

  // Reward functions
  const addReward = useCallback(async (reward: Omit<RewardLocal, 'id'>) => {
    await createReward(reward);
  }, [createReward]);

  const updateReward = useCallback((id: string, updates: Partial<RewardLocal>) => {
    console.warn('updateReward not implemented');
  }, []);

  const deleteReward = useCallback((id: string) => {
    console.warn('deleteReward not implemented');
  }, []);

  const getAvailableRewards = useCallback(() => {
    return rewards.filter(reward => !reward.usedInTask);
  }, [rewards]);

  // Gacha functions
  const addGachaHistory = useCallback(async (history: Omit<GachaHistoryLocal, 'id'>) => {
    await createGachaHistory(history);
  }, [createGachaHistory]);

  const performGacha = useCallback(() => {
    const availableRewards = getAvailableRewards();
    if (availableRewards.length === 0) return null;
    const randomIndex = Math.floor(Math.random() * availableRewards.length);
    return availableRewards[randomIndex];
  }, [getAvailableRewards]);

  const useGachaCount = useCallback(() => {
    if (userStats.gachaCount <= 0) return false;
    dbUpdateUserStats({ gachaCount: userStats.gachaCount - 1 });
    return true;
  }, [userStats.gachaCount, dbUpdateUserStats]);

  // Gacha configuration functions
  const changeGachaThreshold = useCallback((newThreshold: number) => {
    const today = getToday();
    const lastChange = userStats.lastThresholdChange;
    
    if (lastChange && calculateDaysDiff(lastChange, today) < 7) {
      return false;
    }
    
    dbUpdateUserStats({
      gachaThreshold: newThreshold,
      lastThresholdChange: today
    });
    return true;
  }, [userStats.lastThresholdChange, dbUpdateUserStats]);

  const canChangeGachaThreshold = useMemo(() => {
    const today = getToday();
    const lastChange = userStats.lastThresholdChange;
    return !lastChange || calculateDaysDiff(lastChange, today) >= 7;
  }, [userStats.lastThresholdChange]);

  const changeGachaDay = useCallback((newDay: number) => {
    const today = getToday();
    const lastChange = userStats.lastGachaDayChange;
    
    if (lastChange && calculateDaysDiff(lastChange, today) < 14) {
      return false;
    }
    
    dbUpdateUserStats({
      gachaDay: newDay,
      lastGachaDayChange: today
    });
    return true;
  }, [userStats.lastGachaDayChange, dbUpdateUserStats]);

  const canChangeGachaDay = useMemo(() => {
    const today = getToday();
    const lastChange = userStats.lastGachaDayChange;
    return !lastChange || calculateDaysDiff(lastChange, today) >= 14;
  }, [userStats.lastGachaDayChange]);

  const changeGachaCount = useCallback((newCount: number) => {
    const today = getToday();
    const lastChange = userStats.lastGachaCountChange;
    
    if (lastChange && calculateDaysDiff(lastChange, today) < 7) {
      return false;
    }
    
    dbUpdateUserStats({
      maxGachaCount: newCount,
      lastGachaCountChange: today
    });
    return true;
  }, [userStats.lastGachaCountChange, dbUpdateUserStats]);

  const canChangeGachaCount = useMemo(() => {
    const today = getToday();
    const lastChange = userStats.lastGachaCountChange;
    return !lastChange || calculateDaysDiff(lastChange, today) >= 7;
  }, [userStats.lastGachaCountChange]);

  const changeGachaMode = useCallback((newMode: 'fixed' | 'random') => {
    dbUpdateUserStats({ gachaMode: newMode });
    return true;
  }, [dbUpdateUserStats]);

  const canChangeGachaMode = useMemo(() => true, []);

  const rollDice = useCallback(() => {
    const result = Math.floor(Math.random() * userStats.maxDiceValue) + 1;
    dbUpdateUserStats({
      gachaCount: result,
      hasDiceRolled: true,
      lastDiceRoll: getToday()
    });
    return result;
  }, [userStats.maxDiceValue, dbUpdateUserStats]);

  const canRollDice = useMemo(() => {
    return userStats.gachaMode === 'random' && !userStats.hasDiceRolled;
  }, [userStats.gachaMode, userStats.hasDiceRolled]);

  const changeDiceValue = useCallback((newValue: number) => {
    dbUpdateUserStats({ maxDiceValue: newValue });
    return true;
  }, [dbUpdateUserStats]);

  const canRollDiceToday = useMemo(() => canRollDice, [canRollDice]);

  // User Stats functions
  const updateUserStatsLocal = useCallback((updates: Partial<UserStatsLocal>) => {
    dbUpdateUserStats(updates);
  }, [dbUpdateUserStats]);

  // Weekly stats calculation
  const weeklyData = useMemo(() => userStats.weeklyData || [], [userStats.weeklyData]);
  
  const weeklyAverageCompletionRate = useMemo(() => {
    if (weeklyData.length === 0) return 0;
    const sum = weeklyData.reduce((total, day) => total + day.completionRate, 0);
    return Math.round(sum / weeklyData.length);
  }, [weeklyData]);

  const daysUntilGacha = useMemo(() => {
    const today = parseDate(getToday());
    const dayOfWeek = today.getDay();
    const gachaDay = userStats.gachaDay;
    let daysUntil = gachaDay - dayOfWeek;
    if (daysUntil <= 0) daysUntil += 7;
    return daysUntil;
  }, [userStats.gachaDay]);

  const gachaWeekDateRange = useMemo(() => {
    const today = getToday();
    const todayDate = parseDate(today);
    const nextWeekDate = new Date(todayDate.getTime() + 7 * 24 * 60 * 60 * 1000);
    const nextWeek = formatSimpleDate(nextWeekDate);
    return { start: today, end: nextWeek };
  }, []);

  // Achievement functions
  const updateAchievement = useCallback((id: string, updates: Partial<AchievementLocal>) => {
    console.warn('updateAchievement not implemented');
  }, []);

  const getUnlockedAchievements = useCallback(() => {
    return achievements.filter(achievement => achievement.isUnlocked);
  }, [achievements]);

  // Reset function
  const resetAllData = useCallback(() => {
    console.warn('resetAllData not implemented');
    setActiveTaskId(null);
  }, []);

  const contextValue: AppContextType = {
    currentDate,
    setCurrentDate,
    tasks,
    addTask,
    updateTask,
    deleteTask,
    completeTask,
    uncompleteTask,
    moveTaskUp,
    moveTaskDown,
    reorderTasks,
    getTodayTasks,
    taskGroups,
    addTaskGroup,
    updateTaskGroup,
    deleteTaskGroup,
    rewards,
    addReward,
    updateReward,
    deleteReward,
    getAvailableRewards,
    gachaHistory,
    addGachaHistory,
    performGacha,
    useGachaCount,
    changeGachaThreshold,
    canChangeGachaThreshold,
    changeGachaDay,
    canChangeGachaDay,
    changeGachaCount,
    canChangeGachaCount,
    changeGachaMode,
    canChangeGachaMode,
    rollDice,
    canRollDice,
    changeDiceValue,
    canRollDiceToday,
    userStats,
    updateUserStats: updateUserStatsLocal,
    weeklyData,
    weeklyAverageCompletionRate,
    daysUntilGacha,
    gachaWeekDateRange,
    achievements,
    updateAchievement,
    getUnlockedAchievements,
    activeTaskId,
    setActiveTaskId,
    resetAllData,
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};