import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import { TaskLocal } from '@shared/schema';

export type TimerMode = 'countdown' | 'stopwatch';

interface TaskTimerState {
  taskId: string;
  isRunning: boolean;
  isPaused: boolean;
  mode: TimerMode;
  duration: number; // in minutes
  timeLeft: number; // in seconds for countdown
  elapsedTime: number; // in seconds for stopwatch
  startTime: Date | null;
  pausedTime: Date | null; // 一時停止した時刻
  intervalId: NodeJS.Timeout | null;
  realStartTime: Date | null; // 実際の開始時刻（バックグラウンド計算用）
}

interface TimerContextType {
  getTaskTimer: (taskId: string) => TaskTimerState;
  startTimer: (taskId: string, mode: TimerMode, duration?: number) => void;
  pauseTimer: (taskId: string) => void;
  resumeTimer: (taskId: string) => void;
  stopTimer: (taskId: string) => void;
  resetTimer: (taskId: string) => void;
  setTimerMode: (taskId: string, mode: TimerMode) => void;
  setTimerDuration: (taskId: string, duration: number) => void;
  getFormattedTime: (taskId: string) => string;
  getProgress: (taskId: string) => number;
}

const TimerContext = createContext<TimerContextType | null>(null);

export function TimerProvider({ children }: { children: React.ReactNode }) {
  const [timers, setTimers] = useState<Map<string, TaskTimerState>>(new Map());
  const intervalsRef = useRef<Map<string, NodeJS.Timeout>>(new Map());

  // バックグラウンドでも正確な時間を計算する関数
  const calculateCurrentTime = (timer: TaskTimerState): { timeLeft: number; elapsedTime: number } => {
    if (!timer.realStartTime || !timer.isRunning) {
      return { timeLeft: timer.timeLeft, elapsedTime: timer.elapsedTime };
    }

    const now = new Date();
    const totalElapsed = Math.floor((now.getTime() - timer.realStartTime.getTime()) / 1000);

    if (timer.mode === 'countdown') {
      const initialTime = timer.duration * 60;
      const newTimeLeft = Math.max(0, initialTime - totalElapsed);
      return { timeLeft: newTimeLeft, elapsedTime: totalElapsed };
    } else {
      return { timeLeft: timer.timeLeft, elapsedTime: totalElapsed };
    }
  };

  // タスクのタイマー状態を取得（存在しない場合はデフォルト値を作成）
  const getTaskTimer = (taskId: string): TaskTimerState => {
    const existing = timers.get(taskId);
    if (existing) {
      // バックグラウンドでの経過時間を反映
      const { timeLeft, elapsedTime } = calculateCurrentTime(existing);
      return { ...existing, timeLeft, elapsedTime };
    }

    const defaultTimer: TaskTimerState = {
      taskId,
      isRunning: false,
      isPaused: false,
      mode: 'countdown',
      duration: 25, // デフォルト25分
      timeLeft: 25 * 60, // 25分を秒に変換
      elapsedTime: 0,
      startTime: null,
      pausedTime: null,
      intervalId: null,
      realStartTime: null,
    };

    setTimers(prev => new Map(prev).set(taskId, defaultTimer));
    return defaultTimer;
  };

  // タイマーを開始
  const startTimer = (taskId: string, mode: TimerMode, duration = 25) => {
    const timer = getTaskTimer(taskId);
    
    // 既存のインターバルをクリア
    const existingInterval = intervalsRef.current.get(taskId);
    if (existingInterval) {
      clearInterval(existingInterval);
    }

    const startTime = new Date();
    const newTimer: TaskTimerState = {
      ...timer,
      isRunning: true,
      isPaused: false,
      mode,
      duration,
      timeLeft: mode === 'countdown' ? duration * 60 : timer.timeLeft,
      elapsedTime: mode === 'stopwatch' ? 0 : timer.elapsedTime,
      startTime,
      pausedTime: null,
      realStartTime: startTime, // バックグラウンド計算用の開始時刻
    };

    setTimers(prev => new Map(prev).set(taskId, newTimer));

    // バックグラウンドでも動作するインターバル開始
    const intervalId = setInterval(() => {
      setTimers(prevTimers => {
        const currentTimer = prevTimers.get(taskId);
        if (!currentTimer || !currentTimer.isRunning || !currentTimer.realStartTime) return prevTimers;

        const newTimers = new Map(prevTimers);
        const { timeLeft, elapsedTime } = calculateCurrentTime(currentTimer);
        
        if (currentTimer.mode === 'countdown') {
          newTimers.set(taskId, {
            ...currentTimer,
            timeLeft,
            elapsedTime,
          });

          // タイマー終了時
          if (timeLeft === 0) {
            clearInterval(intervalId);
            intervalsRef.current.delete(taskId);
            newTimers.set(taskId, {
              ...currentTimer,
              isRunning: false,
              timeLeft: 0,
              elapsedTime,
            });
          }
        } else {
          // ストップウォッチモード
          newTimers.set(taskId, {
            ...currentTimer,
            elapsedTime,
          });
        }

        return newTimers;
      });
    }, 1000);

    intervalsRef.current.set(taskId, intervalId);
  };

  // タイマーを一時停止
  const pauseTimer = (taskId: string) => {
    const intervalId = intervalsRef.current.get(taskId);
    if (intervalId) {
      clearInterval(intervalId);
      intervalsRef.current.delete(taskId);
    }

    setTimers(prev => {
      const timer = prev.get(taskId);
      if (!timer) return prev;
      
      // 現在の正確な時間を計算してから一時停止
      const { timeLeft, elapsedTime } = calculateCurrentTime(timer);
      
      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...timer,
        isRunning: false,
        isPaused: true,
        pausedTime: new Date(),
        timeLeft,
        elapsedTime,
      });
      return newTimers;
    });
  };

  // タイマーを再開
  const resumeTimer = (taskId: string) => {
    const timer = getTaskTimer(taskId);
    if (!timer.isPaused) return;

    // 既存のインターバルをクリア
    const existingInterval = intervalsRef.current.get(taskId);
    if (existingInterval) {
      clearInterval(existingInterval);
    }

    const now = new Date();
    
    // 一時停止時間を考慮して新しい開始時刻を計算
    setTimers(prev => {
      const currentTimer = prev.get(taskId);
      if (!currentTimer) return prev;

      // 一時停止していた時間を除いた新しい実際の開始時刻を計算
      const pausedDuration = currentTimer.pausedTime ? 
        Math.floor((now.getTime() - currentTimer.pausedTime.getTime()) / 1000) : 0;
      
      const newRealStartTime = currentTimer.realStartTime ? 
        new Date(currentTimer.realStartTime.getTime() + (pausedDuration * 1000)) : now;

      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...currentTimer,
        isRunning: true,
        isPaused: false,
        pausedTime: null,
        realStartTime: newRealStartTime,
      });
      return newTimers;
    });

    // バックグラウンド対応のインターバル開始
    const intervalId = setInterval(() => {
      setTimers(prevTimers => {
        const currentTimer = prevTimers.get(taskId);
        if (!currentTimer || !currentTimer.isRunning || !currentTimer.realStartTime) return prevTimers;

        const newTimers = new Map(prevTimers);
        const { timeLeft, elapsedTime } = calculateCurrentTime(currentTimer);
        
        if (currentTimer.mode === 'countdown') {
          newTimers.set(taskId, {
            ...currentTimer,
            timeLeft,
            elapsedTime,
          });

          // タイマー終了時
          if (timeLeft === 0) {
            clearInterval(intervalId);
            intervalsRef.current.delete(taskId);
            newTimers.set(taskId, {
              ...currentTimer,
              isRunning: false,
              timeLeft: 0,
              elapsedTime,
            });
          }
        } else {
          // ストップウォッチモード
          newTimers.set(taskId, {
            ...currentTimer,
            elapsedTime,
          });
        }

        return newTimers;
      });
    }, 1000);

    intervalsRef.current.set(taskId, intervalId);
  };

  // タイマーを停止
  const stopTimer = (taskId: string) => {
    const intervalId = intervalsRef.current.get(taskId);
    if (intervalId) {
      clearInterval(intervalId);
      intervalsRef.current.delete(taskId);
    }

    setTimers(prev => {
      const timer = prev.get(taskId);
      if (!timer) return prev;
      
      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...timer,
        isRunning: false,
        isPaused: false,
      });
      return newTimers;
    });
  };

  // タイマーをリセット
  const resetTimer = (taskId: string) => {
    stopTimer(taskId);
    
    setTimers(prev => {
      const timer = prev.get(taskId);
      if (!timer) return prev;
      
      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...timer,
        timeLeft: timer.duration * 60,
        elapsedTime: 0,
        startTime: null,
      });
      return newTimers;
    });
  };

  // タイマーモードを設定
  const setTimerMode = (taskId: string, mode: TimerMode) => {
    setTimers(prev => {
      const timer = prev.get(taskId) || getTaskTimer(taskId);
      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...timer,
        mode,
        timeLeft: mode === 'countdown' ? timer.duration * 60 : timer.timeLeft,
        elapsedTime: mode === 'stopwatch' ? 0 : timer.elapsedTime,
      });
      return newTimers;
    });
  };

  // タイマー時間を設定
  const setTimerDuration = (taskId: string, duration: number) => {
    setTimers(prev => {
      const timer = prev.get(taskId) || getTaskTimer(taskId);
      const newTimers = new Map(prev);
      newTimers.set(taskId, {
        ...timer,
        duration,
        timeLeft: timer.mode === 'countdown' ? duration * 60 : timer.timeLeft,
      });
      return newTimers;
    });
  };

  // 時間をフォーマット
  const getFormattedTime = (taskId: string): string => {
    const timer = getTaskTimer(taskId);
    
    if (timer.mode === 'countdown') {
      const minutes = Math.floor(timer.timeLeft / 60);
      const seconds = timer.timeLeft % 60;
      return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
      const minutes = Math.floor(timer.elapsedTime / 60);
      const seconds = timer.elapsedTime % 60;
      return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
  };

  // 進捗率を取得
  const getProgress = (taskId: string): number => {
    const timer = getTaskTimer(taskId);
    
    if (timer.mode === 'countdown') {
      const totalTime = timer.duration * 60;
      return totalTime > 0 ? ((totalTime - timer.timeLeft) / totalTime) * 100 : 0;
    }
    
    return 0; // ストップウォッチモードでは進捗率なし
  };

  // ページフォーカス時の時間補正とバックグラウンド対応
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        // ページが再表示されたときに全タイマーを更新
        setTimers(prevTimers => {
          const newTimers = new Map(prevTimers);
          
          prevTimers.forEach((timer, taskId) => {
            if (timer.isRunning && timer.realStartTime) {
              const { timeLeft, elapsedTime } = calculateCurrentTime(timer);
              newTimers.set(taskId, {
                ...timer,
                timeLeft,
                elapsedTime,
              });
              
              // カウントダウンが終了している場合は停止
              if (timer.mode === 'countdown' && timeLeft === 0) {
                newTimers.set(taskId, {
                  ...timer,
                  isRunning: false,
                  timeLeft: 0,
                  elapsedTime,
                });
                
                // インターバルも停止
                const intervalId = intervalsRef.current.get(taskId);
                if (intervalId) {
                  clearInterval(intervalId);
                  intervalsRef.current.delete(taskId);
                }
              }
            }
          });
          
          return newTimers;
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // コンポーネントのアンマウント時にクリーンアップ
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      intervalsRef.current.forEach(intervalId => clearInterval(intervalId));
      intervalsRef.current.clear();
    };
  }, []);

  const contextValue: TimerContextType = {
    getTaskTimer,
    startTimer,
    pauseTimer,
    resumeTimer,
    stopTimer,
    resetTimer,
    setTimerMode,
    setTimerDuration,
    getFormattedTime,
    getProgress,
  };

  return (
    <TimerContext.Provider value={contextValue}>
      {children}
    </TimerContext.Provider>
  );
}

export function useTaskTimer() {
  const context = useContext(TimerContext);
  if (!context) {
    throw new Error('useTaskTimer must be used within a TimerProvider');
  }
  return context;
}