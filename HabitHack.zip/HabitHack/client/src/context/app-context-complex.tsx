import React, { createContext, useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { useDatabase } from '@/context/database-context';
import { 
  TaskLocal, 
  TaskGroupLocal, 
  RewardLocal, 
  GachaHistoryLocal, 
  UserStatsLocal,
  AchievementLocal,
  RecurrencePattern
} from '@shared/schema';
import { DEFAULT_TASK_GROUPS, DEFAULT_REWARDS, DEFAULT_ACHIEVEMENTS } from '@/lib/constants';
import { generateId, getCompletionRate } from '@/lib/utils';
import * as dateUtils from '@/lib/dates';

interface AppContextType {
  // Current date
  currentDate: string;
  setCurrentDate: (date: string) => void;
  
  // Tasks
  tasks: TaskLocal[];
  addTask: (task: Omit<TaskLocal, 'id'>) => void;
  updateTask: (id: string, updates: Partial<TaskLocal>) => void;
  deleteTask: (id: string, deleteRelated?: boolean) => void;
  completeTask: (id: string) => void;
  uncompleteTask: (id: string) => void;
  moveTaskUp: (id: string) => void;
  moveTaskDown: (id: string) => void;
  reorderTasks: (tasks: TaskLocal[]) => void;
  getTodayTasks: () => TaskLocal[];
  
  // Task Groups
  taskGroups: TaskGroupLocal[];
  addTaskGroup: (group: Omit<TaskGroupLocal, 'id'>) => void;
  updateTaskGroup: (id: string, updates: Partial<TaskGroupLocal>) => void;
  deleteTaskGroup: (id: string) => void;
  
  // Rewards
  rewards: RewardLocal[];
  addReward: (reward: Omit<RewardLocal, 'id'>) => void;
  updateReward: (id: string, updates: Partial<RewardLocal>) => void;
  deleteReward: (id: string) => void;
  getAvailableRewards: () => RewardLocal[];
  
  // Gacha
  gachaHistory: GachaHistoryLocal[];
  addGachaHistory: (history: Omit<GachaHistoryLocal, 'id'>) => void;
  performGacha: () => RewardLocal | null;
  useGachaCount: () => boolean;
  changeGachaThreshold: (newThreshold: number) => boolean;
  canChangeGachaThreshold: boolean;
  changeGachaDay: (newDay: number) => boolean;
  canChangeGachaDay: boolean;
  changeGachaCount: (newCount: number) => boolean;
  canChangeGachaCount: boolean;
  changeGachaMode: (newMode: 'fixed' | 'random') => boolean;
  canChangeGachaMode: boolean;
  rollDice: () => number;
  canRollDice: boolean;
  changeDiceValue: (newValue: number) => boolean;
  canRollDiceToday: boolean;
  
  // User Stats
  userStats: UserStatsLocal;
  updateUserStats: (updates: Partial<UserStatsLocal>) => void;
  weeklyData: {
    date: string;
    completionRate: number;
  }[];
  weeklyAverageCompletionRate: number;
  daysUntilGacha: number;
  gachaWeekDateRange: {
    start: string;
    end: string;
  };
  
  // Achievements
  achievements: AchievementLocal[];
  updateAchievement: (id: string, updates: Partial<AchievementLocal>) => void;
  getUnlockedAchievements: () => AchievementLocal[];
  
  // Active Task for Timer
  activeTaskId: string | null;
  setActiveTaskId: (id: string | null) => void;
  
  // Reset all app data
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentDate, setCurrentDate] = useState<string>(() => 
    new Date().toISOString().split('T')[0]
  );
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);

  // データベース連携フック
  const {
    tasks: dbTasks,
    taskGroups: dbTaskGroups,
    rewards: dbRewards,
    gachaHistory: dbGachaHistory,
    userStats: dbUserStats,
    isLoading,
    createTask,
    updateTask: dbUpdateTask,
    deleteTask: dbDeleteTask,
    createTaskGroup,
    createReward,
    updateUserStats: dbUpdateUserStats,
    createGachaHistory,
  } = useDatabase();

  // デフォルトデータの使用
  const tasks = dbTasks || [];
  const taskGroups = dbTaskGroups || [];
  const rewards = dbRewards || [];
  const gachaHistory = dbGachaHistory || [];
  const userStats = dbUserStats || {
    streak: 0,
    gachaThreshold: 80,
    weeklyData: [],
    gachaDay: 0,
    lastGachaDayChange: undefined,
    showGachaDayChangeWarning: true,
    lastThresholdChange: undefined,
    showThresholdChangeWarning: true,
    gachaCount: 1,
    maxGachaCount: 1,
    lastGachaCountChange: undefined,
    showGachaCountChangeWarning: true,
    gachaMode: 'fixed',
    lastGachaModeChange: undefined,
    showGachaModeChangeWarning: true,
    maxDiceValue: 6,
    hasDiceRolled: false,
    lastDiceRoll: undefined,
  };
  const achievements = DEFAULT_ACHIEVEMENTS;

  // Task functions
  const addTask = useCallback(async (task: Omit<TaskLocal, 'id'>) => {
    await createTask(task);
  }, [createTask]);

  const updateTask = useCallback(async (id: string, updates: Partial<TaskLocal>) => {
    await dbUpdateTask(id, updates);
  }, [dbUpdateTask]);

  const deleteTask = useCallback(async (id: string, deleteRelated?: boolean) => {
    if (deleteRelated) {
      const relatedTasks = tasks.filter(task => task.parentTaskId === id);
      for (const relatedTask of relatedTasks) {
        await dbDeleteTask(relatedTask.id);
      }
    }
    await dbDeleteTask(id);
  }, [dbDeleteTask, tasks]);

  const completeTask = useCallback(async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (task) {
      await updateTask(id, { 
        isCompleted: true,
        completedAt: new Date().toISOString()
      });
    }
  }, [tasks, updateTask]);

  const uncompleteTask = useCallback(async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (task) {
      await updateTask(id, { 
        isCompleted: false,
        completedAt: undefined
      });
    }
  }, [tasks, updateTask]);

  const moveTaskUp = useCallback(async (id: string) => {
    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex > 0) {
      const reorderedTasks = [...tasks];
      [reorderedTasks[taskIndex], reorderedTasks[taskIndex - 1]] = 
      [reorderedTasks[taskIndex - 1], reorderedTasks[taskIndex]];
      
      await updateTask(reorderedTasks[taskIndex].id, { order: taskIndex });
      await updateTask(reorderedTasks[taskIndex - 1].id, { order: taskIndex - 1 });
    }
  }, [tasks, updateTask]);

  const moveTaskDown = useCallback(async (id: string) => {
    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex < tasks.length - 1) {
      const reorderedTasks = [...tasks];
      [reorderedTasks[taskIndex], reorderedTasks[taskIndex + 1]] = 
      [reorderedTasks[taskIndex + 1], reorderedTasks[taskIndex]];
      
      await updateTask(reorderedTasks[taskIndex].id, { order: taskIndex });
      await updateTask(reorderedTasks[taskIndex + 1].id, { order: taskIndex + 1 });
    }
  }, [tasks, updateTask]);

  const reorderTasks = useCallback(async (newTasks: TaskLocal[]) => {
    for (let i = 0; i < newTasks.length; i++) {
      await updateTask(newTasks[i].id, { order: i });
    }
  }, [updateTask]);

  const getTodayTasks = useCallback(() => {
    return tasks.filter(task => task.date === currentDate);
  }, [tasks, currentDate]);

  // Task Group functions
  const addTaskGroup = useCallback(async (group: Omit<TaskGroupLocal, 'id'>) => {
    await createTaskGroup(group);
  }, [createTaskGroup]);

  const updateTaskGroup = useCallback(async (id: string, updates: Partial<TaskGroupLocal>) => {
    // Note: この機能はデータベースに実装が必要
    console.warn('updateTaskGroup is not implemented in database layer');
  }, []);

  const deleteTaskGroup = useCallback(async (id: string) => {
    // Note: この機能はデータベースに実装が必要
    console.warn('deleteTaskGroup is not implemented in database layer');
  }, []);

  // Reward functions
  const addReward = useCallback(async (reward: Omit<RewardLocal, 'id'>) => {
    await createReward(reward);
  }, [createReward]);

  const updateReward = useCallback(async (id: string, updates: Partial<RewardLocal>) => {
    // Note: この機能はデータベースに実装が必要
    console.warn('updateReward is not implemented in database layer');
  }, []);

  const deleteReward = useCallback(async (id: string) => {
    // Note: この機能はデータベースに実装が必要
    console.warn('deleteReward is not implemented in database layer');
  }, []);

  const getAvailableRewards = useCallback(() => {
    return rewards.filter(reward => !reward.usedInTask);
  }, [rewards]);

  // Gacha functions
  const addGachaHistory = useCallback(async (history: Omit<GachaHistoryLocal, 'id'>) => {
    await createGachaHistory(history);
  }, [createGachaHistory]);

  const performGacha = useCallback(() => {
    const availableRewards = getAvailableRewards();
    if (availableRewards.length === 0) return null;

    const randomIndex = Math.floor(Math.random() * availableRewards.length);
    return availableRewards[randomIndex];
  }, [getAvailableRewards]);

  const useGachaCount = useCallback(async () => {
    if (userStats.gachaCount <= 0) return false;
    await dbUpdateUserStats({ gachaCount: userStats.gachaCount - 1 });
    return true;
  }, [userStats.gachaCount, dbUpdateUserStats]);

  // User Stats functions
  const updateUserStatsLocal = useCallback(async (updates: Partial<UserStatsLocal>) => {
    await dbUpdateUserStats(updates);
  }, [dbUpdateUserStats]);

  // Gacha configuration functions
  const changeGachaThreshold = useCallback((newThreshold: number) => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastThresholdChange;
    
    if (lastChange) {
      const lastChangeDate = dateUtils.parseDate(lastChange);
      const todayDate = dateUtils.parseDate(today);
      const daysDiff = Math.floor((todayDate.getTime() - lastChangeDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff < 7) {
        return false;
      }
    }
    
    updateUserStatsLocal({
      gachaThreshold: newThreshold,
      lastThresholdChange: today
    });
    return true;
  }, [userStats.lastThresholdChange, updateUserStatsLocal]);

  const canChangeGachaThreshold = useMemo(() => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastThresholdChange;
    
    if (!lastChange) return true;
    
    const lastChangeDate = dateUtils.parseDate(lastChange);
    const todayDate = dateUtils.parseDate(today);
    const daysDiff = Math.floor((todayDate.getTime() - lastChangeDate.getTime()) / (1000 * 60 * 60 * 24));
    
    return daysDiff >= 7;
  }, [userStats.lastThresholdChange]);

  const changeGachaDay = useCallback(async (newDay: number) => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastGachaDayChange;
    
    if (lastChange && dateUtils.getDaysDifference(lastChange, today) < 14) {
      return false;
    }
    
    await updateUserStatsLocal({
      gachaDay: newDay,
      lastGachaDayChange: today
    });
    return true;
  }, [userStats.lastGachaDayChange, updateUserStatsLocal]);

  const canChangeGachaDay = useMemo(() => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastGachaDayChange;
    return !lastChange || dateUtils.getDaysDifference(lastChange, today) >= 14;
  }, [userStats.lastGachaDayChange]);

  const changeGachaCount = useCallback(async (newCount: number) => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastGachaCountChange;
    
    if (lastChange && dateUtils.getDaysDifference(lastChange, today) < 7) {
      return false;
    }
    
    await updateUserStatsLocal({
      maxGachaCount: newCount,
      lastGachaCountChange: today
    });
    return true;
  }, [userStats.lastGachaCountChange, updateUserStatsLocal]);

  const canChangeGachaCount = useMemo(() => {
    const today = dateUtils.getToday();
    const lastChange = userStats.lastGachaCountChange;
    return !lastChange || dateUtils.getDaysDifference(lastChange, today) >= 7;
  }, [userStats.lastGachaCountChange]);

  const changeGachaMode = useCallback(async (newMode: 'fixed' | 'random') => {
    const today = dateUtils.getToday();
    const gachaDay = dateUtils.getGachaDay(userStats.gachaDay);
    
    if (userStats.gachaCount < userStats.maxGachaCount && today === gachaDay) {
      return false;
    }
    
    await updateUserStatsLocal({
      gachaMode: newMode,
      lastGachaModeChange: today
    });
    return true;
  }, [userStats, updateUserStatsLocal]);

  const canChangeGachaMode = useMemo(() => {
    const today = dateUtils.getToday();
    const gachaDay = dateUtils.getGachaDay(userStats.gachaDay);
    return userStats.gachaCount >= userStats.maxGachaCount || today !== gachaDay;
  }, [userStats]);

  const rollDice = useCallback(async () => {
    const today = dateUtils.getToday();
    const result = Math.floor(Math.random() * userStats.maxDiceValue) + 1;
    
    await updateUserStatsLocal({
      gachaCount: result,
      hasDiceRolled: true,
      lastDiceRoll: today
    });
    
    return result;
  }, [userStats.maxDiceValue, updateUserStatsLocal]);

  const canRollDice = useMemo(() => {
    return userStats.gachaMode === 'random' && !userStats.hasDiceRolled;
  }, [userStats.gachaMode, userStats.hasDiceRolled]);

  const changeDiceValue = useCallback(async (newValue: number) => {
    await updateUserStatsLocal({ maxDiceValue: newValue });
    return true;
  }, [updateUserStatsLocal]);

  const canRollDiceToday = useMemo(() => {
    const today = dateUtils.getToday();
    const gachaDay = dateUtils.getGachaDay(userStats.gachaDay);
    return today === gachaDay && canRollDice;
  }, [userStats.gachaDay, canRollDice]);

  // Weekly stats calculation
  const weeklyData = useMemo(() => {
    return userStats.weeklyData || [];
  }, [userStats.weeklyData]);

  const weeklyAverageCompletionRate = useMemo(() => {
    if (weeklyData.length === 0) return 0;
    const sum = weeklyData.reduce((total, day) => total + day.completionRate, 0);
    return Math.round(sum / weeklyData.length);
  }, [weeklyData]);

  const daysUntilGacha = useMemo(() => {
    const today = dateUtils.getToday();
    const nextGachaDay = dateUtils.getNextGachaDay(userStats.gachaDay);
    return dateUtils.getDaysDifference(today, nextGachaDay);
  }, [userStats.gachaDay]);

  const gachaWeekDateRange = useMemo(() => {
    const today = dateUtils.getToday();
    const { start, end } = dateUtils.getGachaWeekDateRange(userStats.gachaDay, today);
    return { start, end };
  }, [userStats.gachaDay]);

  // Achievement functions
  const updateAchievement = useCallback((id: string, updates: Partial<AchievementLocal>) => {
    // Note: アチーブメントはローカルのままで実装
    console.warn('updateAchievement is using local state');
  }, []);

  const getUnlockedAchievements = useCallback(() => {
    return achievements.filter(achievement => achievement.isUnlocked);
  }, [achievements]);

  // Reset function
  const resetAllData = useCallback(async () => {
    // Note: この機能はデータベースに実装が必要
    console.warn('resetAllData is not implemented in database layer');
    setActiveTaskId(null);
  }, []);

  const contextValue: AppContextType = {
    // Current date
    currentDate,
    setCurrentDate,
    
    // Tasks
    tasks,
    addTask,
    updateTask,
    deleteTask,
    completeTask,
    uncompleteTask,
    moveTaskUp,
    moveTaskDown,
    reorderTasks,
    getTodayTasks,
    
    // Task Groups
    taskGroups,
    addTaskGroup,
    updateTaskGroup,
    deleteTaskGroup,
    
    // Rewards
    rewards,
    addReward,
    updateReward,
    deleteReward,
    getAvailableRewards,
    
    // Gacha
    gachaHistory,
    addGachaHistory,
    performGacha,
    useGachaCount,
    changeGachaThreshold,
    canChangeGachaThreshold,
    changeGachaDay,
    canChangeGachaDay,
    changeGachaCount,
    canChangeGachaCount,
    changeGachaMode,
    canChangeGachaMode,
    rollDice,
    canRollDice,
    changeDiceValue,
    canRollDiceToday,
    
    // User Stats
    userStats,
    updateUserStats: updateUserStatsLocal,
    weeklyData,
    weeklyAverageCompletionRate,
    daysUntilGacha,
    gachaWeekDateRange,
    
    // Achievements
    achievements,
    updateAchievement,
    getUnlockedAchievements,
    
    // Active Task for Timer
    activeTaskId,
    setActiveTaskId,
    
    // Reset all app data
    resetAllData,
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};