import React, { createContext, useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { useAuth } from '@/hooks/use-auth';
import { useDatabaseSync } from '@/hooks/use-database-sync';
import { 
  TaskLocal, 
  TaskGroupLocal, 
  RewardLocal, 
  GachaHistoryLocal, 
  UserStatsLocal,
  AchievementLocal,
  RecurrencePattern
} from '@shared/schema';
import { DEFAULT_TASK_GROUPS, DEFAULT_REWARDS, DEFAULT_ACHIEVEMENTS } from '@/lib/constants';
import { generateId, getCompletionRate } from '@/lib/utils';
import * as dateUtils from '@/lib/dates';

interface AppContextType {
  // Current date
  currentDate: string;
  setCurrentDate: (date: string) => void;
  
  // Tasks
  tasks: TaskLocal[];
  addTask: (task: Omit<TaskLocal, 'id'>) => void;
  updateTask: (id: string, updates: Partial<TaskLocal>) => void;
  deleteTask: (id: string, deleteRelated?: boolean) => void;
  completeTask: (id: string) => void;
  uncompleteTask: (id: string) => void;
  moveTaskUp: (id: string) => void;
  moveTaskDown: (id: string) => void;
  reorderTasks: (tasks: TaskLocal[]) => void;
  tasksForCurrentDate: TaskLocal[];
  completedTasksForCurrentDate: TaskLocal[];
  completionRate: number;
  
  // Task Groups
  taskGroups: TaskGroupLocal[];
  addTaskGroup: (group: Omit<TaskGroupLocal, 'id'>) => void;
  updateTaskGroup: (id: string, updates: Partial<TaskGroupLocal>) => void;
  deleteTaskGroup: (id: string) => void;
  
  // Rewards
  rewards: RewardLocal[];
  addReward: (reward: Omit<RewardLocal, 'id'>) => void;
  updateReward: (id: string, updates: Partial<RewardLocal>) => void;
  deleteReward: (id: string) => void;
  
  // Gacha
  gachaHistory: GachaHistoryLocal[];
  addGachaHistory: (history: Omit<GachaHistoryLocal, 'id'>) => void;
  updateGachaHistory: (id: string, updates: Partial<GachaHistoryLocal>) => void;
  getGachaHistoryByDate: (date: string) => GachaHistoryLocal | undefined;
  getCollectedRewards: () => RewardLocal[];
  canGachaThisWeek: boolean;
  gachaDay: number; // 0=日曜, 1=月曜, ... 6=土曜
  changeGachaDay: (newDay: number) => boolean; // 返り値: 変更できたかどうか
  canChangeGachaDay: boolean; // 2週間以内に変更していなければtrue
  changeThreshold: (newThreshold: number) => boolean; // 返り値: 変更できたかどうか
  canChangeThreshold: boolean; // 1週間以内に変更していなければtrue
  changeGachaCount: (newCount: number) => boolean; // 返り値: 変更できたかどうか
  canChangeGachaCount: boolean; // 1週間以内に変更していなければtrue
  changeGachaMode: (newMode: 'fixed' | 'random') => boolean; // 返り値: 変更できたかどうか
  canChangeGachaMode: boolean; // ガチャモードを変更できるかどうか
  rollDice: () => number; // サイコロを振る関数、出目を返す
  canRollDice: boolean; // サイコロを振れるかどうか
  changeDiceValue: (newValue: number) => boolean; // サイコロの最大値を変更する
  canRollDiceToday: boolean; // 今日サイコロを振れるかどうか
  
  // User Stats
  userStats: UserStatsLocal;
  updateUserStats: (updates: Partial<UserStatsLocal>) => void;
  weeklyData: {
    date: string;
    completionRate: number;
  }[];
  weeklyAverageCompletionRate: number;
  daysUntilGacha: number;
  gachaWeekDateRange: {
    start: string;
    end: string;
  };
  
  // Achievements
  achievements: AchievementLocal[];
  updateAchievement: (id: string, updates: Partial<AchievementLocal>) => void;
  getUnlockedAchievements: () => AchievementLocal[];
  
  // Active Task for Timer
  activeTaskId: string | null;
  setActiveTaskId: (id: string | null) => void;
  
  // Reset all app data
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const databaseSync = useDatabaseSync();
  
  // Set up state with localStorage persistence
  const [currentDate, setCurrentDate] = useLocalStorage<string>('currentDate', dateUtils.getToday());
  const [localTasks, setLocalTasks] = useLocalStorage<TaskLocal[]>('tasks', []);
  const [localTaskGroups, setLocalTaskGroups] = useLocalStorage<TaskGroupLocal[]>('taskGroups', DEFAULT_TASK_GROUPS);
  const [localRewards, setLocalRewards] = useLocalStorage<RewardLocal[]>('rewards', DEFAULT_REWARDS);
  const [localGachaHistory, setLocalGachaHistory] = useLocalStorage<GachaHistoryLocal[]>('gachaHistory', []);
  
  // ログイン時にデータベースからデータを同期、ローカルデータを優先してレスポンシブなUIを実現
  const tasks = localTasks;
  const taskGroups = localTaskGroups;
  const rewards = localRewards;
  const gachaHistory = localGachaHistory;
  
  // ユーザーがログインしたときにデータベースからデータを一度だけ同期
  const [hasInitialSync, setHasInitialSync] = React.useState(false);
  
  React.useEffect(() => {
    if (user && databaseSync && !databaseSync.isLoading && !hasInitialSync) {
      // データベースにデータがある場合のみ、ローカルストレージを上書き
      if (Array.isArray(databaseSync.tasks) && databaseSync.tasks.length > 0) {
        setLocalTasks(databaseSync.tasks);
      }
      if (Array.isArray(databaseSync.taskGroups) && databaseSync.taskGroups.length > 0) {
        setLocalTaskGroups(databaseSync.taskGroups);
      }
      if (Array.isArray(databaseSync.rewards) && databaseSync.rewards.length > 0) {
        setLocalRewards(databaseSync.rewards);
      }
      if (Array.isArray(databaseSync.gachaHistory) && databaseSync.gachaHistory.length > 0) {
        setLocalGachaHistory(databaseSync.gachaHistory);
      }
      setHasInitialSync(true);
    }
  }, [user, databaseSync.isLoading, hasInitialSync]);
  
  // ログアウト時に同期フラグをリセット
  React.useEffect(() => {
    if (!user) {
      setHasInitialSync(false);
    }
  }, [user]);

  // Helper functions for updating data - ローカルストレージのみ更新（複製を防ぐ）
  const setTasks = (updater: TaskLocal[] | ((prev: TaskLocal[]) => TaskLocal[])) => {
    // Always update local storage for immediate UI response
    setLocalTasks(updater);
  };
  
  const setTaskGroups = (updater: TaskGroupLocal[] | ((prev: TaskGroupLocal[]) => TaskGroupLocal[])) => {
    if (user) {
      const newGroups = typeof updater === 'function' ? updater(localTaskGroups) : updater;
      setLocalTaskGroups(newGroups);
    } else {
      setLocalTaskGroups(updater);
    }
  };
  
  const setRewards = (updater: RewardLocal[] | ((prev: RewardLocal[]) => RewardLocal[])) => {
    if (user) {
      const newRewards = typeof updater === 'function' ? updater(localRewards) : updater;
      setLocalRewards(newRewards);
    } else {
      setLocalRewards(updater);
    }
  };
  
  const setGachaHistory = (updater: GachaHistoryLocal[] | ((prev: GachaHistoryLocal[]) => GachaHistoryLocal[])) => {
    if (user) {
      const newHistory = typeof updater === 'function' ? updater(localGachaHistory) : updater;
      setLocalGachaHistory(newHistory);
    } else {
      setLocalGachaHistory(updater);
    }
  };
  const [userStats, setUserStats] = useLocalStorage<UserStatsLocal>('userStats', {
    streak: 0,
    gachaThreshold: 80,
    weeklyData: [],
    gachaDay: 0, // デフォルトは日曜日（0）
    showGachaDayChangeWarning: true, // デフォルトでは確認メッセージを表示する
    showThresholdChangeWarning: true, // デフォルトでは確認メッセージを表示する
    gachaCount: 1, // 現在の残りガチャ回数
    maxGachaCount: 1, // 週に獲得できる最大ガチャ回数（設定値）
    showGachaCountChangeWarning: true, // デフォルトでは確認メッセージを表示する
    lastGachaDayChange: undefined,
    lastThresholdChange: undefined,
    lastGachaCountChange: undefined,
    gachaMode: 'fixed', // デフォルトは固定値モード
    showGachaModeChangeWarning: true, // デフォルトでは確認メッセージを表示する
    lastGachaModeChange: undefined,
    maxDiceValue: 6, // サイコロの最大値（ランダムモード用）
    hasDiceRolled: false, // 今週サイコロを振ったかどうか（ランダムモード用）
    lastDiceRoll: undefined, // 最後にサイコロを振った日
  });
  const [achievements, setAchievements] = useLocalStorage<AchievementLocal[]>('achievements', DEFAULT_ACHIEVEMENTS);
  
  // UI state
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  
  // Computed values
  const tasksForCurrentDate = tasks.filter(task => dateUtils.isSameDate(task.date, currentDate));
  const completedTasksForCurrentDate = tasksForCurrentDate.filter(task => task.isCompleted);
  const completionRate = getCompletionRate(tasksForCurrentDate.length, completedTasksForCurrentDate.length);
  
  // Task functions
  const addTask = useCallback((task: Omit<TaskLocal, 'id'>) => {
    const taskId = generateId();
    const newTask: TaskLocal = {
      ...task,
      id: taskId,
    };
    
    // Create an array to hold all tasks to be added (the main task and any recurring tasks)
    const tasksToAdd: TaskLocal[] = [newTask];
    
    // If the task is recurring and has a recurrence pattern, generate future tasks
    if (task.isRecurring && task.recurrencePattern) {
      const taskDate = dateUtils.parseDate(task.date);
      const recurringDates = dateUtils.generateRecurringDates(
        taskDate,
        task.recurrencePattern,
        task.recurrencePattern.occurrences || 10
      );
      
      // Create a task for each generated date
      recurringDates.forEach(date => {
        const recurringTask: TaskLocal = {
          ...task,
          id: generateId(),
          date,
          isCompleted: false, // Future tasks are not completed
          parentTaskId: taskId, // Link to the parent task
        };
        tasksToAdd.push(recurringTask);
      });
    }
    
    // Add all the tasks
    // Add tasks to appropriate storage
    setTasks(prev => [...prev, ...tasksToAdd]);
    
    // If user is logged in, also sync to database
    if (user) {
      try {
        for (const taskToAdd of tasksToAdd) {
          databaseSync.createTask(taskToAdd).catch(error => {
            console.error('Failed to sync task to database:', error);
          });
        }
      } catch (error) {
        console.error('Database sync error:', error);
      }
    }
    
    // Check if this is the first task completion (Achievement)
    if (task.isCompleted) {
      const firstTaskAchievement = achievements.find(a => a.id === "1");
      if (firstTaskAchievement && !firstTaskAchievement.isUnlocked) {
        updateAchievement("1", { 
          isUnlocked: true, 
          unlockedAt: new Date().toISOString() 
        });
      }
    }
    
    return newTask; // Return the newly created task (mainly for the parent recurring task)
  }, [setTasks, achievements]);
  
  const updateTask = useCallback((id: string, updates: Partial<TaskLocal>) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, ...updates } : task
    ));
  }, [setTasks]);
  
  const deleteTask = useCallback((id: string, deleteRelated: boolean = false) => {
    // まず、タスクの情報を取得
    const taskToDelete = tasks.find(task => task.id === id);
    
    if (!taskToDelete) {
      return; // タスクが見つからない場合は何もしない
    }
    
    if (deleteRelated) {
      // 関連する周期タスクも削除（親タスクの場合は子タスク、子タスクの場合は同じ親を持つタスク）
      
      if (taskToDelete.parentTaskId) {
        // これは子タスク（周期タスクの1つ）の場合
        // 親タスクと、同じ親を持つすべての子タスクを削除
        const parentId = taskToDelete.parentTaskId;
        setTasks(prev => prev.filter(task => 
          task.id !== id && 
          task.id !== parentId && 
          task.parentTaskId !== parentId
        ));
      } else if (taskToDelete.isRecurring) {
        // これは親タスク（周期タスクのオリジン）の場合
        // このタスクとその子タスクをすべて削除
        setTasks(prev => prev.filter(task => 
          task.id !== id && 
          task.parentTaskId !== id
        ));
      } else {
        // 通常のタスク（周期ではない）の場合は、そのタスクだけを削除
        setTasks(prev => prev.filter(task => task.id !== id));
      }
    } else {
      // 指定されたタスクのみを削除
      setTasks(prev => prev.filter(task => task.id !== id));
    }
  }, [tasks, setTasks]);
  
  const completeTask = useCallback((id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { 
        ...task, 
        isCompleted: true,
        completedAt: new Date().toISOString() // 完了時刻を記録
      } : task
    ));
    
    // Check for first task completion achievement
    const firstTaskAchievement = achievements.find(a => a.id === "1");
    if (firstTaskAchievement && !firstTaskAchievement.isUnlocked) {
      updateAchievement("1", { 
        isUnlocked: true, 
        unlockedAt: new Date().toISOString() 
      });
    }
    
    // Check for perfect day achievement
    const tasksThatDay = tasks.filter(task => dateUtils.isSameDate(task.date, currentDate));
    const tasksThatDayCount = tasksThatDay.length;
    const completedTasksCount = tasksThatDay.filter(task => task.isCompleted || task.id === id).length;
    
    if (tasksThatDayCount > 0 && completedTasksCount === tasksThatDayCount) {
      const perfectDayAchievement = achievements.find(a => a.id === "4");
      if (perfectDayAchievement && !perfectDayAchievement.isUnlocked) {
        updateAchievement("4", { 
          isUnlocked: true, 
          unlockedAt: new Date().toISOString() 
        });
      }
    }
    
    // Update streak logic
    if (dateUtils.isSameDate(currentDate, dateUtils.getToday())) {
      const didCompleteTaskYesterday = userStats.streak > 0;
      if (didCompleteTaskYesterday) {
        // Continue streak
        setUserStats(prev => ({
          ...prev,
          streak: prev.streak + 1
        }));
        
        // Check for streak achievements
        if (userStats.streak + 1 === 3) {
          const threeDayAchievement = achievements.find(a => a.id === "2");
          if (threeDayAchievement && !threeDayAchievement.isUnlocked) {
            updateAchievement("2", { 
              isUnlocked: true, 
              unlockedAt: new Date().toISOString() 
            });
          }
        }
        
        if (userStats.streak + 1 === 7) {
          const sevenDayAchievement = achievements.find(a => a.id === "6");
          if (sevenDayAchievement && !sevenDayAchievement.isUnlocked) {
            updateAchievement("6", { 
              isUnlocked: true, 
              unlockedAt: new Date().toISOString() 
            });
          }
        }
      } else {
        // Start new streak
        setUserStats(prev => ({
          ...prev,
          streak: 1
        }));
      }
    }
  }, [setTasks, tasks, currentDate, userStats, achievements, setUserStats]);
  
  const uncompleteTask = useCallback((id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { 
        ...task, 
        isCompleted: false,
        completedAt: undefined // 完了時刻をクリア
      } : task
    ));
  }, [setTasks]);
  
  // タスクを上に移動する (順序を前に)
  const moveTaskUp = useCallback((id: string) => {
    setTasks(prev => {
      // 現在日付のタスクのみを対象に順序を調整
      const currentDateTasks = prev.filter(task => dateUtils.isSameDate(task.date, currentDate));
      
      // order プロパティを持つタスクと持たないタスクに分ける
      const tasksWithOrder = currentDateTasks.filter(task => typeof task.order === 'number');
      const tasksWithoutOrder = currentDateTasks.filter(task => typeof task.order !== 'number');
      
      // 最初にタスクに順番がない場合は、すべてのタスクに順番を設定
      if (tasksWithOrder.length === 0) {
        // 完了状態でソートしてインデックスを割り当て
        const sortedTasks = [...currentDateTasks].sort((a, b) => 
          a.isCompleted === b.isCompleted ? 0 : (a.isCompleted ? 1 : -1)
        );
        
        // すべてのタスクに順序を割り当て
        sortedTasks.forEach((task, index) => {
          const taskIndex = prev.findIndex(t => t.id === task.id);
          if (taskIndex !== -1) {
            prev[taskIndex] = { ...prev[taskIndex], order: index };
          }
        });
        
        // 対象のタスクを見つけて処理
        const targetIndex = prev.findIndex(task => task.id === id);
        if (targetIndex > 0) {
          // 前のタスクを見つける (同じ日付のタスクのみを対象)
          const prevTasks = prev.filter((task, idx) => 
            idx < targetIndex && dateUtils.isSameDate(task.date, currentDate)
          );
          
          if (prevTasks.length > 0) {
            const prevTaskIndex = prev.findIndex(task => task.id === prevTasks[prevTasks.length - 1].id);
            
            // 順序を入れ替え
            const targetOrder = prev[targetIndex].order;
            const prevOrder = prev[prevTaskIndex].order;
            
            prev[targetIndex] = { ...prev[targetIndex], order: prevOrder };
            prev[prevTaskIndex] = { ...prev[prevTaskIndex], order: targetOrder };
          }
        }
        
        return [...prev];
      }
      
      // すでにorderがあるタスクをソート
      const sortedTasksWithOrder = [...tasksWithOrder].sort((a, b) => {
        // 完了状態を優先
        if (a.isCompleted !== b.isCompleted) {
          return a.isCompleted ? 1 : -1;
        }
        // 次に順序
        return (a.order || 0) - (b.order || 0);
      });
      
      // 対象のタスクのインデックスを取得
      const targetTaskIndex = sortedTasksWithOrder.findIndex(task => task.id === id);
      
      // 最初のタスクでなければ移動可能
      if (targetTaskIndex > 0) {
        // 前のタスクと順序を入れ替え
        const targetTask = sortedTasksWithOrder[targetTaskIndex];
        const prevTask = sortedTasksWithOrder[targetTaskIndex - 1];
        
        // prevTask が完了済みの場合は移動不可
        if (prevTask.isCompleted) {
          return prev;
        }
        
        // 実際のtasksリスト内でのインデックスを取得
        const targetIndex = prev.findIndex(task => task.id === targetTask.id);
        const prevIndex = prev.findIndex(task => task.id === prevTask.id);
        
        // 順序を入れ替え
        const targetOrder = targetTask.order;
        const prevOrder = prevTask.order;
        
        prev[targetIndex] = { ...prev[targetIndex], order: prevOrder };
        prev[prevIndex] = { ...prev[prevIndex], order: targetOrder };
      }
      
      return [...prev];
    });
  }, [currentDate, setTasks]);
  
  // タスクを下に移動する (順序を後ろに)
  const moveTaskDown = useCallback((id: string) => {
    setTasks(prev => {
      // 現在日付のタスクのみを対象に順序を調整
      const currentDateTasks = prev.filter(task => dateUtils.isSameDate(task.date, currentDate));
      
      // order プロパティを持つタスクと持たないタスクに分ける
      const tasksWithOrder = currentDateTasks.filter(task => typeof task.order === 'number');
      const tasksWithoutOrder = currentDateTasks.filter(task => typeof task.order !== 'number');
      
      // 最初にタスクに順番がない場合は、すべてのタスクに順番を設定
      if (tasksWithOrder.length === 0) {
        // 完了状態でソートしてインデックスを割り当て
        const sortedTasks = [...currentDateTasks].sort((a, b) => 
          a.isCompleted === b.isCompleted ? 0 : (a.isCompleted ? 1 : -1)
        );
        
        // すべてのタスクに順序を割り当て
        sortedTasks.forEach((task, index) => {
          const taskIndex = prev.findIndex(t => t.id === task.id);
          if (taskIndex !== -1) {
            prev[taskIndex] = { ...prev[taskIndex], order: index };
          }
        });
        
        // 対象のタスクを見つけて処理
        const targetIndex = prev.findIndex(task => task.id === id);
        if (targetIndex < prev.length - 1) {
          // 次のタスクを見つける (同じ日付のタスクのみを対象)
          const nextTasks = prev.filter((task, idx) => 
            idx > targetIndex && dateUtils.isSameDate(task.date, currentDate)
          );
          
          if (nextTasks.length > 0) {
            const nextTaskIndex = prev.findIndex(task => task.id === nextTasks[0].id);
            
            // 順序を入れ替え
            const targetOrder = prev[targetIndex].order;
            const nextOrder = prev[nextTaskIndex].order;
            
            prev[targetIndex] = { ...prev[targetIndex], order: nextOrder };
            prev[nextTaskIndex] = { ...prev[nextTaskIndex], order: targetOrder };
          }
        }
        
        return [...prev];
      }
      
      // すでにorderがあるタスクをソート
      const sortedTasksWithOrder = [...tasksWithOrder].sort((a, b) => {
        // 完了状態を優先
        if (a.isCompleted !== b.isCompleted) {
          return a.isCompleted ? 1 : -1;
        }
        // 次に順序
        return (a.order || 0) - (b.order || 0);
      });
      
      // 対象のタスクのインデックスを取得
      const targetTaskIndex = sortedTasksWithOrder.findIndex(task => task.id === id);
      
      // 対象のタスクが完了済みの場合は移動不可
      const targetTask = sortedTasksWithOrder[targetTaskIndex];
      if (targetTask.isCompleted) {
        return prev;
      }
      
      // 最後のタスクでなければ移動可能
      if (targetTaskIndex < sortedTasksWithOrder.length - 1) {
        // 次のタスクと順序を入れ替え
        const nextTask = sortedTasksWithOrder[targetTaskIndex + 1];
        
        // nextTaskが未完了のタスクの場合のみ入れ替え
        if (!nextTask.isCompleted) {
          // 実際のtasksリスト内でのインデックスを取得
          const targetIndex = prev.findIndex(task => task.id === targetTask.id);
          const nextIndex = prev.findIndex(task => task.id === nextTask.id);
          
          // 順序を入れ替え
          const targetOrder = targetTask.order;
          const nextOrder = nextTask.order;
          
          prev[targetIndex] = { ...prev[targetIndex], order: nextOrder };
          prev[nextIndex] = { ...prev[nextIndex], order: targetOrder };
        }
      }
      
      return [...prev];
    });
  }, [currentDate, setTasks]);
  
  // タスク順序の一括更新（ドラッグ＆ドロップで並び替え後）
  const reorderTasks = useCallback((reorderedTasks: TaskLocal[]) => {
    setTasks(prev => {
      // 現在日付のタスクのみ対象とする
      const tasksForUpdate = reorderedTasks.filter(task => 
        dateUtils.isSameDate(task.date, currentDate)
      );
      
      // 完了タスクと未完了タスクを分ける
      const incompleteTasks = tasksForUpdate.filter(task => !task.isCompleted);
      const completedTasks = tasksForUpdate.filter(task => task.isCompleted);
      
      // それぞれのリストに新しい順序（order）を割り当てる
      const updatedIncompleteTasks = incompleteTasks.map((task, index) => ({
        ...task,
        order: index
      }));
      
      // 完了タスクは未完了タスクの後に表示
      const updatedCompletedTasks = completedTasks.map((task, index) => ({
        ...task,
        order: updatedIncompleteTasks.length + index
      }));
      
      // すべての更新対象タスクを結合
      const updatedTasks = [...updatedIncompleteTasks, ...updatedCompletedTasks];
      
      // 元のタスクリストを更新
      return prev.map(task => {
        const updatedTask = updatedTasks.find(t => t.id === task.id);
        return updatedTask || task;
      });
    });
  }, [currentDate, setTasks]);
  
  // Task Groups functions
  const addTaskGroup = useCallback((group: Omit<TaskGroupLocal, 'id'>) => {
    const newGroup: TaskGroupLocal = {
      ...group,
      id: generateId()
    };
    setTaskGroups(prev => [...prev, newGroup]);
  }, [setTaskGroups]);
  
  const updateTaskGroup = useCallback((id: string, updates: Partial<TaskGroupLocal>) => {
    setTaskGroups(prev => prev.map(group => 
      group.id === id ? { ...group, ...updates } : group
    ));
  }, [setTaskGroups]);
  
  const deleteTaskGroup = useCallback((id: string) => {
    setTaskGroups(prev => prev.filter(group => group.id !== id));
  }, [setTaskGroups]);
  
  // Rewards functions
  const addReward = useCallback((reward: Omit<RewardLocal, 'id'>) => {
    const newReward: RewardLocal = {
      ...reward,
      id: generateId()
    };
    setRewards(prev => [...prev, newReward]);
  }, [setRewards]);
  
  const updateReward = useCallback((id: string, updates: Partial<RewardLocal>) => {
    setRewards(prev => prev.map(reward => 
      reward.id === id ? { ...reward, ...updates } : reward
    ));
  }, [setRewards]);
  
  const deleteReward = useCallback((id: string) => {
    setRewards(prev => prev.filter(reward => reward.id !== id));
  }, [setRewards]);
  
  // Gacha functions
  const addGachaHistory = useCallback((history: Omit<GachaHistoryLocal, 'id'>) => {
    const newHistory: GachaHistoryLocal = {
      ...history,
      id: generateId()
    };
    setGachaHistory(prev => [...prev, newHistory]);
    
    // Check for rare reward achievement
    if (history.rewardId) {
      const reward = rewards.find(r => r.id === history.rewardId);
      if (reward && reward.rarity === 3) {
        const rareRewardAchievement = achievements.find(a => a.id === "7");
        if (rareRewardAchievement && !rareRewardAchievement.isUnlocked) {
          updateAchievement("7", { 
            isUnlocked: true, 
            unlockedAt: new Date().toISOString() 
          });
        }
      }
    }
  }, [setGachaHistory, rewards, achievements]);
  
  const getGachaHistoryByDate = useCallback((date: string) => {
    return gachaHistory.find(history => dateUtils.isSameDate(history.date, date));
  }, [gachaHistory]);
  
  const getCollectedRewards = useCallback(() => {
    // 各ガチャ履歴ごとに独自のアイテムを生成するようにします
    return gachaHistory.map(history => {
      // 対応する報酬テンプレートを見つける
      const rewardTemplate = rewards.find(r => r.id === history.rewardId);
      if (!rewardTemplate) return null;
      
      // 履歴IDに基づいた一意のアイテムインスタンスを生成
      return {
        id: history.id, // 履歴IDをアイテムIDとして使用
        title: rewardTemplate.title,
        description: rewardTemplate.description,
        isPenalty: rewardTemplate.isPenalty,
        rarity: rewardTemplate.rarity,
        emoji: rewardTemplate.emoji,
        usedInTask: history.usedInTask, // 履歴にusedInTaskフラグを持たせる
        originalRewardId: rewardTemplate.id, // 元のrewardIdを保持
      };
    }).filter(item => item && !item.usedInTask) as RewardLocal[]; // null項目と使用済みを除外
  }, [gachaHistory, rewards]);
  
  // Update weekly data with today's completion rate and manage streak logic
  useEffect(() => {
    if (dateUtils.isSameDate(currentDate, dateUtils.getToday())) {
      const today = dateUtils.getToday();
      const existingEntry = userStats.weeklyData.find(data => dateUtils.isSameDate(data.date, today));
      
      // 前日を取得
      const yesterday = dateUtils.getPreviousDay(today);
      
      // 前日のタスク
      const yesterdayTasks = tasks.filter(task => dateUtils.isSameDate(task.date, yesterday));
      
      // ストリークのリセットが必要かどうかを確認
      // 前日のタスクが0個または前日のタスクがあるが未完了のタスクがある場合
      const shouldResetStreak = 
        yesterdayTasks.length === 0 || // タスクが0の日
        yesterdayTasks.some(task => !task.isCompleted); // 未完了のタスクがある日
      
      // ストリークのリセットが必要な場合
      if (shouldResetStreak && userStats.streak > 0) {
        setUserStats(prev => ({
          ...prev,
          streak: 0, // ストリークをリセット
          weeklyData: existingEntry
            ? prev.weeklyData.map(data => 
                dateUtils.isSameDate(data.date, today) 
                  ? { ...data, completionRate } 
                  : data
              )
            : [...prev.weeklyData, {
                date: today,
                completionRate
              }]
        }));
      } 
      // 通常のweeklyDataの更新
      else if (!existingEntry) {
        // Add new entry
        setUserStats(prev => ({
          ...prev,
          weeklyData: [...prev.weeklyData, {
            date: today,
            completionRate
          }]
        }));
      } else if (existingEntry.completionRate !== completionRate) {
        // Update existing entry only if completion rate has changed
        setUserStats(prev => ({
          ...prev,
          weeklyData: prev.weeklyData.map(data => 
            dateUtils.isSameDate(data.date, today) 
              ? { ...data, completionRate } 
              : data
          )
        }));
      }
    }
  }, [currentDate, completionRate, setUserStats, tasks]);
  
  // ユーザー統計を更新する関数
  const updateUserStats = useCallback((updates: Partial<UserStatsLocal>) => {
    setUserStats(prev => ({
      ...prev,
      ...updates
    }));
  }, [setUserStats]);

  // ガチャの日にガチャ回数をリセットするための処理
  // （useEffectの使用を避け、代わりにマウント時に実行する関数として実装）
  const resetGachaCountIfNeeded = useCallback(() => {
    const today = new Date();
    const todayStr = dateUtils.getToday();
    const currentDayOfWeek = today.getDay();
    const gachaDaySetting = userStats.gachaDay;
    const isGachaDay = currentDayOfWeek === gachaDaySetting;
    
    if (isGachaDay) {
      // 今日のガチャ履歴
      const todayGachaHistory = gachaHistory.filter(history => dateUtils.isSameDate(history.date, todayStr));
      
      // 最新のガチャ履歴（今日以外）を取得して新しい週かどうかを判断
      const lastGachaHistory = gachaHistory
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .find(h => !dateUtils.isSameDate(h.date, todayStr));
      
      // 前回のガチャ日を取得
      const lastGachaDate = lastGachaHistory?.date;
      
      // 新しい週かどうかを判断
      // 1. 前回のガチャがない、または
      // 2. 前回のガチャ日が7日以上前、または
      // 3. 前回のガチャ日の曜日がガチャ曜日で、今回も同じガチャ曜日（＝1週間経過）
      const isNewWeek = !lastGachaDate || 
        Math.ceil(Math.abs(new Date(todayStr).getTime() - new Date(lastGachaDate).getTime()) / (1000 * 60 * 60 * 24)) >= 7 ||
        (new Date(lastGachaDate).getDay() === gachaDaySetting);
      
      // 設定されている最大回数（最低1回）
      const maxGachaCount = Math.max(1, Math.abs(userStats.maxGachaCount || 1));
        
      // 以下の場合にガチャ回数をリセット
      // 1. 新しい週の場合、または
      // 2. 残りガチャ回数が0以下の場合
      // かつ、今日のガチャ利用回数が設定値より少ない場合
      if ((isNewWeek || userStats.gachaCount <= 0) && todayGachaHistory.length < maxGachaCount) {
        console.log('[ガチャ回数リセット]', {
          前回ガチャ日: lastGachaDate,
          現在日: todayStr,
          新しい週: isNewWeek,
          現在の回数: userStats.gachaCount,
          リセット後の回数: maxGachaCount
        });
        
        // 値が実際に変わる場合のみupdateする
        if (maxGachaCount !== userStats.gachaCount) {
          setUserStats(prev => ({
            ...prev,
            gachaCount: maxGachaCount
          }));
          return true;
        }
      }
    }
    return false;
  }, [gachaHistory, userStats.gachaDay, userStats.gachaCount, userStats.maxGachaCount, setUserStats]);
  
  // 初回マウント時にのみ実行
  useEffect(() => {
    resetGachaCountIfNeeded();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  // Calculate weekly average completion rate
  const weeklyData = userStats.weeklyData;
  
  // Gacha day setup (must be defined before using it)
  const gachaDay = userStats.gachaDay ?? 0; // デフォルトは日曜日(0)
  
  // Get the dates from previous gacha day+1 to current gacha day
  const gachaWeekDates = dateUtils.getGachaWeekDates(new Date(), gachaDay).map(date => dateUtils.formatSimpleDate(date));
  
  // Filter weekly data for the gacha week period
  const currentWeekData = weeklyData.filter(data => 
    gachaWeekDates.includes(data.date)
  );
  
  // Get date range for display purposes
  const [startDate, endDate] = dateUtils.getGachaWeekDateRange(new Date(), gachaDay);
  const gachaWeekDateRange = {
    start: dateUtils.formatSimpleDate(startDate),
    end: dateUtils.formatSimpleDate(endDate)
  };
  
  // Calculate the average completion rate for the current week
  const weeklyAverageCompletionRate = currentWeekData.length > 0
    ? Math.round(currentWeekData.reduce((sum, data) => sum + data.completionRate, 0) / currentWeekData.length)
    : 0;

  // Check if user can change gacha day (less than 2 weeks since last change)
  const canChangeGachaDay = useCallback(() => {
    if (!userStats.lastGachaDayChange) return true;
    
    const lastChangeDate = dateUtils.parseDate(userStats.lastGachaDayChange);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lastChangeDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 14; // 14日以上経過していれば変更可能
  }, [userStats.lastGachaDayChange])();
  
  // Function to change gacha day
  const changeGachaDay = useCallback((newDay: number): boolean => {
    if (newDay === gachaDay) return true; // 同じ曜日を選択した場合は変更なしで成功とみなす
    if (!canChangeGachaDay) return false;
    if (newDay < 0 || newDay > 6) return false;
    
    setUserStats(prev => ({
      ...prev,
      gachaDay: newDay,
      lastGachaDayChange: dateUtils.getToday()
    }));
    
    return true;
  }, [canChangeGachaDay, gachaDay, setUserStats]);
  
  // Check if user can change threshold (less than 1 week since last change)
  const canChangeThreshold = useCallback(() => {
    if (!userStats.lastThresholdChange) return true;
    
    const lastChangeDate = dateUtils.parseDate(userStats.lastThresholdChange);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lastChangeDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 7; // 7日以上経過していれば変更可能
  }, [userStats.lastThresholdChange])();
  
  // Function to change threshold
  const changeThreshold = useCallback((newThreshold: number): boolean => {
    if (newThreshold === userStats.gachaThreshold) return true; // 同じ値を選択した場合は変更なしで成功とみなす
    if (!canChangeThreshold) return false;
    if (newThreshold < 50 || newThreshold > 100) return false;
    
    setUserStats(prev => ({
      ...prev,
      gachaThreshold: newThreshold,
      lastThresholdChange: dateUtils.getToday()
    }));
    
    return true;
  }, [canChangeThreshold, userStats.gachaThreshold, setUserStats]);
  
  // Check if user can change gacha count (less than 1 week since last change)
  const canChangeGachaCount = useCallback(() => {
    if (!userStats.lastGachaCountChange) return true;
    
    const lastChangeDate = dateUtils.parseDate(userStats.lastGachaCountChange);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lastChangeDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 7; // 7日以上経過していれば変更可能
  }, [userStats.lastGachaCountChange])();
  
  // Function to change max gacha count (設定値)
  const changeGachaCount = useCallback((newCount: number): boolean => {
    if (newCount === userStats.maxGachaCount) return true; // 同じ値を選択した場合は変更なしで成功とみなす
    if (!canChangeGachaCount) return false;
    if (newCount < 1 || newCount > 6) return false; // 1回から最大6回まで許可
    
    setUserStats(prev => ({
      ...prev,
      maxGachaCount: newCount,
      // 残りガチャ回数も更新：現在回数が新しい最大値より多かったらキープ、少なかったら新しい最大値にセット
      gachaCount: Math.max(prev.gachaCount, newCount),
      lastGachaCountChange: dateUtils.getToday()
    }));
    
    return true;
  }, [canChangeGachaCount, userStats.maxGachaCount, setUserStats]);
  
  // ガチャモード変更の制限チェック
  const canChangeGachaMode = (() => {
    // モード別の制限チェック
    const currentMode = userStats.gachaMode;
    
    // 固定値モードからランダムモードへの変更制限
    if (currentMode === 'fixed') {
      const today = dateUtils.getToday();
      const todayGachaHistory = gachaHistory.filter(history => dateUtils.isSameDate(history.date, today));
      // 今日ガチャを使用していなければモード変更可能
      if (todayGachaHistory.length === 0) return true;
      return false;
    }
    
    // ランダムモードから固定値モードへの変更制限
    if (currentMode === 'random') {
      // サイコロを振っていない場合のみ変更可能
      return !userStats.hasDiceRolled;
    }
    
    // モード変更の制限期間をチェック（前回変更から1週間経過しているか）
    if (!userStats.lastGachaModeChange) return true;
    
    const lastChangeDate = dateUtils.parseDate(userStats.lastGachaModeChange);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lastChangeDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays >= 7; // 7日以上経過していれば変更可能
  })();
  
  // ガチャモード変更関数
  const changeGachaMode = useCallback((newMode: 'fixed' | 'random'): boolean => {
    if (newMode === userStats.gachaMode) return true; // 同じモードを選択した場合は変更なしで成功とみなす
    if (!canChangeGachaMode) return false;
    
    setUserStats(prev => ({
      ...prev,
      gachaMode: newMode,
      lastGachaModeChange: dateUtils.getToday(),
      // ランダムモードに変更する場合は、サイコロを振っていない状態にリセット
      hasDiceRolled: newMode === 'random' ? false : prev.hasDiceRolled,
    }));
    
    return true;
  }, [canChangeGachaMode, userStats.gachaMode, setUserStats]);
  
  // サイコロの最大値変更関数
  const changeDiceValue = useCallback((newValue: number): boolean => {
    if (newValue === userStats.maxDiceValue) return true; // 同じ値を選択した場合は変更なしで成功とみなす
    if (newValue < 1 || newValue > 10) return false; // 1から10までの値のみ許可
    
    setUserStats(prev => ({
      ...prev,
      maxDiceValue: newValue
    }));
    
    return true;
  }, [userStats.maxDiceValue, setUserStats]);
  
  // 今日サイコロを振れるかどうか判定
  const canRollDiceToday = (() => {
    // ランダムモードでなければサイコロは振れない
    if (userStats.gachaMode !== 'random') return false;
    
    const today = new Date();
    const currentDayOfWeek = today.getDay();
    const targetGachaDay = gachaDay;
    
    // 指定されたガチャ曜日でなければサイコロは振れない
    if (currentDayOfWeek !== targetGachaDay) return false;
    
    // すでにサイコロを振っていたら、もう振れない
    if (userStats.hasDiceRolled) return false;
    
    return true;
  })();
  
  // サイコロを振る関数
  const rollDice = useCallback((): number => {
    if (!canRollDiceToday) return 0;
    
    // サイコロを振る（1〜maxDiceValue）
    const diceResult = Math.floor(Math.random() * userStats.maxDiceValue) + 1;
    
    // サイコロの結果をステートに保存
    setUserStats(prev => ({
      ...prev,
      gachaCount: diceResult, // 出目の数だけガチャ回数を設定
      hasDiceRolled: true, // サイコロを振った状態にする
      lastDiceRoll: dateUtils.getToday() // 最後にサイコロを振った日を記録
    }));
    
    return diceResult;
  }, [canRollDiceToday, userStats.maxDiceValue, setUserStats]);
  
  // サイコロを振れるかどうか（ランダムモードかつ今週まだ振っていないか）
  const canRollDice = userStats.gachaMode === 'random' && !userStats.hasDiceRolled;
  
  // Days until next gacha
  const daysUntilGacha = (() => {
    const today = new Date();
    const currentDayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const targetGachaDay = gachaDay;
    
    // 今日がガチャの日で、まだガチャ回数が残っている場合は0日（今日引ける）
    if (currentDayOfWeek === targetGachaDay && userStats.gachaCount > 0) {
      return 0;
    }
    // 現在の曜日と目標の曜日の差を計算
    else if (currentDayOfWeek === targetGachaDay) {
      return 7; // 今日がガチャの日だが回数がないなら次回は7日後
    } else if (currentDayOfWeek < targetGachaDay) {
      return targetGachaDay - currentDayOfWeek;
    } else {
      return 7 - (currentDayOfWeek - targetGachaDay);
    }
  })();
  
  // Check if can do gacha this week
  const canGachaThisWeek = (() => {
    const today = new Date();
    const currentDayOfWeek = today.getDay();
    const targetGachaDay = gachaDay;
    
    // 今日がガチャの日かどうかチェック
    if (currentDayOfWeek !== targetGachaDay) {
      return false;
    }
    
    // 今週のガチャ日を計算
    const gachaDate = new Date(today);
    const gachaDateStr = dateUtils.formatSimpleDate(gachaDate);
    
    // ガチャ回数が残っているかチェック
    if (userStats.gachaCount <= 0) {
      return false;
    }
    
    // ガチャ日で、かつガチャ回数が残っている場合はtrue
    return true;
  })();
  
  // Achievement functions
  const updateAchievement = useCallback((id: string, updates: Partial<AchievementLocal>) => {
    setAchievements(prev => prev.map(achievement => 
      achievement.id === id ? { ...achievement, ...updates } : achievement
    ));
  }, [setAchievements]);
  
  const getUnlockedAchievements = useCallback(() => {
    return achievements.filter(achievement => achievement.isUnlocked);
  }, [achievements]);
  

  
  // ガチャ履歴を更新するメソッド
  const updateGachaHistory = useCallback((id: string, updates: Partial<GachaHistoryLocal>) => {
    setGachaHistory(prev => prev.map(history => 
      history.id === id ? { ...history, ...updates } : history
    ));
  }, [setGachaHistory]);

  // 全データをリセットする関数
  const resetAllData = useCallback(() => {
    // タスク関連の情報をリセット
    setTasks([]);
    // タスクグループをデフォルトに戻す
    setTaskGroups(DEFAULT_TASK_GROUPS);
    // 報酬をデフォルトに戻す
    setRewards(DEFAULT_REWARDS);
    // ガチャ履歴をリセット
    setGachaHistory([]);
    // 実績をデフォルトに戻す
    setAchievements(DEFAULT_ACHIEVEMENTS);
    // ユーザー統計をリセット
    setUserStats({
      streak: 0,
      gachaThreshold: 80,
      weeklyData: [],
      gachaDay: 0, // デフォルトは日曜日（0）
      showGachaDayChangeWarning: true,
      showThresholdChangeWarning: true,
      gachaCount: 1, // 現在のガチャ残り回数
      maxGachaCount: 1, // 週に獲得できる最大ガチャ回数（設定値）
      showGachaCountChangeWarning: true,
      lastGachaDayChange: undefined,
      lastThresholdChange: undefined,
      lastGachaCountChange: undefined,
      gachaMode: 'fixed', // デフォルトは固定値モード
      showGachaModeChangeWarning: true, // デフォルトでは確認メッセージを表示する
      lastGachaModeChange: undefined,
      maxDiceValue: 6, // サイコロの最大値（ランダムモード用）
      hasDiceRolled: false, // 今週サイコロを振ったかどうか（ランダムモード用）
      lastDiceRoll: undefined, // 最後にサイコロを振った日
    });
    // アクティブなタスクをクリア
    setActiveTaskId(null);
  }, [setTasks, setTaskGroups, setRewards, setGachaHistory, setAchievements, setUserStats]);

  // Context value
  const value = {
    // Current date
    currentDate,
    setCurrentDate,
    
    // Tasks
    tasks,
    addTask,
    updateTask,
    deleteTask,
    completeTask,
    uncompleteTask,
    moveTaskUp,
    moveTaskDown,
    reorderTasks,
    tasksForCurrentDate,
    completedTasksForCurrentDate,
    completionRate,
    
    // Task Groups
    taskGroups,
    addTaskGroup,
    updateTaskGroup,
    deleteTaskGroup,
    
    // Rewards
    rewards,
    addReward,
    updateReward,
    deleteReward,
    
    // Gacha
    gachaHistory,
    addGachaHistory,
    updateGachaHistory,
    getGachaHistoryByDate,
    getCollectedRewards,
    canGachaThisWeek,
    gachaDay,
    changeGachaDay,
    canChangeGachaDay,
    changeThreshold,
    canChangeThreshold,
    changeGachaCount,
    canChangeGachaCount,
    changeGachaMode,
    canChangeGachaMode,
    rollDice,
    canRollDice,
    changeDiceValue,
    canRollDiceToday,
    
    // User Stats
    userStats,
    updateUserStats,
    weeklyData,
    weeklyAverageCompletionRate,
    daysUntilGacha,
    gachaWeekDateRange,
    
    // Achievements
    achievements,
    updateAchievement,
    getUnlockedAchievements,
    
    // Active Task for Timer
    activeTaskId,
    setActiveTaskId,
    
    // Reset All Data
    resetAllData,
  };
  
  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
