import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AppProvider } from "@/context/app-context";
import { TimerProvider } from "@/context/timer-context";

import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Statistics from "@/pages/statistics";
import Gacha from "@/pages/gacha";
import Settings from "@/pages/settings";
import AuthPage from "@/pages/auth-page";
import ErrorBoundary from "@/components/ErrorBoundary";

function Router() {
  return (
    <Switch>
      {/* 認証ページ (認証不要) */}
      <Route path="/auth" component={AuthPage} />
      
      {/* 認証が必要なページ */}
      <ProtectedRoute path="/" component={Home} />
      <ProtectedRoute path="/statistics" component={Statistics} />
      <ProtectedRoute path="/gacha" component={Gacha} />
      <ProtectedRoute path="/settings" component={Settings} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TimerProvider>
          <AppProvider>
            <ErrorBoundary>
              <Router />
            </ErrorBoundary>
            <Toaster />
          </AppProvider>
        </TimerProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
