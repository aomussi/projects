import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import {
  TaskLocal,
  TaskGroupLocal,
  RewardLocal,
  GachaHistoryLocal,
  UserStatsLocal,
  AchievementLocal
} from '@shared/schema';

export function useDatabaseSync() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Tasks
  const {
    data: tasks = [],
    isLoading: tasksLoading
  } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!user,
  });

  const {
    data: taskGroups = [],
    isLoading: taskGroupsLoading
  } = useQuery({
    queryKey: ['/api/task-groups'],
    enabled: !!user,
  });

  const {
    data: rewards = [],
    isLoading: rewardsLoading
  } = useQuery({
    queryKey: ['/api/rewards'],
    enabled: !!user,
  });

  const {
    data: gachaHistory = [],
    isLoading: gachaHistoryLoading
  } = useQuery({
    queryKey: ['/api/gacha-history'],
    enabled: !!user,
  });

  const {
    data: userStats,
    isLoading: userStatsLoading
  } = useQuery({
    queryKey: ['/api/user-stats'],
    enabled: !!user,
  });

  const {
    data: achievements = [],
    isLoading: achievementsLoading
  } = useQuery({
    queryKey: ['/api/achievements'],
    enabled: !!user,
  });

  // Mutations for creating data
  const createTaskMutation = useMutation({
    mutationFn: async (task: Omit<TaskLocal, 'id'>) => {
      const res = await apiRequest('POST', '/api/tasks', task);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const createTaskGroupMutation = useMutation({
    mutationFn: async (group: Omit<TaskGroupLocal, 'id'>) => {
      const res = await apiRequest('POST', '/api/task-groups', group);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/task-groups'] });
    },
  });

  const createRewardMutation = useMutation({
    mutationFn: async (reward: Omit<RewardLocal, 'id'>) => {
      const res = await apiRequest('POST', '/api/rewards', reward);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
    },
  });

  const createGachaHistoryMutation = useMutation({
    mutationFn: async (history: Omit<GachaHistoryLocal, 'id'>) => {
      const res = await apiRequest('POST', '/api/gacha-history', history);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/gacha-history'] });
    },
  });

  const updateUserStatsMutation = useMutation({
    mutationFn: async (stats: Partial<UserStatsLocal>) => {
      const res = await apiRequest('PUT', '/api/user-stats', stats);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-stats'] });
    },
  });

  // Update mutations
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<TaskLocal> }) => {
      const res = await apiRequest('PUT', `/api/tasks/${id}`, updates);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const updateTaskGroupMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<TaskGroupLocal> }) => {
      const res = await apiRequest('PUT', `/api/task-groups/${id}`, updates);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/task-groups'] });
    },
  });

  const updateRewardMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<RewardLocal> }) => {
      const res = await apiRequest('PUT', `/api/rewards/${id}`, updates);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
    },
  });

  // Delete mutations
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const deleteTaskGroupMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/task-groups/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/task-groups'] });
    },
  });

  const deleteRewardMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/rewards/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
    },
  });

  const isLoading = tasksLoading || taskGroupsLoading || rewardsLoading || 
                   gachaHistoryLoading || userStatsLoading || achievementsLoading;

  return {
    // Data
    tasks: tasks || [],
    taskGroups: taskGroups || [],
    rewards: rewards || [],
    gachaHistory: gachaHistory || [],
    userStats: userStats || null,
    achievements: achievements || [],
    
    // Loading states
    isLoading,
    
    // Mutations
    createTask: createTaskMutation.mutateAsync,
    createTaskGroup: createTaskGroupMutation.mutateAsync,
    createReward: createRewardMutation.mutateAsync,
    createGachaHistory: createGachaHistoryMutation.mutateAsync,
    updateUserStats: updateUserStatsMutation.mutateAsync,
    updateTask: updateTaskMutation.mutateAsync,
    updateTaskGroup: updateTaskGroupMutation.mutateAsync,
    updateReward: updateRewardMutation.mutateAsync,
    deleteTask: deleteTaskMutation.mutateAsync,
    deleteTaskGroup: deleteTaskGroupMutation.mutateAsync,
    deleteReward: deleteRewardMutation.mutateAsync,
  };
}