import { useState, useRef, useEffect, useCallback } from 'react';

export type TimerMode = 'countdown' | 'stopwatch';

interface TimerOptions {
  duration?: number; // in minutes
  onComplete?: () => void;
  mode?: TimerMode;
}

export function useTimer({ duration = 25, onComplete, mode = 'countdown' }: TimerOptions = {}) {
  const [timeLeft, setTimeLeft] = useState(duration * 60); // Convert to seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerMode, setTimerMode] = useState<TimerMode>(mode);
  const [customDuration, setCustomDuration] = useState(duration);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const totalDuration = customDuration * 60; // Total duration in seconds
  
  // プログレスバーの計算（カウントダウンとストップウォッチで計算方法が異なる）
  const progress = timerMode === 'countdown' 
    ? (1 - timeLeft / totalDuration) * 100  // カウントダウン: 0→100%
    : 0;  // ストップウォッチ: 上限なしなので進捗バーは使用しない
  
  // モード切替関数
  const switchMode = useCallback((newMode: TimerMode) => {
    if (isRunning || isPaused) {
      reset(); // 実行中なら停止してリセット
    }
    
    setTimerMode(newMode);
    
    if (newMode === 'countdown') {
      setTimeLeft(customDuration * 60);
      setElapsedTime(0);
    } else {
      setTimeLeft(customDuration * 60);
      setElapsedTime(0);
    }
  }, [isRunning, isPaused, customDuration]);
  
  // 時間設定を変更する関数
  const setDuration = useCallback((newDuration: number) => {
    if (isRunning || isPaused) {
      reset(); // 実行中なら停止してリセット
    }
    
    setCustomDuration(newDuration);
    
    if (timerMode === 'countdown') {
      setTimeLeft(newDuration * 60);
    } else {
      setTimeLeft(newDuration * 60);
    }
    
    setElapsedTime(0);
  }, [isRunning, isPaused, timerMode]);
  
  // タイマースタート
  const start = useCallback(() => {
    setIsRunning(true);
    setIsPaused(false);
    if (!startTime) {
      setStartTime(new Date());
    }
    
    intervalRef.current = setInterval(() => {
      if (timerMode === 'countdown') {
        // カウントダウンモード
        setTimeLeft((prev) => {
          const newTime = prev - 1;
          setElapsedTime(totalDuration - newTime);
          
          if (newTime <= 0) {
            clearInterval(intervalRef.current!);
            setIsRunning(false);
            onComplete?.();
            return 0;
          }
          
          return newTime;
        });
      } else {
        // ストップウォッチモード - 上限なし
        setElapsedTime(prev => {
          const newElapsed = prev + 1;
          
          // 999分59秒 = 59999秒を上限とする（実質無制限）
          if (newElapsed >= 59999) {
            clearInterval(intervalRef.current!);
            setIsRunning(false);
            onComplete?.();
            return 59999;
          }
          
          return newElapsed;
        });
      }
    }, 1000);
  }, [startTime, totalDuration, onComplete, timerMode]);
  
  const pause = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPaused(true);
    setIsRunning(false);
  }, []);
  
  const resume = useCallback(() => {
    start();
  }, [start]);
  
  const reset = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    if (timerMode === 'countdown') {
      setTimeLeft(customDuration * 60);
      setElapsedTime(0);
    } else {
      setTimeLeft(customDuration * 60);
      setElapsedTime(0);
    }
    
    setIsRunning(false);
    setIsPaused(false);
    setStartTime(null);
  }, [customDuration, timerMode]);
  
  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsRunning(false);
    // Don't reset the time, just stop the timer
  }, []);
  
  const toggle = useCallback(() => {
    if (isRunning) {
      pause();
    } else if (isPaused) {
      resume();
    } else {
      start();
    }
  }, [isRunning, isPaused, pause, resume, start]);
  
  // 表示時間のフォーマット（カウントダウン/ストップウォッチで表示内容が異なる）
  const getFormattedTime = useCallback(() => {
    if (timerMode === 'countdown') {
      // カウントダウンモード: 残り時間を表示
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
      // ストップウォッチモード: 経過時間を表示
      const minutes = Math.floor(elapsedTime / 60);
      const seconds = elapsedTime % 60;
      return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
  }, [timeLeft, elapsedTime, timerMode]);
  
  const getElapsedTimeInMinutes = useCallback(() => {
    return Math.ceil(elapsedTime / 60);
  }, [elapsedTime]);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  return {
    timeLeft,
    isRunning,
    isPaused,
    progress,
    startTime,
    elapsedTime,
    timerMode,
    customDuration,
    getElapsedTimeInMinutes,
    start,
    pause,
    resume,
    reset,
    stop,
    toggle,
    getFormattedTime,
    switchMode,
    setDuration,
  };
}
