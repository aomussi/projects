import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '@shared/schema';
import { formatTimeHHMM } from '@/lib/utils';
import { Modal } from '@/components/Modal';

interface TaskCompletionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskLocal;
  executionTime?: {
    startTime: Date;
    duration: number; // in minutes
  };
}

export function TaskCompletionModal({ 
  open, 
  onOpenChange, 
  task,
  executionTime
}: TaskCompletionModalProps) {
  const { updateTask } = useAppContext();
  const [reflection, setReflection] = useState('');
  
  const handleSave = () => {
    const updates: Partial<TaskLocal> = {
      reflection: reflection || undefined
    };
    
    if (executionTime) {
      const startTimeStr = formatTimeHHMM(executionTime.startTime);
      const endTime = new Date(executionTime.startTime);
      endTime.setMinutes(endTime.getMinutes() + executionTime.duration);
      const endTimeStr = formatTimeHHMM(endTime);
      
      updates.actualTime = executionTime.duration;
      updates.startTime = startTimeStr;
      updates.endTime = endTimeStr;
    }
    
    updateTask(task.id, updates);
    onOpenChange(false);
  };
  
  return (
    <Modal 
      open={open} 
      onOpenChange={onOpenChange}
      showCloseButton={false}
    >
      <div className="text-center mb-6">
        <div className="inline-block p-3 bg-green-100 rounded-full mb-2">
          <i className="fas fa-check text-2xl text-green-500"></i>
        </div>
        <h2 className="text-xl font-bold text-gray-800">タスク完了！</h2>
        <div className="text-gray-600">{task.title}</div>
      </div>
      
      {executionTime && (
        <div className="mb-4">
          <div className="text-sm font-medium mb-1">実行時間</div>
          <div className="flex items-center justify-between bg-gray-100 p-3 rounded">
            <div>
              <i className="fas fa-clock text-gray-500 mr-2"></i>
              <span>{executionTime.duration}分</span>
            </div>
            <div className="text-sm text-gray-500">
              {formatTimeHHMM(executionTime.startTime)} - {formatTimeHHMM(new Date(executionTime.startTime.getTime() + executionTime.duration * 60 * 1000))}
            </div>
          </div>
        </div>
      )}
      
      <div className="mb-6">
        <div className="text-sm font-medium mb-1">振り返り（任意）</div>
        <Textarea
          value={reflection}
          onChange={(e) => setReflection(e.target.value)}
          placeholder="タスクを終えた感想や気づきを入力してください"
          className="h-24"
        />
      </div>
      
      <div className="flex justify-end">
        <Button onClick={handleSave}>
          保存
        </Button>
      </div>
    </Modal>
  );
}