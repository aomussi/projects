import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '../../../shared/schema';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { formatSimpleDate } from '@/lib/dates';

interface TaskRescheduleModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskLocal;
  onComplete?: () => void;
}

export function TaskRescheduleModal({ open, onOpenChange, task, onComplete }: TaskRescheduleModalProps) {
  const { updateTask } = useAppContext();
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  const handleReschedule = () => {
    if (!date) return;
    
    // タスクの日付を更新
    const dateStr = formatSimpleDate(date);
    updateTask(task.id, { date: dateStr });
    
    // ダイアログを閉じる
    onOpenChange(false);
    
    // 完了ハンドラーがあれば呼び出す
    if (onComplete) {
      onComplete();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>タスクの日付を変更</DialogTitle>
          <DialogDescription>
            {task.rewardId ? '報酬/罰ゲームタスクの日付を変更します' : 'タスクの日付を変更します'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <CalendarComponent
            mode="single"
            selected={date}
            onSelect={setDate}
            initialFocus
            disabled={{ before: new Date() }}
          />
        </div>
        
        <DialogFooter className="sm:justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            キャンセル
          </Button>
          <Button onClick={handleReschedule} disabled={!date}>
            日付を変更
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}