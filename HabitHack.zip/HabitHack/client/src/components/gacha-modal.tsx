import React, { useState } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { getGachaRewardRarity, getRandomInt } from '@/lib/utils';
import { getToday } from '@/lib/dates';

interface GachaModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onResult: (rewardId: string) => void;
}

export function GachaModal({ open, onOpenChange, onResult }: GachaModalProps) {
  const { 
    weeklyAverageCompletionRate, 
    rewards, 
    userStats,
    updateUserStats
  } = useAppContext();
  
  const [isSpinning, setIsSpinning] = useState(false);
  
  const spinGacha = () => {
    setIsSpinning(true);
    
    // ペナルティか報酬かを決定（閾値以上なら報酬、未満ならペナルティ）
    const isPenalty = weeklyAverageCompletionRate < userStats.gachaThreshold;
    
    // ペナルティまたは報酬に該当するアイテムを全て取得
    const allEligibleRewards = rewards.filter(reward => reward.isPenalty === isPenalty);
    
    // 報酬がない場合の対策
    if (allEligibleRewards.length === 0) {
      // 何も表示せずに終了
      setIsSpinning(false);
      onOpenChange(false);
      return;
    }
    
    // 各レア度のアイテムを抽出
    const normalRewards = allEligibleRewards.filter(reward => reward.rarity === 1);
    const rareRewards = allEligibleRewards.filter(reward => reward.rarity === 2);
    const superRareRewards = allEligibleRewards.filter(reward => reward.rarity === 3);
    
    // 全てのアイテムを1つの配列にまとめる
    // 同じレア度は同じ確率で出現する
    const combinedRewards = [
      ...normalRewards,
      ...rareRewards,
      ...superRareRewards
    ];
    
    // ランダムに1つ選択
    const selectedReward = combinedRewards[getRandomInt(0, combinedRewards.length - 1)];
    
    // ガチャ回数を確実に減らす - 0未満にはならないようにする
    const newCount = Math.max(0, userStats.gachaCount - 1);
    updateUserStats({
      gachaCount: newCount
    });
    
    // Simulate spinning animation
    setTimeout(() => {
      setIsSpinning(false);
      
      // ガチャ結果モーダルを表示するためにガチャモーダルは必ず閉じる
      onOpenChange(false);
      
      if (selectedReward) {
        onResult(selectedReward.id);
      }
    }, 2000);
  };
  
  const getStatusMessage = () => {
    if (weeklyAverageCompletionRate >= userStats.gachaThreshold) {
      return "目標達成おめでとう！";
    } else {
      return "目標未達成...";
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogTitle className="sr-only">週間ガチャ</DialogTitle>
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">週間ガチャ</h2>
          <div className="text-sm text-gray-500 mb-2">今週の達成率: {weeklyAverageCompletionRate}%</div>
          <div className={`inline-block px-3 py-1 rounded-full text-sm ${
            weeklyAverageCompletionRate >= userStats.gachaThreshold 
              ? "bg-yellow-100 text-yellow-800" 
              : "bg-gray-100 text-gray-800"
          }`}>
            {getStatusMessage()}
          </div>
          
          <div className="mt-2 text-sm font-medium text-blue-600">
            残りガチャ回数: {userStats.gachaCount}回
          </div>
        </div>
        
        <div className="flex justify-center mb-6">
          <div className={`relative w-40 h-40 rounded-full flex items-center justify-center ${
            weeklyAverageCompletionRate >= userStats.gachaThreshold
              ? "bg-yellow-100"
              : "bg-gray-100"
          }`}>
            <div className={`text-6xl ${isSpinning ? "animate-spin" : ""}`}>
              {isSpinning ? "🎲" : "🎁"}
            </div>
          </div>
        </div>
        
        <Button
          className="w-full py-3 mb-4 font-medium"
          onClick={spinGacha}
          disabled={isSpinning || userStats.gachaCount <= 0}
        >
          {isSpinning ? "ガチャ中..." : userStats.gachaCount <= 0 ? "ガチャ回数がありません" : "ガチャを回す！"}
        </Button>
        
        <div className="text-center text-sm text-gray-500">
          目標達成率{userStats.gachaThreshold}%以上で報酬アイテム、未満で罰ゲームが出現します。
        </div>
        <div className="text-center text-xs text-blue-600 mt-1">
          各レア度の確率はアイテム数に応じて変動します。
        </div>
      </DialogContent>
    </Dialog>
  );
}
