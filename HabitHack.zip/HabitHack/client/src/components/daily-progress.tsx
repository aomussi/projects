import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useAppContext } from '@/context/app-context';

export function DailyProgress() {
  const { 
    tasksForCurrentDate, 
    completedTasksForCurrentDate, 
    completionRate,
    userStats
  } = useAppContext();
  
  const totalTasks = tasksForCurrentDate.length;
  const completedTasks = completedTasksForCurrentDate.length;
  
  const renderProgressCircle = () => {
    const circumference = 2 * Math.PI * 18;
    const dashOffset = circumference * (1 - completionRate / 100);
    
    return (
      <div className="relative w-10 h-10">
        <svg className="w-10 h-10 -rotate-90 transform">
          <circle 
            r="18" 
            cx="20" 
            cy="20" 
            fill="transparent" 
            stroke="#e0e0e0" 
            strokeWidth="3"
          />
          <circle 
            r="18" 
            cx="20" 
            cy="20" 
            fill="transparent" 
            stroke="hsl(var(--primary))" 
            strokeWidth="3" 
            strokeDasharray={circumference} 
            strokeDashoffset={dashOffset}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-xs font-medium">
          {completionRate}%
        </span>
      </div>
    );
  };
  
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium">今日の進捗</h2>
          <div className="text-sm text-gray-500">
            {completedTasks}/{totalTasks} 完了
          </div>
        </div>
        
        <div className="mt-2">
          <Progress value={completionRate} className="h-2" />
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center">
            {renderProgressCircle()}
            <span className="ml-2 text-sm">完了率</span>
          </div>
          
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
              <i className="fas fa-fire text-orange-500"></i>
            </div>
            <div className="ml-2">
              <div className="text-xs text-gray-500">連続達成</div>
              <div className="text-sm font-medium">{userStats.streak}日</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
