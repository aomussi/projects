import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { WeeklyStatsModal } from './weekly-stats-modal';
import { getCurrentWeekDates, formatSimpleDate } from '@/lib/dates';
import { cn } from '@/lib/utils';

export function WeeklyProgress() {
  const { 
    weeklyData, 
    weeklyAverageCompletionRate,
    daysUntilGacha,
    userStats
  } = useAppContext();
  
  const [statsModalOpen, setStatsModalOpen] = useState(false);
  
  // Get the current week's dates
  const currentWeekDates = getCurrentWeekDates(new Date());
  
  // Map dates to weekdays
  const weekDays = ['月', '火', '水', '木', '金', '土', '日'];
  
  // Get completion rates for each day
  const completionRates = currentWeekDates.map(date => {
    const dateStr = formatSimpleDate(date);
    const dayData = weeklyData.find(data => data.date === dateStr);
    return dayData ? dayData.completionRate : null;
  });
  
  // Calculate progress toward gacha
  const daysPassed = 7 - daysUntilGacha;
  const gachaProgress = Math.min(100, Math.round((daysPassed / 7) * 100));
  
  return (
    <>
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-medium">週間達成状況</h2>
            <span className="text-sm text-gray-500">{weeklyAverageCompletionRate}% 達成</span>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-3">
            {weekDays.map((day, index) => (
              <div key={index} className="text-center">
                <div className="text-xs text-gray-500 mb-1">{day}</div>
                <div className={cn(
                  "mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm",
                  completionRates[index] !== null 
                    ? completionRates[index]! >= userStats.gachaThreshold
                      ? "bg-primary text-white"
                      : "bg-gray-200 text-gray-600"
                    : "bg-gray-300"
                )}>
                  {completionRates[index] !== null 
                    ? `${completionRates[index]}%` 
                    : "-"}
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center p-2 mb-2 bg-gray-100 rounded-lg">
            <div className="text-sm mb-1">
              ガチャまであと<span className="font-bold text-primary"> {daysUntilGacha} </span>日
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full" 
                style={{ width: `${gachaProgress}%` }}
              ></div>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            className="w-full py-2 text-sm" 
            onClick={() => setStatsModalOpen(true)}
          >
            詳細を見る
          </Button>
        </CardContent>
      </Card>
      
      <WeeklyStatsModal 
        open={statsModalOpen} 
        onOpenChange={setStatsModalOpen} 
      />
    </>
  );
}
