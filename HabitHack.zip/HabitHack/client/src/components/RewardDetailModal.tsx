import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { RewardLocal } from '@shared/schema';
import { Calendar } from 'lucide-react';
import { TaskDateModal } from './TaskDateModal';
import { Modal } from '@/components/Modal';

interface RewardDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reward: RewardLocal;
}

export function RewardDetailModal({ open, onOpenChange, reward }: RewardDetailModalProps) {
  const { updateReward } = useAppContext();
  const [dateModalOpen, setDateModalOpen] = useState(false);
  
  // 日付モーダルを開く
  const handleAddToTask = () => {
    setDateModalOpen(true);
  };
  
  // アイテム詳細モーダルが閉じられたときに日付モーダルも閉じる
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setDateModalOpen(false);
    }
    onOpenChange(open);
  };
  
  // レア度を星で表示
  const renderRarityStars = (rarity: number) => {
    const stars = [];
    for (let i = 0; i < rarity; i++) {
      stars.push(<span key={i} className="text-yellow-400">★</span>);
    }
    return stars;
  };

  const renderFooter = () => (
    <>
      <Button variant="outline" onClick={() => onOpenChange(false)}>閉じる</Button>
      <Button 
        onClick={handleAddToTask}
        className="flex items-center"
      >
        <Calendar className="h-4 w-4 mr-2" />
        タスクに追加
      </Button>
    </>
  );
  
  return (
    <>
      <Modal 
        open={open} 
        onOpenChange={handleOpenChange}
        title={
          <div className="flex items-center">
            <span className="text-2xl mr-2">{reward.emoji || (reward.isPenalty ? '⚠️' : '🎁')}</span>
            {reward.title}
          </div>
        }
        description="アイテム詳細"
        footer={renderFooter()}
      >
        <div className="py-4">
          <div className="flex items-center mb-3">
            <span className="text-sm text-gray-500 mr-2">レア度:</span>
            <span>{renderRarityStars(reward.rarity)}</span>
          </div>
          
          {reward.description && (
            <div className="mb-4">
              <h3 className="text-sm font-medium mb-1 text-gray-500">説明</h3>
              <p className="text-sm">{reward.description}</p>
            </div>
          )}
          
          <div className="mb-4">
            <h3 className="text-sm font-medium mb-1 text-gray-500">タイプ</h3>
            <p className="text-sm">{reward.isPenalty ? '罰ゲーム' : '報酬'}</p>
          </div>
        </div>
      </Modal>
      
      <TaskDateModal 
        open={dateModalOpen} 
        onOpenChange={setDateModalOpen}
        reward={reward}
        onComplete={() => {
          setDateModalOpen(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}