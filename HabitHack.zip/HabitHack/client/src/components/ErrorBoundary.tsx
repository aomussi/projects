import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCw } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null
    };
  }

  static getDerivedStateFromError(error: Error): State {
    // エラー発生時にUIを更新
    return {
      hasError: true,
      error,
      errorInfo: null
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // エラー情報をログに記録
    console.error('エラーバウンダリーがエラーをキャッチしました:', error, errorInfo);
    this.setState({
      errorInfo
    });
  }

  handleReset = (): void => {
    // アプリケーションをリセット
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null
    });
  }

  render(): ReactNode {
    if (this.state.hasError) {
      // カスタムエラーUIを表示
      return (
        <div className="container max-w-md mx-auto my-8 p-6">
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle className="text-lg font-semibold">
              エラーが発生しました
            </AlertTitle>
            <AlertDescription className="mt-2">
              <p className="mb-2">
                アプリケーションで予期せぬエラーが発生しました。
              </p>
              <p className="text-sm text-muted-foreground mb-4">
                {this.state.error?.message || 'エラーの詳細は利用できません'}
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={this.handleReset}
                  variant="outline"
                  className="flex items-center gap-1"
                >
                  <RefreshCw className="h-4 w-4" />
                  再試行
                </Button>
                <Button 
                  onClick={() => window.location.href = '/'}
                  variant="default"
                >
                  ホームに戻る
                </Button>
              </div>
            </AlertDescription>
          </Alert>
          {process.env.NODE_ENV !== 'production' && (
            <div className="mt-4 p-4 bg-muted rounded-md overflow-auto text-xs">
              <details>
                <summary className="cursor-pointer font-medium mb-2">
                  開発者向けエラー詳細
                </summary>
                <pre className="whitespace-pre-wrap break-words">
                  {this.state.error?.stack}
                </pre>
                {this.state.errorInfo && (
                  <pre className="mt-2 whitespace-pre-wrap break-words">
                    {this.state.errorInfo.componentStack}
                  </pre>
                )}
              </details>
            </div>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;