import React from 'react';
import { useAppContext } from '@/context/app-context';
import { getCurrentWeekDates, formatSimpleDate } from '@/lib/dates';
import { cn } from '@/lib/utils';
import { Modal } from '@/components/Modal';

interface WeeklyStatsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WeeklyStatsModal({ open, onOpenChange }: WeeklyStatsModalProps) {
  const { 
    weeklyData,
    weeklyAverageCompletionRate,
    taskGroups,
    tasks,
    gachaWeekDateRange
  } = useAppContext();
  
  // 日付のフォーマット関数（MM/DD形式）
  const formatDateMMDD = (dateStr: string) => {
    const date = new Date(dateStr);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };
  
  // Current week dates (standard week view)
  const currentWeekDates = getCurrentWeekDates(new Date());
  
  // ガチャ曜日に合わせて表示順序を調整（ガチャ曜日が最後になるように）
  const getOrderedWeekdays = (gachaDay: number) => {
    // 日本語の曜日表記（月曜始まり）
    const allWeekdays = ['月', '火', '水', '木', '金', '土', '日'];
    
    // gachaDayを日本の曜日インデックスに変換（0=日曜 → 6, 1=月曜 → 0, ...）
    const japaneseGachaIndex = gachaDay === 0 ? 6 : gachaDay - 1;
    
    // japaneseGachaIndexの翌日から開始し、一周して当日で終わるように
    const result = [];
    for (let i = 1; i <= 7; i++) {
      const index = (japaneseGachaIndex + i) % 7;
      result.push(allWeekdays[index]);
    }
    return result;
  };
  
  const userStatsContext = useAppContext();
  const gachaDay = userStatsContext.userStats.gachaDay;
  const weekDays = getOrderedWeekdays(gachaDay);
  
  // Get completion rates for each day
  const completionRates = currentWeekDates.map(date => {
    const dateStr = formatSimpleDate(date);
    const dayData = weeklyData.find(data => data.date === dateStr);
    return dayData ? dayData.completionRate : 0;
  });
  
  // Calculate stats
  const completedTasksCount = tasks.filter(task => task.isCompleted).length;
  
  // Calculate total execution time (in minutes)
  const totalExecutionTime = tasks
    .filter(task => task.actualTime !== undefined)
    .reduce((sum, task) => sum + (task.actualTime || 0), 0);
  
  // Format execution time (hours)
  const totalHours = (totalExecutionTime / 60).toFixed(1);
  
  // Calculate group completion rates
  const groupCompletionRates = taskGroups.map(group => {
    const groupTasks = tasks.filter(task => task.groupId === group.id);
    const totalGroupTasks = groupTasks.length;
    const completedGroupTasks = groupTasks.filter(task => task.isCompleted).length;
    
    const completionRate = totalGroupTasks > 0 
      ? Math.round((completedGroupTasks / totalGroupTasks) * 100) 
      : 0;
    
    return {
      group,
      completionRate
    };
  });
  
  // Sort by completion rate
  groupCompletionRates.sort((a, b) => b.completionRate - a.completionRate);
  
  return (
    <Modal 
      open={open} 
      onOpenChange={onOpenChange}
      title="週間レポート"
      className="sm:max-w-md max-h-[90vh] overflow-y-auto"
    >
      {/* ガチャ期間の日付範囲表示 */}
      {gachaWeekDateRange && (
        <div className="text-xs text-center text-gray-500 mb-3">
          {`${formatDateMMDD(gachaWeekDateRange.start)} 〜 ${formatDateMMDD(gachaWeekDateRange.end)}`}
        </div>
      )}
      
      <div className="mb-4">
        <div className="font-medium mb-2">達成率推移</div>
        <div className="h-40 bg-gray-100 rounded flex items-end p-2">
          {weekDays.map((day, index) => (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div 
                className={cn(
                  "w-full",
                  completionRates[index] > 0 ? "bg-primary" : "bg-gray-300"
                )}
                style={{ height: `${completionRates[index]}%` }}
              ></div>
              <div className="text-xs mt-1">{day}</div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <div className="font-medium mb-2">タスク実績</div>
        <div className="bg-gray-100 rounded p-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white p-2 rounded shadow-sm text-center">
              <div className="text-2xl font-bold text-primary">{completedTasksCount}</div>
              <div className="text-xs text-gray-500">完了タスク数</div>
            </div>
            <div className="bg-white p-2 rounded shadow-sm text-center">
              <div className="text-2xl font-bold text-primary">{weeklyAverageCompletionRate}%</div>
              <div className="text-xs text-gray-500">平均達成率</div>
            </div>
            <div className="bg-white p-2 rounded shadow-sm text-center">
              <div className="text-2xl font-bold text-primary">{totalHours}h</div>
              <div className="text-xs text-gray-500">総実行時間</div>
            </div>
            <div className="bg-white p-2 rounded shadow-sm text-center">
              <div className="text-2xl font-bold text-green-500">+2</div>
              <div className="text-xs text-gray-500">ストリーク</div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="font-medium mb-2">グループ別達成率</div>
        <div className="space-y-2">
          {groupCompletionRates.map(({ group, completionRate }) => (
            <div key={group.id}>
              <div className="flex justify-between text-sm mb-1">
                <span>{group.name}</span>
                <span>{completionRate}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full" 
                  style={{ 
                    width: `${completionRate}%`,
                    backgroundColor: group.color 
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Modal>
  );
}