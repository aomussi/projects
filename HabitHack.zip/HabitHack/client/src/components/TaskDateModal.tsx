import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { RewardLocal, TaskLocal } from '@shared/schema';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { formatSimpleDate, getToday } from '@/lib/dates';
import { useLocation } from 'wouter';
import { Modal } from '@/components/Modal';

interface TaskDateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reward: RewardLocal;
  onComplete: () => void;
}

export function TaskDateModal({ open, onOpenChange, reward, onComplete }: TaskDateModalProps) {
  const { addTask, updateGachaHistory, setCurrentDate } = useAppContext();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [, setLocation] = useLocation();
  
  const handleAddTask = () => {
    if (!date) return;
    
    console.log('報酬アイテムを追加:', reward);
    console.log('originalRewardId:', reward.originalRewardId);
    
    // 新しいタスクを追加
    const dateStr = date ? formatSimpleDate(date) : getToday();
    const newTask: Omit<TaskLocal, 'id'> = {
      title: `${reward.isPenalty ? '罰ゲーム' : '報酬'}: ${reward.title}`,
      isCompleted: false,
      isRecurring: false,
      date: dateStr, // yyyy-MM-dd 形式で保存
      groupId: null,
      rewardId: reward.originalRewardId || reward.id
    };
    
    console.log('作成されるタスク:', newTask);
    
    const createdTask = addTask(newTask);
    console.log('作成されたタスク:', createdTask);
    
    // ガチャ履歴を更新して、このアイテムが使用済みであるとマーク
    updateGachaHistory(reward.id, { usedInTask: true });
    console.log('ガチャ履歴を更新:', reward.id, { usedInTask: true });
    
    // タスクの日付をフォーマットして現在の日付に設定
    // 追加されたタスクと同じ日付を表示するようにする
    setCurrentDate(dateStr);
    
    // 処理完了後にホームページに遷移
    onComplete();
    setTimeout(() => {
      setLocation('/');
    }, 100);
  };

  const renderFooter = () => (
    <>
      <Button variant="outline" onClick={() => onOpenChange(false)}>
        キャンセル
      </Button>
      <Button onClick={handleAddTask} disabled={!date}>
        追加
      </Button>
    </>
  );
  
  return (
    <Modal 
      open={open} 
      onOpenChange={onOpenChange}
      title="タスクを追加する日付を選択"
      description="アイテムをタスクに追加すると、所持アイテム一覧から削除されます"
      footer={renderFooter()}
    >
      <div className="py-4">
        <CalendarComponent
          mode="single"
          selected={date}
          onSelect={setDate}
          initialFocus
          disabled={{ before: new Date() }}
        />
      </div>
    </Modal>
  );
}