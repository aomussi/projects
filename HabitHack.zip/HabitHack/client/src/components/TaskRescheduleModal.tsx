import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '@shared/schema';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { formatSimpleDate } from '@/lib/dates';
import { Modal } from '@/components/Modal';

interface TaskRescheduleModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskLocal;
  onComplete?: () => void;
}

export function TaskRescheduleModal({ open, onOpenChange, task, onComplete }: TaskRescheduleModalProps) {
  const { updateTask } = useAppContext();
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  const handleReschedule = () => {
    if (!date) return;
    
    // タスクの日付を更新
    const dateStr = formatSimpleDate(date);
    updateTask(task.id, { date: dateStr });
    
    // ダイアログを閉じる
    onOpenChange(false);
    
    // 完了ハンドラーがあれば呼び出す
    if (onComplete) {
      onComplete();
    }
  };

  const renderFooter = () => (
    <>
      <Button variant="outline" onClick={() => onOpenChange(false)}>
        キャンセル
      </Button>
      <Button onClick={handleReschedule} disabled={!date}>
        日付を変更
      </Button>
    </>
  );
  
  return (
    <Modal 
      open={open} 
      onOpenChange={onOpenChange}
      title="タスクの日付を変更"
      description={task.rewardId ? '報酬/罰ゲームタスクの日付を変更します' : 'タスクの日付を変更します'}
      footer={renderFooter()}
    >
      <div className="py-4">
        <CalendarComponent
          mode="single"
          selected={date}
          onSelect={setDate}
          initialFocus
          disabled={{ before: new Date() }}
        />
      </div>
    </Modal>
  );
}