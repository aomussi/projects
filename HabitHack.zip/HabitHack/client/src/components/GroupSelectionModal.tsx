import React, { useState } from 'react';
import { DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAppContext } from '@/context/app-context';
import { colors } from '@/lib/constants';
import { X, Plus } from 'lucide-react';
import { Modal } from '@/components/Modal';

interface GroupSelectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (groupId: string | null) => void;
}

export function GroupSelectionModal({ open, onOpenChange, onSelect }: GroupSelectionModalProps) {
  const { taskGroups, addTaskGroup } = useAppContext();
  const [showAddGroup, setShowAddGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedColor, setSelectedColor] = useState(colors[0].value);
  
  const handleSelectGroup = (groupId: string) => {
    onSelect(groupId);
    onOpenChange(false);
  };
  
  const handleAddGroup = () => {
    if (newGroupName.trim()) {
      const newGroup = {
        name: newGroupName.trim(),
        color: selectedColor
      };
      
      addTaskGroup(newGroup);
      setNewGroupName('');
      setSelectedColor(colors[0].value);
      setShowAddGroup(false);
    }
  };
  
  return (
    <Modal 
      open={open} 
      onOpenChange={onOpenChange}
      title="グループ選択"
    >
      {!showAddGroup ? (
        <>
          <div className="mb-4">
            {taskGroups.map((group) => (
              <div
                key={group.id}
                className="flex items-center p-3 hover:bg-gray-100 rounded cursor-pointer"
                onClick={() => handleSelectGroup(group.id)}
              >
                <div
                  className="w-4 h-4 rounded-full mr-3"
                  style={{ backgroundColor: group.color }}
                ></div>
                <span>{group.name}</span>
              </div>
            ))}
          </div>
          
          <Button
            variant="ghost"
            className="flex items-center p-3 text-primary"
            onClick={() => setShowAddGroup(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            <span>新しいグループを追加</span>
          </Button>
        </>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">グループ名</label>
            <Input
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              placeholder="新しいグループ名"
              className="mt-1"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium">カラー</label>
            <div className="flex flex-wrap gap-2 mt-1">
              {colors.map((color) => (
                <button
                  key={color.value}
                  className="w-8 h-8 rounded-full border-2 flex items-center justify-center"
                  style={{
                    backgroundColor: color.value,
                    borderColor: selectedColor === color.value ? 'white' : color.value,
                    boxShadow: selectedColor === color.value ? '0 0 0 2px black' : 'none'
                  }}
                  onClick={() => setSelectedColor(color.value)}
                  aria-label={`Select ${color.name} color`}
                />
              ))}
            </div>
          </div>
          
          <div className="flex justify-between pt-2">
            <Button
              variant="ghost"
              onClick={() => setShowAddGroup(false)}
            >
              キャンセル
            </Button>
            <Button onClick={handleAddGroup}>
              追加
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}