import React, { useState, useRef } from 'react';
import { TaskRescheduleModal } from '@/components/task-reschedule-modal';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from '@/components/ui/dropdown-menu';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '@shared/schema';
import { cn, formatTime } from '@/lib/utils';
import { MoreVertical, Play, Check, Repeat, Calendar, AlertTriangle, CalendarDays } from 'lucide-react';

interface TaskItemProps {
  task: TaskLocal;
  onStartTimer: (task: TaskLocal) => void;
}

export function TaskItem({ task, onStartTimer }: TaskItemProps) {
  const { 
    updateTask, 
    deleteTask, 
    completeTask, 
    uncompleteTask, 
    taskGroups,
    tasks,
    rewards
  } = useAppContext();
  
  // スワイプ関連のstate変数を削除
  const [rescheduleModalOpen, setRescheduleModalOpen] = useState(false);
  const taskRef = useRef<HTMLDivElement>(null);
  
  // Get task group
  const taskGroup = task.groupId 
    ? taskGroups.find(group => group.id === task.groupId) 
    : null;
    
  // 周期タスク関連のデータを取得
  const isParentTask = task.isRecurring && !task.parentTaskId;
  const isChildTask = !!task.parentTaskId;
  
  // 親タスクの場合、子タスクの数を取得
  const childTasks = isParentTask
    ? tasks.filter(t => t.parentTaskId === task.id)
    : [];
    
  // 子タスクの場合、親タスクを取得
  const parentTask = isChildTask
    ? tasks.find(t => t.id === task.parentTaskId)
    : null;
    
  // 同じ親を持つ他の子タスク（兄弟タスク）を取得
  const siblingTasks = isChildTask && task.parentTaskId
    ? tasks.filter(t => t.parentTaskId === task.parentTaskId && t.id !== task.id)
    : [];
  
  // スワイプ機能を完全に無効化
  
  // スワイプ機能と関連コードを削除
  
  // 報酬・罰ゲームタスクかどうかを判定
  const isRewardTask = !!task.rewardId;
  
  // 報酬アイテムの取得（報酬タスクの場合）
  const rewardItem = isRewardTask && task.rewardId 
    ? rewards.find(reward => reward.id === task.rewardId)
    : null;
  
  // 罰ゲームかどうか
  const isPenaltyTask = isRewardTask && rewardItem?.isPenalty;
  
  // Task border color based on type and completion status
  const getBorderColor = () => {
    if (task.isCompleted) return 'border-gray-300';
    if (isRewardTask) return isPenaltyTask ? 'border-red-500' : 'border-amber-500';
    return task.isRecurring ? 'border-blue-500' : 'border-green-500';
  };
  
  // Button border color
  const getButtonBorderColor = () => {
    if (task.isCompleted) return 'border-gray-400 bg-gray-400';
    if (isRewardTask) return isPenaltyTask ? 'border-red-500' : 'border-amber-500';
    return task.isRecurring ? 'border-blue-500' : 'border-green-500';
  };
  
  // タスクの背景色を取得
  const getBackgroundColor = () => {
    if (isRewardTask) return 'bg-amber-50'; // 報酬タスクは薄い黄色
    return 'bg-white';
  };

  return (
    <div>
      <div
        ref={taskRef}
        className={cn(
          "task-item p-4 rounded-lg shadow-sm border-l-4 mb-2",
          getBackgroundColor(), // 背景色を追加
          getBorderColor(),
          task.isCompleted && "opacity-60"
        )}
        // スワイプ機能を削除
        data-task-id={task.id}
      >
        <div className="flex items-center">
          <button
            className={cn(
              "mr-3 w-6 h-6 rounded-full border-2 flex items-center justify-center",
              getButtonBorderColor()
            )}
            onClick={() => task.isCompleted ? uncompleteTask(task.id) : completeTask(task.id)}
          >
            <Check className={cn("text-white w-4 h-4", !task.isCompleted && "opacity-0")} />
          </button>
          
          <div className="flex-1">
            <div className={cn("font-medium", task.isCompleted && "line-through")}>
              {task.title}
            </div>
            <div className="flex items-center mt-1 text-sm text-gray-500">
              {taskGroup && (
                <span className="mr-2">
                  <i className="fas fa-tag mr-1"></i>
                  {taskGroup.name}
                </span>
              )}
              {task.estimatedTime && (
                <span className="mr-2">
                  <i className="fas fa-clock mr-1"></i>
                  {formatTime(task.estimatedTime)}
                </span>
              )}
              {isParentTask && childTasks.length > 0 && (
                <span className="mr-2 flex items-center text-blue-500">
                  <Repeat className="h-3 w-3 mr-1" />
                  <span>{childTasks.length}個の関連タスク</span>
                </span>
              )}
              {isChildTask && (
                <span className="mr-2 flex items-center text-blue-500">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>周期タスク</span>
                </span>
              )}
              {task.rewardId && (
                <span className="mr-2 flex items-center text-purple-500">
                  <span>🎁</span>
                  <span className="ml-1">
                    {isPenaltyTask ? '罰ゲームタスク' : '報酬タスク'}
                  </span>
                </span>
              )}
            </div>
          </div>
          
          <div className="flex">
            
            {/* タイマーボタン */}
            {!task.isCompleted && (
              <Button
                variant="ghost"
                size="icon"
                className="text-gray-500 h-auto p-2"
                onClick={() => onStartTimer(task)}
              >
                <Play className="h-4 w-4" />
              </Button>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-500 h-auto p-2"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {/* 基本操作 - 報酬タスク以外の場合のみ削除可能 */}
                {!isRewardTask && (
                  <DropdownMenuItem onClick={() => deleteTask(task.id)}>
                    削除
                  </DropdownMenuItem>
                )}
                
                {/* リスケジュール（日付変更）- すべてのタスクで可能 */}
                <DropdownMenuItem onClick={() => setRescheduleModalOpen(true)}>
                  <CalendarDays className="h-4 w-4 mr-2" />
                  日付を変更
                </DropdownMenuItem>
                
                {/* 完了状態の変更 */}
                {!task.isCompleted ? (
                  <DropdownMenuItem onClick={() => completeTask(task.id)}>
                    <Check className="h-4 w-4 mr-2" />
                    完了にする
                  </DropdownMenuItem>
                ) : (
                  <DropdownMenuItem onClick={() => uncompleteTask(task.id)}>
                    未完了に戻す
                  </DropdownMenuItem>
                )}
                
                {/* 周期タスク関連の操作 - 報酬タスク以外のみ */}
                {!isRewardTask && (isParentTask || isChildTask) && (
                  <>
                    <DropdownMenuSeparator />
                    
                    {/* 親タスクの場合 */}
                    {isParentTask && childTasks.length > 0 && (
                      <DropdownMenuItem onClick={() => deleteTask(task.id, true)} className="text-red-500">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        すべての関連タスクを削除
                      </DropdownMenuItem>
                    )}
                    
                    {/* 子タスクの場合 */}
                    {isChildTask && parentTask && (
                      <DropdownMenuItem onClick={() => deleteTask(task.id, true)} className="text-red-500">
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        すべての関連タスクを削除
                      </DropdownMenuItem>
                    )}
                  </>
                )}
                
                {/* 報酬タスクの場合に表示するラベル */}
                {isRewardTask && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel className="text-xs text-muted-foreground">
                      報酬・罰ゲームタスクは削除できません
                    </DropdownMenuLabel>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* リスケジュールモーダル */}
      <TaskRescheduleModal
        open={rescheduleModalOpen}
        onOpenChange={setRescheduleModalOpen}
        task={task}
      />
    </div>
  );
}