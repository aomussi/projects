import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { GachaModal } from './gacha-modal';
import { GachaResultModal } from './gacha-result-modal';
import { cn } from '@/lib/utils';
import { getToday } from '@/lib/dates';

export function GachaPreview() {
  const { 
    rewards, 
    getCollectedRewards, 
    addGachaHistory, 
    weeklyAverageCompletionRate,
    daysUntilGacha,
    canGachaThisWeek,
    userStats,
    updateUserStats
  } = useAppContext();
  
  const [gachaModalOpen, setGachaModalOpen] = useState(false);
  const [resultModalOpen, setResultModalOpen] = useState(false);
  const [selectedRewardId, setSelectedRewardId] = useState<string | null>(null);
  
  const collectedRewards = getCollectedRewards();
  
  const handleGachaResult = (rewardId: string) => {
    setSelectedRewardId(rewardId);
    setResultModalOpen(true);
    
    // Record gacha history
    addGachaHistory({
      rewardId,
      date: getToday(),
      weekCompletionRate: weeklyAverageCompletionRate
    });
    
    // ガチャ回数を減らす
    if (userStats.gachaCount > 0) {
      updateUserStats({
        gachaCount: userStats.gachaCount - 1
      });
    }
  };
  
  const handleOpenGacha = () => {
    if (canGachaThisWeek) {
      setGachaModalOpen(true);
    }
  };
  
  // Display up to 4 rewards (collected or placeholders)
  const displayRewards = () => {
    const rewardsToShow = collectedRewards.slice(0, 4);
    const placeholdersNeeded = Math.max(0, 4 - rewardsToShow.length);
    
    return (
      <div className="flex overflow-x-auto py-2 mb-2 scrollbar-hide">
        {rewardsToShow.map((reward) => (
          <div key={reward.id} className="flex-shrink-0 w-16 mx-1 text-center">
            <div className={cn(
              "w-14 h-14 rounded-full mx-auto mb-1 flex items-center justify-center",
              reward.rarity === 3 ? "bg-purple-100" : 
              reward.rarity === 2 ? "bg-blue-100" : "bg-yellow-100"
            )}>
              <span className={cn(
                "text-2xl",
                reward.rarity === 3 ? "text-purple-600" : 
                reward.rarity === 2 ? "text-blue-600" : "text-yellow-600"
              )}>
                {reward.emoji || "🎁"}
              </span>
            </div>
            <div className="text-xs truncate">{reward.title}</div>
          </div>
        ))}
        
        {Array.from({ length: placeholdersNeeded }).map((_, i) => (
          <div key={`placeholder-${i}`} className="flex-shrink-0 w-16 mx-1 text-center opacity-40">
            <div className="w-14 h-14 rounded-full bg-gray-200 mx-auto mb-1 flex items-center justify-center">
              <span className="text-gray-500 text-2xl">?</span>
            </div>
            <div className="text-xs">未獲得</div>
          </div>
        ))}
      </div>
    );
  };
  
  const selectedReward = selectedRewardId 
    ? rewards.find(r => r.id === selectedRewardId) 
    : null;
  
  return (
    <>
      <Card className="mb-20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-medium">週間ガチャ</h2>
            <div className="text-sm bg-gray-100 px-2 py-1 rounded-full text-gray-700">
              <i className="fas fa-trophy text-yellow-500 mr-1"></i> {collectedRewards.length}個獲得
            </div>
          </div>
          
          {canGachaThisWeek && (
            <div className="flex items-center justify-center bg-blue-50 p-2 rounded-lg mb-3">
              <span className="text-blue-600 font-medium">
                今週のガチャ: 残り{userStats.gachaCount}回
              </span>
            </div>
          )}
          
          {displayRewards()}
          
          <Button 
            className="w-full"
            onClick={handleOpenGacha}
            disabled={!canGachaThisWeek}
          >
            <i className="fas fa-gift mr-2"></i> 
            {canGachaThisWeek 
              ? "ガチャを回す" 
              : `ガチャまであと${daysUntilGacha}日`
            }
          </Button>
        </CardContent>
      </Card>
      
      <GachaModal 
        open={gachaModalOpen} 
        onOpenChange={setGachaModalOpen} 
        onResult={handleGachaResult} 
      />
      
      {selectedReward && (
        <GachaResultModal 
          open={resultModalOpen}
          onOpenChange={setResultModalOpen}
          reward={selectedReward}
        />
      )}
    </>
  );
}
