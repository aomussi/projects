import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/context/app-context';
import { TaskItem } from '@/components/TaskItem';
import { TaskTimerModal } from '@/components/TaskTimerModal';
import { TaskCompletionModal } from './TaskCompletionModal';
import { TaskLocal } from '@shared/schema';
import { Reorder } from 'framer-motion';

export function TaskList() {
  const { tasksForCurrentDate, reorderTasks } = useAppContext();
  const [activeTask, setActiveTask] = useState<TaskLocal | null>(null);
  const [timerModalOpen, setTimerModalOpen] = useState(false);
  const [completionModalOpen, setCompletionModalOpen] = useState(false);
  const [executionTime, setExecutionTime] = useState<{
    startTime: Date;
    duration: number;
  } | undefined>(undefined);
  
  // ドラッグ＆ドロップで並び替え可能なタスクのState
  const [tasks, setTasks] = useState<TaskLocal[]>([]);
  
  // tasksForCurrentDateが変更されたときにローカルの状態を更新
  React.useEffect(() => {
    // 未完了タスクと完了済みタスクを分離
    const incompleteTasks = tasksForCurrentDate.filter(task => !task.isCompleted);
    const completedTasks = tasksForCurrentDate.filter(task => task.isCompleted);
    
    // ソートした未完了タスクを設定（これがドラッグ＆ドロップの対象）
    setTasks(incompleteTasks.sort((a, b) => {
      // orderプロパティでソート
      if (a.order !== undefined && b.order !== undefined) {
        return a.order - b.order;
      } else if (a.order !== undefined) {
        return -1;
      } else if (b.order !== undefined) {
        return 1;
      }
      
      // orderがなければIDでソート
      return a.id.localeCompare(b.id);
    }));
  }, [tasksForCurrentDate]);
  
  // ドラッグ＆ドロップ後、完了タスクと合わせて並び替えを適用
  const handleReorder = (reorderedTasks: TaskLocal[]) => {
    setTasks(reorderedTasks);
    // タスクの順序を永続化する
    reorderTasks(reorderedTasks);
  };
  
  // Sort tasks: incomplete tasks first, then by order (if present), then by ID
  const sortedTasks = [...tasksForCurrentDate].sort((a, b) => {
    // 最初に完了状態でソート
    if (a.isCompleted !== b.isCompleted) {
      return a.isCompleted ? 1 : -1;
    }
    
    // 次に順序でソート (orderがnull/undefinedの場合は最後に)
    if (a.order !== undefined && b.order !== undefined) {
      return a.order - b.order;
    } else if (a.order !== undefined) {
      return -1; // aにはorderがあるがbにはない場合、aを前に
    } else if (b.order !== undefined) {
      return 1;  // bにはorderがあるがaにはない場合、bを前に
    }
    
    // 最後にID（作成順）でソート
    return a.id.localeCompare(b.id);
  });
  
  const handleStartTimer = (task: TaskLocal) => {
    setActiveTask(task);
    setTimerModalOpen(true);
  };
  
  const handleTimerComplete = (task: TaskLocal, startTime: Date, duration: number) => {
    setActiveTask(task);
    setExecutionTime({ startTime, duration });
    setTimerModalOpen(false);
    setCompletionModalOpen(true);
  };
  
  return (
    <div className="space-y-2 mb-6">
      {/* ドラッグ＆ドロップで並べ替え可能な未完了タスク */}
      <Reorder.Group
        axis="y"
        values={tasks}
        onReorder={handleReorder}
        className="reorder-group"
      >
        {tasks.map((task) => (
          <Reorder.Item 
            key={task.id} 
            value={task}
            dragListener={true}
            whileDrag={{ 
              scale: 1.02, 
              boxShadow: "0 5px 10px rgba(0,0,0,0.15)",
              zIndex: 10,
              opacity: 0.9
            }}
            transition={{ 
              type: "spring", 
              stiffness: 300, 
              damping: 20 
            }}
            className="reorder-item"
          >
            <TaskItem
              key={task.id}
              task={task}
              onStartTimer={handleStartTimer}
            />
          </Reorder.Item>
        ))}
      </Reorder.Group>
      
      {/* 完了済みタスク（ドラッグ不可） */}
      {sortedTasks.filter(task => task.isCompleted).map((task) => (
        <TaskItem 
          key={task.id} 
          task={task} 
          onStartTimer={handleStartTimer} 
        />
      ))}
      
      {/* Show message when no tasks */}
      {sortedTasks.length === 0 && (
        <div className="text-center py-10 text-gray-500">
          <div className="text-3xl mb-2">📝</div>
          <p>タスクがありません</p>
          <p className="text-sm">新しいタスクを追加してください</p>
        </div>
      )}
      
      {/* Timer Modal */}
      {activeTask && (
        <TaskTimerModal
          open={timerModalOpen}
          onOpenChange={setTimerModalOpen}
          task={activeTask}
          onComplete={handleTimerComplete}
        />
      )}
      
      {/* Completion Modal */}
      {activeTask && (
        <TaskCompletionModal
          open={completionModalOpen}
          onOpenChange={setCompletionModalOpen}
          task={activeTask}
          executionTime={executionTime}
        />
      )}
    </div>
  );
}