import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogClose 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RewardLocal } from '@shared/schema';

interface RewardSelectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (rewardId: string | null) => void;
  currentRewardId?: string | null;
}

export function RewardSelectionModal({ 
  open, 
  onOpenChange, 
  onSelect,
  currentRewardId = null
}: RewardSelectionModalProps) {
  const { rewards, getCollectedRewards } = useAppContext();
  const [selectedRewardId, setSelectedRewardId] = useState<string | null>(currentRewardId);
  
  // 獲得済みの報酬・罰ゲームのみを表示
  const collectedRewards = getCollectedRewards();
  const availableRewards = collectedRewards.filter(reward => !reward.isPenalty);
  const availablePenalties = collectedRewards.filter(reward => reward.isPenalty);
  
  // すべての報酬アイテムに「なし」オプションを追加
  const handleRewardSelect = (reward: RewardLocal | null) => {
    setSelectedRewardId(reward?.id || null);
  };
  
  const handleConfirm = () => {
    onSelect(selectedRewardId);
    onOpenChange(false);
  };
  
  const handleRemoveReward = () => {
    onSelect(null);
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>報酬・罰ゲームを選択</DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="rewards" className="py-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="rewards">報酬</TabsTrigger>
            <TabsTrigger value="penalties">罰ゲーム</TabsTrigger>
          </TabsList>
          
          <TabsContent value="rewards" className="mt-4 max-h-[300px] overflow-y-auto">
            {availableRewards.length > 0 ? (
              <div className="space-y-2">
                {availableRewards.map(reward => (
                  <div 
                    key={reward.id}
                    className={`p-3 rounded-lg cursor-pointer flex items-center ${
                      selectedRewardId === reward.id ? 'bg-primary/10' : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                    onClick={() => handleRewardSelect(reward)}
                  >
                    <span className="text-xl mr-3">{reward.emoji || '🎁'}</span>
                    <div>
                      <div className="font-medium">{reward.title}</div>
                      {reward.description && (
                        <div className="text-xs text-gray-500">{reward.description}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                まだ獲得した報酬がありません。<br />
                ガチャを回して報酬をゲットしましょう！
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="penalties" className="mt-4 max-h-[300px] overflow-y-auto">
            {availablePenalties.length > 0 ? (
              <div className="space-y-2">
                {availablePenalties.map(penalty => (
                  <div 
                    key={penalty.id}
                    className={`p-3 rounded-lg cursor-pointer flex items-center ${
                      selectedRewardId === penalty.id ? 'bg-primary/10' : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                    onClick={() => handleRewardSelect(penalty)}
                  >
                    <span className="text-xl mr-3">{penalty.emoji || '⚠️'}</span>
                    <div>
                      <div className="font-medium">{penalty.title}</div>
                      {penalty.description && (
                        <div className="text-xs text-gray-500">{penalty.description}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                まだ獲得した罰ゲームがありません。<br />
                ガチャを回して罰ゲームをゲットしましょう！<br />
                （罰ゲームも役立つことがあります）
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="flex gap-2">
          {currentRewardId && (
            <Button
              variant="outline"
              onClick={handleRemoveReward}
              className="text-red-500 hover:text-red-700"
            >
              削除
            </Button>
          )}
          <DialogClose asChild>
            <Button variant="outline">キャンセル</Button>
          </DialogClose>
          <Button onClick={handleConfirm}>
            選択
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}