import React from 'react';
import { useLocation, Link } from 'wouter';
import { cn } from '@/lib/utils';

export function TabBar() {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2 px-4 z-10">
      <div className="flex justify-around items-center">
        <Link href="/">
          <div className={cn(
            "flex flex-col items-center p-2 cursor-pointer",
            isActive('/') ? "text-primary" : "text-gray-500"
          )}>
            <i className="fas fa-tasks text-xl"></i>
            <span className="text-xs mt-1">タスク</span>
          </div>
        </Link>
        
        <Link href="/statistics">
          <div className={cn(
            "flex flex-col items-center p-2 cursor-pointer",
            isActive('/statistics') ? "text-primary" : "text-gray-500"
          )}>
            <i className="fas fa-chart-line text-xl"></i>
            <span className="text-xs mt-1">統計</span>
          </div>
        </Link>
        
        <div className="flex items-center justify-center">
          <Link href="/">
            <div className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center shadow-lg -mt-5 cursor-pointer">
              <i className="fas fa-plus text-xl"></i>
            </div>
          </Link>
        </div>
        
        <Link href="/gacha">
          <div className={cn(
            "flex flex-col items-center p-2 cursor-pointer",
            isActive('/gacha') ? "text-primary" : "text-gray-500"
          )}>
            <i className="fas fa-gift text-xl"></i>
            <span className="text-xs mt-1">ガチャ</span>
          </div>
        </Link>
        
        <Link href="/settings">
          <div className={cn(
            "flex flex-col items-center p-2 cursor-pointer",
            isActive('/settings') ? "text-primary" : "text-gray-500"
          )}>
            <i className="fas fa-user text-xl"></i>
            <span className="text-xs mt-1">設定</span>
          </div>
        </Link>
      </div>
    </div>
  );
}