import React, { useCallback, useState, useEffect } from 'react';
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTaskTimer, TimerMode } from '@/context/timer-context';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '@shared/schema';
import { cn } from '@/lib/utils';
import { Timer, Clock, Settings } from 'lucide-react';
import { Modal } from '@/components/Modal';

interface TaskTimerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskLocal;
  onComplete: (task: TaskLocal, startTime: Date, duration: number) => void;
}

export function TaskTimerModal({ 
  open, 
  onOpenChange, 
  task,
  onComplete
}: TaskTimerModalProps) {
  const { completeTask } = useAppContext();
  const timer = useTaskTimer();
  
  // 設定の状態管理
  const [showSettings, setShowSettings] = useState(false);
  const [customDuration, setCustomDuration] = useState(task.estimatedTime || 25);
  
  // このタスクのタイマー状態を取得
  const taskTimer = timer.getTaskTimer(task.id);
  
  // タイマー初期化
  useEffect(() => {
    // タスクの推定時間でタイマーを初期化
    if (task.estimatedTime && task.estimatedTime !== taskTimer.duration) {
      timer.setTimerDuration(task.id, task.estimatedTime);
      setCustomDuration(task.estimatedTime);
    }
  }, [task.id, task.estimatedTime, timer, taskTimer.duration]);
  
  const handleComplete = useCallback(() => {
    if (taskTimer.startTime) {
      const duration = taskTimer.mode === 'countdown' 
        ? Math.ceil(taskTimer.elapsedTime / 60)
        : Math.ceil(taskTimer.elapsedTime / 60);
      onComplete(task, taskTimer.startTime, duration);
      completeTask(task.id);
    }
    timer.stopTimer(task.id);
    onOpenChange(false);
  }, [task, taskTimer, onComplete, completeTask, timer, onOpenChange]);
  
  const handleCancel = () => {
    timer.stopTimer(task.id);
    onOpenChange(false);
  };
  
  // Calculate progress circle parameters
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const progress = timer.getProgress(task.id);
  const dashOffset = circumference * (1 - progress / 100);
  
  // コンテンツの表示モード切り替え
  const handleModeChange = (mode: TimerMode) => {
    timer.setTimerMode(task.id, mode);
  };
  
  // 時間設定の変更
  const handleDurationChange = (newDuration: number) => {
    setCustomDuration(newDuration);
    timer.setTimerDuration(task.id, newDuration);
  };
  
  // 設定メニュートグル
  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };
  
  // ショーケースモードとセッティングモードで表示内容を分ける
  const renderTimerContent = () => (
    <>
      <div className="flex items-center justify-center mb-2">
        <Tabs 
          value={taskTimer.mode} 
          onValueChange={(value) => handleModeChange(value as TimerMode)}
          className="mb-2"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="countdown" className="flex items-center gap-1">
              <Timer className="h-4 w-4" />
              <span>タイマー</span>
            </TabsTrigger>
            <TabsTrigger value="stopwatch" className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>ストップウォッチ</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Button
          variant="ghost"
          size="icon"
          className="ml-2"
          onClick={toggleSettings}
        >
          <Settings className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="flex justify-center my-4">
        <div className="relative">
          <svg className="w-48 h-48">
            <circle 
              r={radius} 
              cx="96" 
              cy="96" 
              fill="transparent" 
              stroke="#e5e7eb" 
              strokeWidth="8"
            />
            {taskTimer.mode === 'countdown' && (
              <circle 
                r={radius} 
                cx="96" 
                cy="96" 
                fill="transparent" 
                stroke="hsl(var(--primary))" 
                strokeWidth="8" 
                strokeDasharray={circumference} 
                strokeDashoffset={dashOffset}
                className="-rotate-90 transform origin-center"
              />
            )}
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-gray-800">{timer.getFormattedTime(task.id)}</div>
            <div className="text-sm text-gray-500">
              {taskTimer.mode === 'countdown' ? '残り時間' : '経過時間'}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex justify-center space-x-4 mb-4">
        <Button
          variant="outline"
          size="icon"
          className="w-12 h-12 rounded-full"
          onClick={() => timer.resetTimer(task.id)}
        >
          <i className="fas fa-redo"></i>
        </Button>
        
        <Button
          className={cn(
            "w-16 h-16 rounded-full flex items-center justify-center text-white",
            !taskTimer.isRunning && "bg-primary"
          )}
          onClick={() => {
            if (taskTimer.isRunning) {
              timer.pauseTimer(task.id);
            } else if (taskTimer.isPaused) {
              timer.resumeTimer(task.id);
            } else {
              timer.startTimer(task.id, taskTimer.mode, taskTimer.duration);
            }
          }}
        >
          <i className={cn("text-xl", taskTimer.isRunning ? "fas fa-pause" : "fas fa-play")}></i>
        </Button>
      </div>
    </>
  );

  // セッティングの表示内容
  const renderSettingsContent = () => (
    <div className="space-y-4 py-4">
      <div className="space-y-2">
        <Label htmlFor="duration">時間設定（分）</Label>
        <div className="flex items-center space-x-2">
          <Input
            id="duration"
            type="number"
            min="1"
            max="120"
            value={customDuration}
            onChange={(e) => {
              const value = e.target.value;
              // 空文字列の場合はそのままにする（数値変換しない）
              if (value === '') {
                setCustomDuration('' as any);
              } else {
                const numValue = parseInt(value);
                if (!isNaN(numValue)) {
                  handleDurationChange(numValue);
                }
              }
            }}
            onBlur={() => {
              // フォーカスを失ったときに空または無効な値ならデフォルト値を設定
              if (typeof customDuration === 'string' && (customDuration === '' || isNaN(Number(customDuration)))) {
                handleDurationChange(25);
              }
            }}
            className="w-20"
          />
          <span>分</span>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {[5, 10, 15, 25, 30, 45, 60].map((preset) => (
            <Button
              key={preset}
              variant={Number(customDuration) === preset ? "default" : "outline"}
              size="sm"
              onClick={() => handleDurationChange(preset)}
            >
              {preset}分
            </Button>
          ))}
        </div>
      </div>
    </div>
  );

  const renderFooter = () => {
    if (showSettings) {
      return (
        <Button
          variant="outline"
          onClick={toggleSettings}
        >
          戻る
        </Button>
      );
    }
    
    return (
      <>
        <Button variant="ghost" onClick={handleCancel}>
          キャンセル
        </Button>
        <Button 
          className="bg-green-500 hover:bg-green-600" 
          onClick={handleComplete}
        >
          完了
        </Button>
      </>
    );
  };
  
  return (
    <Modal
      open={open}
      onOpenChange={onOpenChange}
      title={task.title}
      description={showSettings ? '設定' : '集中タイム'}
      footer={renderFooter()}
    >
      {showSettings ? renderSettingsContent() : renderTimerContent()}
    </Modal>
  );
}