import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { useAppContext } from '@/context/app-context';
import { X } from 'lucide-react';
import { getCurrentWeekDates, formatSimpleDate } from '@/lib/dates';
import { cn } from '@/lib/utils';

interface WeeklyStatsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WeeklyStatsModal({ open, onOpenChange }: WeeklyStatsModalProps) {
  const { 
    weeklyData,
    weeklyAverageCompletionRate,
    taskGroups,
    tasks
  } = useAppContext();
  
  // Current week dates
  const currentWeekDates = getCurrentWeekDates(new Date());
  const weekDays = ['月', '火', '水', '木', '金', '土', '日'];
  
  // Get completion rates for each day
  const completionRates = currentWeekDates.map(date => {
    const dateStr = formatSimpleDate(date);
    const dayData = weeklyData.find(data => data.date === dateStr);
    return dayData ? dayData.completionRate : 0;
  });
  
  // Calculate stats
  const completedTasksCount = tasks.filter(task => task.isCompleted).length;
  
  // Calculate total execution time (in minutes)
  const totalExecutionTime = tasks
    .filter(task => task.actualTime !== undefined)
    .reduce((sum, task) => sum + (task.actualTime || 0), 0);
  
  // Format execution time (hours)
  const totalHours = (totalExecutionTime / 60).toFixed(1);
  
  // Calculate group completion rates
  const groupCompletionRates = taskGroups.map(group => {
    const groupTasks = tasks.filter(task => task.groupId === group.id);
    const totalGroupTasks = groupTasks.length;
    const completedGroupTasks = groupTasks.filter(task => task.isCompleted).length;
    
    const completionRate = totalGroupTasks > 0 
      ? Math.round((completedGroupTasks / totalGroupTasks) * 100) 
      : 0;
    
    return {
      group,
      completionRate
    };
  });
  
  // Sort by completion rate
  groupCompletionRates.sort((a, b) => b.completionRate - a.completionRate);
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex justify-between items-center">
          <DialogTitle className="text-lg font-bold">週間レポート</DialogTitle>
          <DialogClose className="text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4" />
          </DialogClose>
        </DialogHeader>
        
        <div className="mb-4">
          <div className="font-medium mb-2">達成率推移</div>
          <div className="h-40 bg-gray-100 rounded flex items-end p-2">
            {weekDays.map((day, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div 
                  className={cn(
                    "w-full",
                    completionRates[index] > 0 ? "bg-primary" : "bg-gray-300"
                  )}
                  style={{ height: `${completionRates[index]}%` }}
                ></div>
                <div className="text-xs mt-1">{day}</div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mb-4">
          <div className="font-medium mb-2">タスク実績</div>
          <div className="bg-gray-100 rounded p-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-2xl font-bold text-primary">{completedTasksCount}</div>
                <div className="text-xs text-gray-500">完了タスク数</div>
              </div>
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-2xl font-bold text-primary">{weeklyAverageCompletionRate}%</div>
                <div className="text-xs text-gray-500">平均達成率</div>
              </div>
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-2xl font-bold text-primary">{totalHours}h</div>
                <div className="text-xs text-gray-500">総実行時間</div>
              </div>
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-2xl font-bold text-green-500">+2</div>
                <div className="text-xs text-gray-500">ストリーク</div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="font-medium mb-2">グループ別達成率</div>
          <div className="space-y-2">
            {groupCompletionRates.map(({ group, completionRate }) => (
              <div key={group.id}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{group.name}</span>
                  <span>{completionRate}%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full" 
                    style={{ 
                      width: `${completionRate}%`,
                      backgroundColor: group.color 
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
