import React from 'react';
import { Label } from '@/components/ui/label';
import { Input, InputProps } from '@/components/ui/input';
import { Textarea, TextareaProps } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { withA11yProps } from '@/lib/accessibility-utils';

/**
 * アクセシビリティを強化したフォームフィールドグループ
 * ラベルと入力要素をセマンティックに関連付けます
 */
export function FormField({
  id,
  label,
  children,
  description,
  error,
  required = false,
}: {
  /** フィールドのユニークID */
  id: string;
  /** フィールドのラベルテキスト */
  label: string;
  /** フォーム要素（input, textareaなど） */
  children: React.ReactNode;
  /** オプションの説明文 */
  description?: string;
  /** エラーメッセージ */
  error?: string;
  /** 必須フィールドかどうか */
  required?: boolean;
}) {
  return (
    <div className="mb-4">
      <Label 
        htmlFor={id}
        className={`mb-1.5 block ${error ? 'text-destructive' : ''}`}
      >
        {label}
        {required && <span className="text-destructive ml-1" aria-hidden="true">*</span>}
        {required && <span className="sr-only">（必須）</span>}
      </Label>
      
      {description && (
        <p 
          id={`${id}-description`} 
          className="text-muted-foreground text-sm mb-1"
        >
          {description}
        </p>
      )}
      
      {children}
      
      {error && (
        <p 
          id={`${id}-error`} 
          className="text-destructive text-sm mt-1"
          role="alert"
        >
          {error}
        </p>
      )}
    </div>
  );
}

/**
 * アクセシビリティを強化した入力フィールド
 */
export function A11yInput({
  id,
  label,
  description,
  error,
  required = false,
  ...props
}: InputProps & {
  id: string;
  label: string;
  description?: string;
  error?: string;
  required?: boolean;
}) {
  // アクセシビリティ属性を設定
  const a11yProps = {
    'aria-required': required ? 'true' : undefined,
    'aria-invalid': error ? 'true' : undefined,
    'aria-describedby': 
      (description ? `${id}-description` : '') + 
      (error ? ` ${id}-error` : ''),
  };
  
  return (
    <FormField
      id={id}
      label={label}
      description={description}
      error={error}
      required={required}
    >
      <Input
        id={id}
        {...withA11yProps(props, a11yProps)}
      />
    </FormField>
  );
}

/**
 * アクセシビリティを強化したテキストエリア
 */
export function A11yTextarea({
  id,
  label,
  description,
  error,
  required = false,
  ...props
}: TextareaProps & {
  id: string;
  label: string;
  description?: string;
  error?: string;
  required?: boolean;
}) {
  // アクセシビリティ属性を設定
  const a11yProps = {
    'aria-required': required ? 'true' : undefined,
    'aria-invalid': error ? 'true' : undefined,
    'aria-describedby': 
      (description ? `${id}-description` : '') + 
      (error ? ` ${id}-error` : ''),
  };
  
  return (
    <FormField
      id={id}
      label={label}
      description={description}
      error={error}
      required={required}
    >
      <Textarea
        id={id}
        {...withA11yProps(props, a11yProps)}
      />
    </FormField>
  );
}