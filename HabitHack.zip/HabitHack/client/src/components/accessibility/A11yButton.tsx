import React from 'react';
import { Button, ButtonProps } from '@/components/ui/button';
import { withA11yProps } from '@/lib/accessibility-utils';
import type { HTMLAttributes } from 'react';

/**
 * アクセシビリティを強化したボタンコンポーネント
 * 適切なaria属性が追加されます
 */
export function A11yButton({
  children,
  action,
  ...props
}: ButtonProps & {
  /** スクリーンリーダー向けのボタンアクション説明 */
  action?: string;
}) {
  // action説明がある場合はaria-labelを追加
  const a11yProps: Record<string, string | undefined> = action ? { 'aria-label': action } : {};
  
  return (
    <Button {...withA11yProps(props, a11yProps)}>
      {children}
    </Button>
  );
}

/**
 * アイコンのみのボタン用のアクセシブルなラッパー
 * アイコンボタンには常にaria-labelが必要
 */
export function A11yIconButton({
  children,
  label,
  ...props
}: ButtonProps & {
  /** スクリーンリーダー向けの説明（必須） */
  label: string;
}) {
  return (
    <Button 
      {...withA11yProps(props, {
        'aria-label': label,
        'role': 'button' as string
      })}
    >
      {children}
    </Button>
  );
}