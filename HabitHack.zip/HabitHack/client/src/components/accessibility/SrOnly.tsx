import React from 'react';
import { srOnlyClass } from '@/lib/accessibility-utils';

/**
 * スクリーンリーダーのみに表示されるテキストコンポーネント
 * 視覚的に隠しながらスクリーンリーダーに情報を伝えるために使用
 * 
 * @param text 読み上げるテキスト
 * @returns JSX要素
 */
export function SrOnly({ text }: { text: string }) {
  return <span className={srOnlyClass}>{text}</span>;
}

/**
 * 視覚的な要素にスクリーンリーダー用の代替テキストを提供
 * 
 * @param props.visual 視覚的に表示される要素
 * @param props.screenReaderText スクリーンリーダーに読み上げられるテキスト
 * @returns JSX要素
 */
export function A11yAnnounce({
  visual,
  screenReaderText
}: {
  visual: React.ReactNode;
  screenReaderText: string;
}) {
  return (
    <span className="relative">
      <span aria-hidden="true">{visual}</span>
      <span className={srOnlyClass}>{screenReaderText}</span>
    </span>
  );
}