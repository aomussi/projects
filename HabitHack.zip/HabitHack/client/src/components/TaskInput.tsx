import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  DialogFooter,
  DialogClose 
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from "@/components/ui/popover";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { useAppContext } from '@/context/app-context';
import { GroupSelectionModal } from './GroupSelectionModal';
import { RecurrencePattern } from '@shared/schema';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { getToday, parseDate, formatSimpleDate } from '@/lib/dates';
import { CalendarIcon, Settings } from 'lucide-react';
import { Modal } from '@/components/Modal';

export function TaskInput() {
  const { addTask, taskGroups, currentDate } = useAppContext();
  const [taskTitle, setTaskTitle] = useState('');
  const [isRecurringTask, setIsRecurringTask] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [groupModalOpen, setGroupModalOpen] = useState(false);
  const [recurrenceModalOpen, setRecurrenceModalOpen] = useState(false);
  
  // 周期タスクの設定
  const [recurrenceType, setRecurrenceType] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [recurrenceInterval, setRecurrenceInterval] = useState(1);
  const [selectedWeekdays, setSelectedWeekdays] = useState<number[]>([]);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [occurrences, setOccurrences] = useState<number>(10);
  const [hasEndDate, setHasEndDate] = useState(false);
  const [hasOccurrences, setHasOccurrences] = useState(true);
  
  const selectedGroup = selectedGroupId 
    ? taskGroups.find(group => group.id === selectedGroupId)
    : null;
  
  const handleAddTask = () => {
    if (taskTitle.trim()) {
      // 周期タスクの設定を準備
      let recurrencePattern: RecurrencePattern | undefined;
      
      if (isRecurringTask) {
        recurrencePattern = {
          type: recurrenceType,
          interval: recurrenceInterval,
          weekdays: recurrenceType === 'weekly' ? selectedWeekdays : undefined,
          endDate: hasEndDate && endDate ? formatSimpleDate(endDate) : undefined,
          occurrences: hasOccurrences ? occurrences : undefined
        };
      }
      
      addTask({
        title: taskTitle.trim(),
        isCompleted: false,
        isRecurring: isRecurringTask,
        date: currentDate,
        groupId: selectedGroupId,
        recurrencePattern
      });
      
      // Reset input
      setTaskTitle('');
      
      // 周期タスクを追加した後、周期タスクの設定をリセット
      if (isRecurringTask) {
        setRecurrenceType('daily');
        setRecurrenceInterval(1);
        setSelectedWeekdays([]);
        setEndDate(undefined);
        setOccurrences(10);
        setHasEndDate(false);
        setHasOccurrences(true);
      }
    }
  };
  
  const handleToggleTaskType = () => {
    setIsRecurringTask(!isRecurringTask);
    
    // 周期タスクの設定モーダルは自動的に開かないように修正
    // ユーザーが明示的に設定ボタンをクリックした場合のみ開く
  };
  
  const getTaskTypeColor = () => {
    return isRecurringTask ? 'bg-blue-500' : 'bg-green-500';
  };
  
  const getTaskTypeIndicator = () => {
    return isRecurringTask ? (
      <>
        <span className="w-3 h-3 rounded-full bg-blue-500 mr-1"></span>
        <span>周期タスク</span>
      </>
    ) : (
      <>
        <span className="w-3 h-3 rounded-full bg-green-500 mr-1"></span>
        <span>単発タスク</span>
      </>
    );
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddTask();
    }
  };
  
  const toggleWeekday = (day: number) => {
    setSelectedWeekdays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day]
    );
  };
  
  const getRecurrenceSummary = () => {
    if (!isRecurringTask) return '単発タスク';
    
    switch (recurrenceType) {
      case 'daily':
        return recurrenceInterval === 1 ? '毎日' : `${recurrenceInterval}日ごと`;
      case 'weekly':
        if (selectedWeekdays.length === 0) {
          return recurrenceInterval === 1 ? '毎週' : `${recurrenceInterval}週間ごと`;
        } else {
          const dayNames = ['日', '月', '火', '水', '木', '金', '土'];
          const days = selectedWeekdays.sort().map(d => dayNames[d]).join('・');
          return recurrenceInterval === 1 
            ? `毎週 ${days}曜日` 
            : `${recurrenceInterval}週間ごと ${days}曜日`;
        }
      case 'monthly':
        return recurrenceInterval === 1 ? '毎月' : `${recurrenceInterval}ヶ月ごと`;
      default:
        return '周期タスク';
    }
  };

  const renderRecurrenceModalFooter = () => (
    <>
      <DialogClose asChild>
        <Button variant="outline">キャンセル</Button>
      </DialogClose>
      <Button onClick={() => setRecurrenceModalOpen(false)}>
        設定を保存
      </Button>
    </>
  );
  
  return (
    <>
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center">
            <Input
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="新しいタスクを追加"
              className="flex-1 border-b border-gray-200 focus-visible:ring-0 focus-visible:ring-offset-0 py-2 px-0"
            />
            <div className="flex ml-2">
              <Button
                size="icon"
                className={cn("mr-2 rounded-full", getTaskTypeColor())}
                onClick={handleToggleTaskType}
                aria-label="タスクタイプ切替"
              >
                <i className="fas fa-bolt"></i>
              </Button>
              <Button
                size="icon"
                className="rounded-full"
                onClick={handleAddTask}
                aria-label="タスク追加"
              >
                <i className="fas fa-plus"></i>
              </Button>
            </div>
          </div>
          
          <div className="flex mt-2 text-sm">
            <div className="flex items-center mr-4">
              {getTaskTypeIndicator()}
              {isRecurringTask && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-1 p-0 h-auto"
                  onClick={() => setRecurrenceModalOpen(true)}
                >
                  <Settings className="h-3 w-3 mr-1" />
                  <span className="text-xs">{getRecurrenceSummary()}</span>
                </Button>
              )}
            </div>
            
            <Button
              variant="ghost"
              className="flex items-center text-gray-500 p-0 h-auto"
              onClick={() => setGroupModalOpen(true)}
            >
              <i className="fas fa-tag mr-1"></i>
              <span>{selectedGroup ? selectedGroup.name : 'グループ'}</span>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* グループ選択モーダル */}
      <GroupSelectionModal
        open={groupModalOpen}
        onOpenChange={setGroupModalOpen}
        onSelect={setSelectedGroupId}
      />
      
      {/* 周期タスク設定モーダル */}
      <Modal
        open={recurrenceModalOpen}
        onOpenChange={setRecurrenceModalOpen}
        title="周期タスクの設定"
        footer={renderRecurrenceModalFooter()}
      >
        <div className="space-y-4 py-2">
          {/* 周期タイプの選択 */}
          <div className="space-y-2">
            <Label>周期タイプ</Label>
            <Select
              value={recurrenceType}
              onValueChange={(value) => setRecurrenceType(value as 'daily' | 'weekly' | 'monthly')}
            >
              <SelectTrigger>
                <SelectValue placeholder="周期タイプを選択" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">毎日</SelectItem>
                <SelectItem value="weekly">毎週</SelectItem>
                <SelectItem value="monthly">毎月</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* 周期の間隔 */}
          <div className="space-y-2">
            <Label>間隔</Label>
            <div className="flex items-center">
              <Input
                type="number"
                min="1"
                value={recurrenceInterval}
                onChange={(e) => setRecurrenceInterval(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 mr-2"
              />
              <span>
                {recurrenceType === 'daily' && '日ごと'}
                {recurrenceType === 'weekly' && '週間ごと'}
                {recurrenceType === 'monthly' && 'ヶ月ごと'}
              </span>
            </div>
          </div>
          
          {/* 週次の場合は曜日選択 */}
          {recurrenceType === 'weekly' && (
            <div className="space-y-2">
              <Label>曜日を選択</Label>
              <div className="flex flex-wrap gap-2">
                {['日', '月', '火', '水', '木', '金', '土'].map((day, idx) => (
                  <Button
                    key={idx}
                    type="button"
                    variant={selectedWeekdays.includes(idx) ? "default" : "outline"}
                    className="w-10 h-10 rounded-full"
                    onClick={() => toggleWeekday(idx)}
                  >
                    {day}
                  </Button>
                ))}
              </div>
            </div>
          )}
          
          {/* 終了設定 */}
          <div className="space-y-2">
            <Label>終了設定</Label>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="has-end-date"
                checked={hasEndDate}
                onCheckedChange={(checked) => {
                  setHasEndDate(!!checked);
                  if (checked) setHasOccurrences(false);
                }}
              />
              <Label htmlFor="has-end-date" className="cursor-pointer">終了日を指定</Label>
            </div>
            
            {hasEndDate && (
              <div className="ml-6">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? formatSimpleDate(endDate) : '終了日を選択'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={setEndDate}
                      initialFocus
                      disabled={(date) => date < parseDate(currentDate)}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            )}
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="has-occurrences"
                checked={hasOccurrences}
                onCheckedChange={(checked) => {
                  setHasOccurrences(!!checked);
                  if (checked) setHasEndDate(false);
                }}
              />
              <Label htmlFor="has-occurrences" className="cursor-pointer">繰り返し回数を指定</Label>
            </div>
            
            {hasOccurrences && (
              <div className="ml-6 flex items-center">
                <Input
                  type="number"
                  min="1"
                  value={occurrences}
                  onChange={(e) => setOccurrences(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-20 mr-2"
                />
                <span>回</span>
              </div>
            )}
            
            {!hasEndDate && !hasOccurrences && (
              <div className="text-sm text-muted-foreground">
                終了条件が設定されていません。デフォルト（10回）が使用されます。
              </div>
            )}
          </div>
        </div>
      </Modal>
    </>
  );
}