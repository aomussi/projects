import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/app-context';
import { RewardLocal } from '@shared/schema';
import { getToday } from '@/lib/dates';
import { cn } from '@/lib/utils';
import { TaskDateModal } from './TaskDateModal';
import { Calendar } from 'lucide-react';
import { Modal } from '@/components/Modal';

interface GachaResultModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reward: RewardLocal;
  onSkip?: () => void; // スキップボタンを押したときの処理を追加
}

export function GachaResultModal({ open, onOpenChange, reward, onSkip }: GachaResultModalProps) {
  const [dateModalOpen, setDateModalOpen] = useState(false);
  
  const handleAddToTask = () => {
    // データ選択モーダルを開く
    setDateModalOpen(true);
  };
  
  // モーダルが閉じられたときの処理
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setDateModalOpen(false);
    }
    onOpenChange(open);
  };
  
  // スキップボタンのクリックハンドラー
  const handleSkip = () => {
    if (onSkip) {
      onSkip();
    } else {
      onOpenChange(false);
    }
  };
  
  const getRarityText = () => {
    if (reward.isPenalty) {
      return "罰ゲーム";
    }
    
    switch (reward.rarity) {
      case 3:
        return "超レア報酬";
      case 2:
        return "レア報酬";
      default:
        return "お楽しみ報酬";
    }
  };
  
  const getBackgroundColor = () => {
    if (reward.isPenalty) {
      return "bg-red-100";
    }
    
    switch (reward.rarity) {
      case 3:
        return "bg-purple-100";
      case 2:
        return "bg-blue-100";
      default:
        return "bg-yellow-100";
    }
  };
  
  return (
    <>
      <Modal 
        open={open} 
        onOpenChange={handleOpenChange}
        showCloseButton={false}
      >
        <div className="text-center mb-6">
          <div className={cn("inline-block p-4 rounded-full mb-3", getBackgroundColor())}>
            <span className="text-6xl">{reward.emoji || "🎁"}</span>
          </div>
          <h2 className="text-xl font-bold text-gray-800">{reward.title}</h2>
          <div className={cn(
            "text-sm px-2 py-1 rounded-full inline-block mt-2",
            reward.isPenalty ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"
          )}>
            {getRarityText()}
          </div>
        </div>
        
        <div className="text-center mb-6">
          <p className="text-gray-600">{reward.description || "お疲れ様でした！ご褒美の時間です。"}</p>
        </div>
        
        <div className="flex justify-between">
          <Button variant="ghost" onClick={handleSkip}>
            スキップ
          </Button>
          <Button onClick={handleAddToTask} className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            タスクに追加
          </Button>
        </div>
      </Modal>
      
      <TaskDateModal 
        open={dateModalOpen} 
        onOpenChange={setDateModalOpen}
        reward={reward}
        onComplete={() => {
          setDateModalOpen(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}