import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  getDaysInMonth, 
  formatYearMonth, 
  getCalendarDaysWithPadding, 
  formatSimpleDate, 
  isCurrentDay 
} from '@/lib/dates';
import { useAppContext } from '@/context/app-context';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CalendarModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CalendarModal({ open, onOpenChange }: CalendarModalProps) {
  const { currentDate, setCurrentDate } = useAppContext();
  
  const [viewDate, setViewDate] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1 };
  });

  // Go to previous month
  const prevMonth = () => {
    setViewDate(prev => {
      if (prev.month === 1) {
        return { year: prev.year - 1, month: 12 };
      }
      return { year: prev.year, month: prev.month - 1 };
    });
  };

  // Go to next month
  const nextMonth = () => {
    setViewDate(prev => {
      if (prev.month === 12) {
        return { year: prev.year + 1, month: 1 };
      }
      return { year: prev.year, month: prev.month + 1 };
    });
  };

  // Select a date
  const selectDate = (date: Date | null) => {
    if (date) {
      setCurrentDate(formatSimpleDate(date));
      onOpenChange(false);
    }
  };

  // Get the calendar days (with padding)
  const calendarDays = getCalendarDaysWithPadding(viewDate.year, viewDate.month);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="flex justify-between items-center">
          <DialogTitle className="text-lg font-bold">カレンダー</DialogTitle>
          <DialogClose className="text-gray-500 hover:text-gray-700">
            <X className="h-4 w-4" />
          </DialogClose>
        </DialogHeader>
        
        <div className="flex justify-between items-center mb-2">
          <Button variant="ghost" size="icon" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="font-medium">{formatYearMonth(new Date(viewDate.year, viewDate.month - 1))}</div>
          <Button variant="ghost" size="icon" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="grid grid-cols-7 gap-1 text-center">
          {['日', '月', '火', '水', '木', '金', '土'].map((day, i) => (
            <div key={i} className="text-sm text-gray-500">{day}</div>
          ))}
          
          {calendarDays.map((day, i) => (
            <Button
              key={i}
              variant="ghost"
              className={cn(
                "p-2 text-center text-sm rounded-full h-auto aspect-square",
                day && isCurrentDay(formatSimpleDate(day)) && "bg-primary text-white hover:bg-primary/90",
                !day && "opacity-30 cursor-default"
              )}
              onClick={() => selectDate(day)}
              disabled={!day}
            >
              {day ? day.getDate() : ''}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
