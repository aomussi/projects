import React, { useCallback, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTimer, TimerMode } from '@/hooks/use-timer';
import { useAppContext } from '@/context/app-context';
import { TaskLocal } from '@shared/schema';
import { cn } from '@/lib/utils';
import { Timer, Clock, Settings } from 'lucide-react';

interface TaskTimerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: TaskLocal;
  onComplete: (task: TaskLocal, startTime: Date, duration: number) => void;
}

export function TaskTimerModal({ 
  open, 
  onOpenChange, 
  task,
  onComplete
}: TaskTimerModalProps) {
  const { completeTask } = useAppContext();
  
  // タイマーの設定
  const [timerMode, setTimerMode] = useState<TimerMode>('countdown');
  const [showSettings, setShowSettings] = useState(false);
  const [customDuration, setCustomDuration] = useState(task.estimatedTime || 25);
  
  // Use timer with estimated time or default to 25 minutes
  const { 
    timeLeft,
    isRunning,
    isPaused,
    progress,
    startTime,
    elapsedTime,
    timerMode: currentTimerMode,
    customDuration: currentDuration,
    getElapsedTimeInMinutes,
    toggle,
    reset,
    stop,
    getFormattedTime,
    switchMode,
    setDuration
  } = useTimer({
    duration: customDuration,
    mode: timerMode,
    onComplete: () => {
      // Auto-complete when timer ends
      handleComplete();
    }
  });
  
  const handleComplete = useCallback(() => {
    if (startTime) {
      onComplete(task, startTime, getElapsedTimeInMinutes());
      completeTask(task.id);
    }
  }, [task, startTime, getElapsedTimeInMinutes, onComplete, completeTask]);
  
  const handleCancel = () => {
    stop();
    onOpenChange(false);
  };
  
  // Calculate progress circle parameters
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - progress / 100);
  
  // コンテンツの表示モード切り替え
  const handleModeChange = (mode: TimerMode) => {
    switchMode(mode);
    setTimerMode(mode);
  };
  
  // 時間設定の変更
  const handleDurationChange = (newDuration: number) => {
    setCustomDuration(newDuration);
    setDuration(newDuration);
  };
  
  // 設定メニュートグル
  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">{task.title}</DialogTitle>
          <DialogDescription className="text-center">
            {showSettings ? '設定' : '集中タイム'}
          </DialogDescription>
        </DialogHeader>
        
        {!showSettings ? (
          // タイマー画面
          <>
            <div className="flex items-center justify-center mb-2">
              <Tabs 
                value={timerMode} 
                onValueChange={(value) => handleModeChange(value as TimerMode)}
                className="mb-2"
              >
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="countdown" className="flex items-center gap-1">
                    <Timer className="h-4 w-4" />
                    <span>タイマー</span>
                  </TabsTrigger>
                  <TabsTrigger value="stopwatch" className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>ストップウォッチ</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              
              <Button
                variant="ghost"
                size="icon"
                className="ml-2"
                onClick={toggleSettings}
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex justify-center my-4">
              <div className="relative">
                <svg className="w-48 h-48">
                  <circle 
                    r={radius} 
                    cx="96" 
                    cy="96" 
                    fill="transparent" 
                    stroke="#e5e7eb" 
                    strokeWidth="8"
                  />
                  {timerMode === 'countdown' && (
                    <circle 
                      r={radius} 
                      cx="96" 
                      cy="96" 
                      fill="transparent" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth="8" 
                      strokeDasharray={circumference} 
                      strokeDashoffset={dashOffset}
                      className="-rotate-90 transform origin-center"
                    />
                  )}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-4xl font-bold text-gray-800">{getFormattedTime()}</div>
                  <div className="text-sm text-gray-500">
                    {timerMode === 'countdown' ? '残り時間' : '経過時間'}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center space-x-4 mb-4">
              <Button
                variant="outline"
                size="icon"
                className="w-12 h-12 rounded-full"
                onClick={reset}
              >
                <i className="fas fa-redo"></i>
              </Button>
              
              <Button
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center text-white",
                  !isRunning && "bg-primary"
                )}
                onClick={toggle}
              >
                <i className={cn("text-xl", isRunning ? "fas fa-pause" : "fas fa-play")}></i>
              </Button>
            </div>
            
            <DialogFooter>
              <Button variant="ghost" onClick={handleCancel}>
                キャンセル
              </Button>
              <Button 
                className="bg-green-500 hover:bg-green-600" 
                onClick={handleComplete}
              >
                完了
              </Button>
            </DialogFooter>
          </>
        ) : (
          // 設定画面
          <>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="duration">時間設定（分）</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    id="duration"
                    type="number"
                    min="1"
                    max="120"
                    value={customDuration}
                    onChange={(e) => {
                      const value = e.target.value;
                      // 空文字列の場合はそのままにする（数値変換しない）
                      if (value === '') {
                        setCustomDuration('' as any);
                      } else {
                        const numValue = parseInt(value);
                        if (!isNaN(numValue)) {
                          handleDurationChange(numValue);
                        }
                      }
                    }}
                    onBlur={() => {
                      // フォーカスを失ったときに空または無効な値ならデフォルト値を設定
                      if (typeof customDuration === 'string' && (customDuration === '' || isNaN(Number(customDuration)))) {
                        handleDurationChange(25);
                      }
                    }}
                    className="w-20"
                  />
                  <span>分</span>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {[5, 10, 15, 25, 30, 45, 60].map((preset) => (
                    <Button
                      key={preset}
                      variant={Number(customDuration) === preset ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleDurationChange(preset)}
                    >
                      {preset}分
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={toggleSettings}
              >
                戻る
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
