import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useLocalStorage } from '../../client/src/hooks/use-local-storage';

describe('useLocalStorage Hook', () => {
  // ローカルストレージのモック
  const localStorageMock = (() => {
    let store: Record<string, string> = {};
    return {
      getItem: vi.fn((key: string) => store[key] || null),
      setItem: vi.fn((key: string, value: string) => {
        store[key] = value.toString();
      }),
      removeItem: vi.fn((key: string) => {
        delete store[key];
      }),
      clear: vi.fn(() => {
        store = {};
      })
    };
  })();

  // windowのlocalStorageをモックに置き換え
  Object.defineProperty(window, 'localStorage', {
    value: localStorageMock
  });

  // 各テスト前にストレージをクリア
  beforeEach(() => {
    localStorageMock.clear();
    vi.clearAllMocks();
    
    // console.logをモック化
    vi.spyOn(console, 'log').mockImplementation(() => {});
  });

  it('初期値を正しく設定する', () => {
    const { result } = renderHook(() => useLocalStorage('testKey', 'initialValue'));
    
    expect(result.current[0]).toBe('initialValue');
    expect(localStorageMock.getItem).toHaveBeenCalledWith('testKey');
  });

  it('localStorageから既存の値を取得する', () => {
    // あらかじめlocalStorageに値を設定
    localStorageMock.setItem('existingKey', JSON.stringify('storedValue'));
    
    const { result } = renderHook(() => useLocalStorage('existingKey', 'defaultValue'));
    
    expect(result.current[0]).toBe('storedValue');
    expect(localStorageMock.getItem).toHaveBeenCalledWith('existingKey');
  });

  it('setValue関数で値を更新する', () => {
    const { result } = renderHook(() => useLocalStorage('updateKey', 'initialValue'));
    
    act(() => {
      result.current[1]('newValue');
    });
    
    expect(result.current[0]).toBe('newValue');
    expect(localStorageMock.setItem).toHaveBeenCalledWith('updateKey', JSON.stringify('newValue'));
  });

  it('setValue関数で関数的更新ができる', () => {
    const { result } = renderHook(() => useLocalStorage('functionKey', 'value'));
    
    act(() => {
      result.current[1](prev => prev + '-updated');
    });
    
    expect(result.current[0]).toBe('value-updated');
    expect(localStorageMock.setItem).toHaveBeenCalledWith('functionKey', JSON.stringify('value-updated'));
  });

  it('JSONパースエラー時に初期値を返す', () => {
    // 無効なJSONを設定
    localStorageMock.getItem.mockReturnValueOnce('invalid json');
    
    const { result } = renderHook(() => useLocalStorage('errorKey', 'fallbackValue'));
    
    expect(result.current[0]).toBe('fallbackValue');
    expect(console.log).toHaveBeenCalled(); // エラーログが出力される
  });
});