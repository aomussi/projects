import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import express from 'express';
import { storage } from '../../server/storage';
import { setupPassport } from '../../server/auth';
import cookieParser from 'cookie-parser';
import passport from 'passport';

describe('認証APIのテスト', () => {
  const app = express();
  
  // テスト用にExpressアプリを設定
  beforeAll(() => {
    app.use(express.json());
    app.use(cookieParser());
    app.use(passport.initialize());
    
    // Passportの設定
    setupPassport();
    
    // 認証ルート
    app.post('/api/register', async (req, res) => {
      try {
        const existingUser = await storage.getUserByUsername(req.body.username);
        
        if (existingUser) {
          return res.status(400).json({ message: 'このユーザー名は既に使用されています' });
        }
        
        const user = await storage.createUser(req.body);
        const { password, ...userInfo } = user;
        return res.status(201).json(userInfo);
      } catch (error) {
        return res.status(500).json({ message: 'ユーザー登録に失敗しました' });
      }
    });
    
    app.post('/api/login', (req, res, next) => {
      passport.authenticate('local', { session: false }, (err, user) => {
        if (err || !user) {
          return res.status(401).json({ message: 'ログインに失敗しました' });
        }
        
        const { password, ...userInfo } = user;
        return res.json(userInfo);
      })(req, res, next);
    });
  });
  
  it('ユーザー登録に成功する', async () => {
    const userData = {
      username: 'testuser',
      password: 'password123'
    };
    
    const response = await request(app)
      .post('/api/register')
      .send(userData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('username', userData.username);
    expect(response.body).not.toHaveProperty('password');
  });
  
  it('既存のユーザー名で登録するとエラーになる', async () => {
    const userData = {
      username: 'testuser',
      password: 'password123'
    };
    
    const response = await request(app)
      .post('/api/register')
      .send(userData)
      .expect('Content-Type', /json/)
      .expect(400);
    
    expect(response.body).toHaveProperty('message');
  });
  
  it('正しい認証情報でログインできる', async () => {
    const userData = {
      username: 'testuser',
      password: 'password123'
    };
    
    const response = await request(app)
      .post('/api/login')
      .send(userData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('username', userData.username);
    expect(response.body).not.toHaveProperty('password');
  });
  
  it('不正な認証情報ではログインできない', async () => {
    const userData = {
      username: 'testuser',
      password: 'wrongpassword'
    };
    
    await request(app)
      .post('/api/login')
      .send(userData)
      .expect(401);
  });
});