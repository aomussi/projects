import { describe, it, expect, beforeAll, beforeEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { storage } from '../../server/storage';
import { setupPassport } from '../../server/auth';
import cookieParser from 'cookie-parser';
import passport from 'passport';

describe('タスクAPIのテスト', () => {
  const app = express();
  let authToken: string;
  let userId: number;
  
  // テスト用にExpressアプリを設定
  beforeAll(async () => {
    app.use(express.json());
    app.use(cookieParser());
    app.use(passport.initialize());
    
    // Passportの設定
    setupPassport();
    
    // ユーザー認証を模擬するミドルウェア
    const mockAuthMiddleware = (req: any, res: any, next: any) => {
      req.userId = userId;
      next();
    };
    
    // タスク取得API
    app.get('/api/tasks', mockAuthMiddleware, async (req, res) => {
      try {
        // ユーザーIDが存在することを確認
        if (!req.userId) {
          return res.status(401).json({ message: '認証が必要です' });
        }
        
        const tasks = await storage.getTasks(req.userId);
        res.json(tasks);
      } catch (error) {
        res.status(500).json({ message: 'タスクの取得に失敗しました' });
      }
    });
    
    // タスク作成API
    app.post('/api/tasks', mockAuthMiddleware, async (req, res) => {
      try {
        const task = await storage.createTask({
          ...req.body,
          userId: req.userId
        });
        res.status(201).json(task);
      } catch (error) {
        res.status(500).json({ message: 'タスクの作成に失敗しました' });
      }
    });
    
    // タスク更新API
    app.put('/api/tasks/:id', mockAuthMiddleware, async (req, res) => {
      try {
        const taskId = parseInt(req.params.id, 10);
        const updatedTask = await storage.updateTask(taskId, req.body);
        
        if (!updatedTask) {
          return res.status(404).json({ message: 'タスクが見つかりません' });
        }
        
        res.json(updatedTask);
      } catch (error) {
        res.status(500).json({ message: 'タスクの更新に失敗しました' });
      }
    });
    
    // タスク削除API
    app.delete('/api/tasks/:id', mockAuthMiddleware, async (req, res) => {
      try {
        const taskId = parseInt(req.params.id, 10);
        const deleted = await storage.deleteTask(taskId);
        
        if (!deleted) {
          return res.status(404).json({ message: 'タスクが見つかりません' });
        }
        
        res.status(204).end();
      } catch (error) {
        res.status(500).json({ message: 'タスクの削除に失敗しました' });
      }
    });
    
    // テストユーザーを作成
    const testUser = await storage.createUser({
      username: 'taskuser',
      password: 'password123'
    });
    
    userId = testUser.id;
  });
  
  it('タスクを作成できる', async () => {
    const taskData = {
      title: 'テストタスク',
      date: '2025-04-29',
      isCompleted: false,
      isRecurring: false
    };
    
    const response = await request(app)
      .post('/api/tasks')
      .send(taskData)
      .expect('Content-Type', /json/)
      .expect(201);
    
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('title', taskData.title);
    expect(response.body).toHaveProperty('date', taskData.date);
    expect(response.body).toHaveProperty('isCompleted', taskData.isCompleted);
    expect(response.body).toHaveProperty('userId', userId);
  });
  
  it('タスクを取得できる', async () => {
    const response = await request(app)
      .get('/api/tasks')
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(Array.isArray(response.body)).toBe(true);
    expect(response.body.length).toBeGreaterThan(0);
  });
  
  it('タスクを更新できる', async () => {
    // タスクを作成
    const createResponse = await request(app)
      .post('/api/tasks')
      .send({
        title: '更新するタスク',
        date: '2025-04-29',
        isCompleted: false,
        isRecurring: false
      });
    
    const taskId = createResponse.body.id;
    
    // タスクを更新
    const updateData = {
      title: '更新されたタスク',
      isCompleted: true
    };
    
    const response = await request(app)
      .put(`/api/tasks/${taskId}`)
      .send(updateData)
      .expect('Content-Type', /json/)
      .expect(200);
    
    expect(response.body).toHaveProperty('id', taskId);
    expect(response.body).toHaveProperty('title', updateData.title);
    expect(response.body).toHaveProperty('isCompleted', updateData.isCompleted);
  });
  
  it('タスクを削除できる', async () => {
    // タスクを作成
    const createResponse = await request(app)
      .post('/api/tasks')
      .send({
        title: '削除するタスク',
        date: '2025-04-29',
        isCompleted: false,
        isRecurring: false
      });
    
    const taskId = createResponse.body.id;
    
    // タスクを削除
    await request(app)
      .delete(`/api/tasks/${taskId}`)
      .expect(204);
    
    // 削除されたタスクを取得しようとするとエラーになることを確認
    await request(app)
      .put(`/api/tasks/${taskId}`)
      .send({ title: 'このタスクは存在しない' })
      .expect(404);
  });
});