/**
 * 安全なシークレットキーを生成するためのユーティリティスクリプト
 * 
 * 使用方法:
 * node scripts/generate-secrets.js
 * 
 * 出力例:
 * JWT_SECRET=f8a7sd6f7asd6f7asd6f7asd6f7asd6f7asd6f7asd6f7asd6f7asd6
 * SESSION_SECRET=a8s7df6a8s7df68as7df68a7sdf6a87sdf6a87sdf687asdf68
 */

const crypto = require('crypto');

// 64バイト（512ビット）のランダムバイトを生成して16進数文字列に変換
function generateSecureSecret() {
  return crypto.randomBytes(64).toString('hex');
}

// JWT用のシークレットキーを生成
const jwtSecret = generateSecureSecret();
console.log(`JWT_SECRET=${jwtSecret}`);

// セッション用のシークレットキーを生成
const sessionSecret = generateSecureSecret();
console.log(`SESSION_SECRET=${sessionSecret}`);

console.log('\n上記の値を.envファイルにコピーして使用してください。');
console.log('本番環境では、必ず安全なシークレットキーを使用してください。');