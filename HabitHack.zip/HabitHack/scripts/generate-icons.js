// アイコン生成スクリプト
// SVGアイコンから各種サイズのPNGを生成するためのスクリプト

const fs = require('fs');
const path = require('path');

// 基本的なPNGアイコンデータ（Base64エンコード）
// これは簡易的なアイコンで、実際のプロジェクトでは適切なツールで生成することを推奨
const generateBasicIcon = (size) => {
  console.log(`Generating ${size}x${size} icon...`);
  
  // 簡易的なアイコンファイルを作成
  // 実際の環境では、SVGからPNGに変換するツール（sharp、canvas、puppeteerなど）を使用
  const iconContent = `<svg width="${size}" height="${size}" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="96" fill="#2196F3"/>
    <g transform="translate(128, 128)">
      <rect x="0" y="0" width="256" height="256" rx="32" fill="white"/>
      <circle cx="64" cy="80" r="16" fill="#10B981"/>
      <rect x="96" y="72" width="128" height="16" fill="#D1D5DB"/>
      <circle cx="64" cy="128" r="16" fill="#6B7280"/>
      <rect x="96" y="120" width="128" height="16" fill="#D1D5DB"/>
      <circle cx="64" cy="176" r="16" fill="#6B7280"/>
      <rect x="96" y="168" width="128" height="16" fill="#D1D5DB"/>
    </g>
  </svg>`;
  
  return iconContent;
};

// アイコンサイズの配列
const sizes = [72, 96, 128, 144, 152, 192, 384, 512];

// public/iconsディレクトリが存在しない場合は作成
const iconsDir = path.join(__dirname, '..', 'public', 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

console.log('PWAアイコン生成スクリプト');
console.log('注意: このスクリプトは基本的なSVGファイルのみを生成します。');
console.log('実際のPNGファイル生成には、適切な画像変換ツールが必要です。');

// 各サイズのSVGファイルを生成（実際の環境ではPNGに変換）
sizes.forEach(size => {
  const svgContent = generateBasicIcon(size);
  const filename = `app-icon-${size}.svg`;
  const filepath = path.join(iconsDir, filename);
  
  fs.writeFileSync(filepath, svgContent);
  console.log(`Generated: ${filename}`);
});

// マスカブルアイコン用（Android Adaptive Icons対応）
const maskableIcon = generateBasicIcon(512);
const maskableFilename = 'app-icon-512-maskable.svg';
const maskableFilepath = path.join(iconsDir, maskableFilename);
fs.writeFileSync(maskableFilepath, maskableIcon);
console.log(`Generated: ${maskableFilename}`);

console.log('\n生成完了！');
console.log('実際のPNGファイルを生成するには、以下のツールを使用してください:');
console.log('1. オンラインツール: https://realfavicongenerator.net/');
console.log('2. コマンドラインツール: npm install sharp を使用');
console.log('3. PWAアイコン生成ツール: https://app-manifest.firebaseapp.com/');