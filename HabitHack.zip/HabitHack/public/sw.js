// サービスワーカーのバージョン（キャッシュの更新に使用）
const CACHE_VERSION = "v8";
const CACHE_NAME = `task-gacha-app-${CACHE_VERSION}`;

// キャッシュするファイル
const urlsToCache = ["/", "/index.html", "/manifest.json", "/assets/index.css", "/assets/index.js"];

// インストール時にキャッシュする
self.addEventListener("install", event => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then(cache => {
        return cache.addAll(urlsToCache);
      })
      .then(() => self.skipWaiting())
  );
});

// 古いキャッシュを削除する
self.addEventListener("activate", event => {
  event.waitUntil(
    caches
      .keys()
      .then(keyList => {
        return Promise.all(
          keyList.map(key => {
            if (key !== CACHE_NAME) {
              return caches.delete(key);
            }
          })
        );
      })
      .then(() => self.clients.claim())
  );
});

// フェッチリクエストをインターセプトしてキャッシュから返す
self.addEventListener("fetch", event => {
  // 外部リソースへのリクエストはブラウザのデフォルト処理に任せる
  const url = event.request.url;
  if (
    url.includes("googleapis.com") ||
    url.includes("gstatic.com") ||
    url.includes("cloudflare.com") ||
    url.includes("cdnjs.cloudflare.com") ||
    url.includes("fonts.googleapis.com")
  ) {
    // 何もしない（ブラウザのデフォルト処理に任せる）
    return;
  }

  // API リクエストの場合はネットワークを優先
  if (url.includes("/api/")) {
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match(event.request);
      })
    );
    return;
  }

  // 静的アセットの場合はキャッシュを優先し、ネットワークからの取得をバックグラウンドで行う
  event.respondWith(
    caches.match(event.request).then(response => {
      if (response) {
        // キャッシュがあれば返す
        // バックグラウンドでネットワークリクエストを行い、キャッシュを更新
        fetch(event.request)
          .then(networkResponse => {
            if (networkResponse && networkResponse.ok) {
              caches.open(CACHE_NAME).then(cache => {
                cache.put(event.request, networkResponse.clone());
              });
            }
          })
          .catch(error => {
            console.log("バックグラウンド更新中のエラー:", error);
          });
        return response;
      }

      // キャッシュにない場合はネットワークから取得
      return fetch(event.request)
        .then(response => {
          // 本番環境でクロスオリジンリクエストの場合はキャッシュしない
          if (
            !response ||
            response.status !== 200 ||
            (response.type !== "basic" && !url.includes(self.location.origin))
          ) {
            return response;
          }

          // レスポンスをキャッシュに保存
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseToCache);
          });

          return response;
        })
        .catch(error => {
          console.log("ネットワークリクエスト中のエラー:", error);
          // オフライン時に特定のページへフォールバックする場合はここに追加
          return caches
            .match("/") // ルートページをフォールバックとして使用
            .then(response => {
              return (
                response ||
                new Response("ネットワークに接続できません", {
                  status: 503,
                  statusText: "Service Unavailable",
                  headers: new Headers({
                    "Content-Type": "text/plain",
                  }),
                })
              );
            });
        });
    })
  );
});
