export default {
  "*.{ts,tsx}": "eslint --fix",
  "*": "prettier --write"
};