import { commonConfig, Config } from './common';

/**
 * 開発環境用設定
 * 共通設定をベースに開発環境固有の設定を上書き
 */
export const developmentConfig: Config = {
  ...commonConfig,
  app: {
    ...commonConfig.app,
    isDev: true,
  },
  jwt: {
    ...commonConfig.jwt,
    cookieOptions: {
      ...commonConfig.jwt.cookieOptions,
      secure: false, // 開発環境ではHTTPでもアクセス可能に
      sameSite: 'lax',
    },
  },
  cors: {
    ...commonConfig.cors,
    // 開発環境では全てのオリジンを許可
    origins: ['*'],
  },
  security: {
    contentSecurityPolicy: {
      directives: {
        // 開発環境ではCSPを緩和
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://cdnjs.cloudflare.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'https://cdnjs.cloudflare.com'],
        formAction: ["'self'"],
        frameAncestors: ["'self'"],
      },
    },
  },
};