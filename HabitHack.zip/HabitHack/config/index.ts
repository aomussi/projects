import dotenvFlow from 'dotenv-flow';
import { developmentConfig } from './development';
import { productionConfig } from './production';
import { Config } from './common';

// 環境変数の読み込み
dotenvFlow.config({
  node_env: process.env.NODE_ENV || 'development',
  default_node_env: 'development',
  silent: false,
});

// 開発時のデバッグ用
console.log(`Loading configuration for NODE_ENV="${process.env.NODE_ENV || 'development'}"`);
console.log(`JWT_SECRET is ${process.env.JWT_SECRET ? 'set' : 'not set'}`);
console.log(`Using: ${process.env.NODE_ENV === 'production' ? 'production' : 'development'} configuration`);

/**
 * 環境に応じた設定を取得
 */
function getConfig(): Config {
  const nodeEnv = process.env.NODE_ENV || 'development';
  
  // 環境に応じた設定を選択
  switch (nodeEnv) {
    case 'production':
      return productionConfig;
    case 'development':
    default:
      return developmentConfig;
  }
}

// 設定をエクスポート
export const config = getConfig();

// 型定義をエクスポート
export type { Config } from './common';