/**
 * 共通設定
 * すべての環境で共通の設定値を定義
 * 環境変数から値を取得する場合はデフォルト値を設定する
 */

export const commonConfig = {
  app: {
    port: parseInt(process.env.PORT || '5000', 10),
    isDev: process.env.NODE_ENV !== 'production',
  },
  jwt: {
    secret: process.env.JWT_SECRET || 'default-jwt-secret-key-for-development-only',
    expiresIn: '7d',
    cookieOptions: {
      httpOnly: true,
      secure: false,
      sameSite: 'lax' as 'lax' | 'strict' | 'none',
    },
  },
  cors: {
    // CORS設定は環境ごとに上書き
    origins: ['http://localhost:5000'],
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
  },
  security: {
    // Helmet設定は環境ごとに上書き
    contentSecurityPolicy: {
      directives: {
        // デフォルトの CSP 設定
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://cdnjs.cloudflare.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'https://cdnjs.cloudflare.com'],
        formAction: ["'self'"],
        frameAncestors: ["'self'"],
        baseUri: ["'self'"],
        objectSrc: ["'none'"],
        scriptSrcAttr: ["'none'"],
      },
    },
  },
  db: {
    // SQLiteのデフォルトパス
    sqlitePath: process.env.SQLITE_PATH || './data/sqlite.db',
  },
  session: {
    // セッション設定
    secret: process.env.SESSION_SECRET || 'default-session-secret-for-development-only',
    cookieMaxAge: 7 * 24 * 60 * 60 * 1000, // 7日間（ミリ秒）
  },
};

export type Config = typeof commonConfig;