import { commonConfig, Config } from './common';

/**
 * 本番環境用設定
 * 共通設定をベースに本番環境固有の設定を上書き
 */
export const productionConfig: Config = {
  ...commonConfig,
  app: {
    ...commonConfig.app,
    isDev: false,
  },
  jwt: {
    ...commonConfig.jwt,
    // 本番環境では警告のみ表示し、デフォルト値を使用（NODE_ENV=productionのときのみ警告）
    secret: process.env.JWT_SECRET || (() => {
      if (process.env.NODE_ENV === 'production') {
        console.warn('WARNING: JWT_SECRET not set in production environment. Using default (insecure) value.');
      }
      return commonConfig.jwt.secret;
    })(),
    cookieOptions: {
      ...commonConfig.jwt.cookieOptions,
      secure: true, // 本番環境ではHTTPSのみ
      sameSite: 'strict',
    },
  },
  cors: {
    ...commonConfig.cors,
    // 本番環境では特定のオリジンのみ許可
    origins: process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(',')
      : ['https://your-production-domain.com'],
  },
  security: {
    contentSecurityPolicy: {
      directives: {
        // 本番環境でも外部リソースを許可するように設定
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://cdnjs.cloudflare.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'https://cdnjs.cloudflare.com'],
        formAction: ["'self'"],
        frameAncestors: ["'self'"],
        baseUri: ["'self'"],
        objectSrc: ["'none'"],
        scriptSrcAttr: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
  },
  session: {
    ...commonConfig.session,
    // 本番環境では警告を表示し、デフォルト値を使用（NODE_ENV=productionのときのみ警告）
    secret: process.env.SESSION_SECRET || (() => {
      if (process.env.NODE_ENV === 'production') {
        console.warn('WARNING: SESSION_SECRET not set in production environment. Using default (insecure) value.');
      }
      return commonConfig.session.secret;
    })(),
  },
};