import express, { type Request, Response, NextFunction } from "express";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import passport from "passport";
import cookieParser from "cookie-parser";
import { setupPassport } from "./auth";
import helmet from "helmet";
import cors from "cors";
import { maskSensitiveData } from "./validators";
import { createServer } from "http";
import { config } from "../config";

// ルーターのインポート
import authRouter from "./routes/auth";
import tasksRouter from "./routes/tasks";
import gachaRouter from "./routes/gacha";

// 環境変数の必須チェックはconfigモジュールで行われるため、ここでは不要

const app = express();

app.set("trust proxy", 1); // 本番で secure cookie を正しく扱うため

// CORS設定を環境に応じて適用
app.use(
  cors({
    origin: config.cors.origins,
    credentials: config.cors.credentials,
    methods: config.cors.methods,
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

// Helmet設定を環境に応じて適用
app.use(
  helmet({
    contentSecurityPolicy: config.security.contentSecurityPolicy,
    crossOriginEmbedderPolicy: false,
    xssFilter: true,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(process.cwd(), "public")));
app.use(cookieParser());
app.use(passport.initialize());

// Passportの設定をセットアップ
setupPassport();

// 各ルーターをマウント
app.use("/api/auth", authRouter);
app.use("/api/tasks", tasksRouter);
app.use("/api/gacha", gachaRouter);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        // 機密情報をマスク
        const maskedResponse = maskSensitiveData(capturedJsonResponse);
        logLine += ` :: ${JSON.stringify(maskedResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // HTTPサーバーの作成
  const httpServer = createServer(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (config.app.isDev) {
    console.log('Running in development mode, setting up Vite HMR');
    await setupVite(app, httpServer);
  } else {
    console.log('Running in production mode, serving static files');
    serveStatic(app);
  }

  // アプリケーションを設定されたポートでサービス
  // これはAPIとクライアントの両方を提供します
  const port = config.app.port;
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`serving on port ${port} (${config.app.isDev ? 'development' : 'production'} mode)`);
    }
  );
})();
