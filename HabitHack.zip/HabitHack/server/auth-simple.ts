import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { Request, Response, NextFunction } from "express";
import { User } from "../drizzle/schema";
import { storage } from "./storage";

// JWT設定は config から取得
import { config } from "../config";

// パスポートの設定
export function setupPassport() {
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "ユーザー名またはパスワードが違います" });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
          return done(null, false, { message: "ユーザー名またはパスワードが違います" });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );
}

// ログイン処理
export async function login(req: Request, res: Response) {
  passport.authenticate("local", { session: false }, (err: Error, user: User, info: any) => {
    if (err) {
      console.error("Authentication error:", err);
      return res.status(500).json({ message: "サーバーエラーが発生しました" });
    }

    if (!user) {
      return res.status(401).json({ message: info.message || "認証に失敗しました" });
    }

    try {
      // JWTを生成（シンプルに署名のみ）
      const payload = { id: user.id, username: user.username };
      const token = jwt.sign(payload, config.jwt.secret);
      
      // HTTPオンリークッキーにトークンを設定
      res.cookie("token", token, {
        httpOnly: config.jwt.cookieOptions.httpOnly,
        secure: config.jwt.cookieOptions.secure,
        sameSite: config.jwt.cookieOptions.sameSite,
        maxAge: config.session.cookieMaxAge,
      });

      // パスワードを除いたユーザー情報を返す
      const { password, ...userInfo } = user;
      res.json(userInfo);
    } catch (error) {
      console.error("JWT generation error:", error);
      res.status(500).json({ message: "サーバーエラーが発生しました" });
    }
  })(req, res);
}

// JWTを検証するミドルウェア
export function authenticateJWT(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies.token;
  if (!token) {
    return res.status(401).json({ message: "認証が必要です" });
  }

  try {
    // トークンを検証
    const decoded = jwt.verify(token, config.jwt.secret) as { id: number };
    req.userId = decoded.id;
    next();
  } catch (error) {
    console.error("JWT verification error:", error);
    return res.status(401).json({ message: "無効なトークンです" });
  }
}

// ログアウト処理
export function logout(req: Request, res: Response) {
  res.clearCookie("token", {
    httpOnly: config.jwt.cookieOptions.httpOnly,
    secure: config.jwt.cookieOptions.secure,
    sameSite: config.jwt.cookieOptions.sameSite
  });
  res.json({ message: "ログアウトしました" });
}

// パスワードハッシュ化
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

// Express Requestインターフェース拡張
declare global {
  namespace Express {
    interface Request {
      userId?: number;
    }
  }
}