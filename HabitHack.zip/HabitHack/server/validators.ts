import { z } from 'zod';
import {
  insertUserSchema,
  insertTaskSchema,
  insertTaskGroupSchema,
  insertRewardSchema,
  insertGachaHistorySchema,
  insertUserStatsSchema,
  insertAchievementSchema
} from '@shared/schema';

// ユーザー関連
export const loginSchema = z.object({
  username: z.string().min(1, 'ユーザー名は必須です'),
  password: z.string().min(1, 'パスワードは必須です'),
});

export const userCreateSchema = insertUserSchema;
export const userUpdateSchema = insertUserSchema.partial();

// タスク関連
export const taskCreateSchema = insertTaskSchema;
export const taskUpdateSchema = insertTaskSchema.partial();
export const taskQuerySchema = z.object({
  date: z.string().optional(),
});

// タスクグループ関連
export const taskGroupCreateSchema = insertTaskGroupSchema;
export const taskGroupUpdateSchema = insertTaskGroupSchema.partial();

// 報酬関連
export const rewardCreateSchema = insertRewardSchema;
export const rewardUpdateSchema = insertRewardSchema.partial();

// ガチャ履歴関連
export const gachaHistoryCreateSchema = insertGachaHistorySchema;
export const gachaHistoryQuerySchema = z.object({
  limit: z.string().regex(/^\d+$/).transform(Number).optional(),
});

// ユーザー統計関連
export const userStatsCreateSchema = insertUserStatsSchema;
export const userStatsUpdateSchema = insertUserStatsSchema.partial();

// 実績関連
export const achievementCreateSchema = insertAchievementSchema;
export const achievementUpdateSchema = insertAchievementSchema.partial();

// IDパラメータのバリデーション
export const idParamSchema = z.object({
  id: z.string().regex(/^\d+$/).transform(Number),
});

// 共通レスポンスのマスク処理用ユーティリティ
export function maskSensitiveData(data: any): any {
  if (!data) return data;
  
  // オブジェクトの場合
  if (typeof data === 'object' && data !== null) {
    if (Array.isArray(data)) {
      // 配列の場合は各要素を再帰的に処理
      return data.map(item => maskSensitiveData(item));
    } else {
      // オブジェクトの場合はプロパティを処理
      const maskedData: Record<string, any> = {};
      for (const [key, value] of Object.entries(data)) {
        // パスワードなどの機密情報をマスク
        if (key === 'password') {
          maskedData[key] = '[MASKED]';
        } else {
          maskedData[key] = maskSensitiveData(value);
        }
      }
      return maskedData;
    }
  }
  
  return data;
}