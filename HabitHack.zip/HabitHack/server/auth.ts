import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { Request, Response, NextFunction } from "express";
import { User } from "@shared/schema";
import { storage } from "./storage";

// JWT設定は config から取得
import { config } from "../config";

// パスポートの設定
export function setupPassport() {
  // ユーザー名/パスワードの検証戦略
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // ユーザー名でユーザーを検索
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "ユーザー名またはパスワードが違います" });
        }

        // パスワードを検証
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
          return done(null, false, { message: "ユーザー名またはパスワードが違います" });
        }

        // 認証成功
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );
}

// JWTの生成
export function generateToken(user: User): string {
  const payload = {
    id: user.id,
    username: user.username,
  };

  console.log("トークン生成 - ユーザー:", user.username);
  
  // JWTの署名 - string型で明示的に型を指定
  return jwt.sign(
    payload, 
    config.jwt.secret as string, 
    { expiresIn: config.jwt.expiresIn }
  );
}

// JWTを検証するミドルウェア
export function authenticateJWT(req: Request, res: Response, next: NextFunction) {
  // クッキーからトークンを取得
  const token = req.cookies.token;
  console.log("認証チェック - トークン:", token ? "存在します" : "存在しません");

  if (!token) {
    return res.status(401).json({ message: "認証が必要です" });
  }

  try {
    // トークンを検証 - any型で型エラーを回避
    const decoded = jwt.verify(token, config.jwt.secret as string) as { id: number; username: string };
    console.log("トークン検証成功:", decoded.username);
    
    // リクエストオブジェクトにユーザーIDを追加
    req.userId = decoded.id;
    next();
  } catch (error) {
    console.error("トークン検証エラー:", error);
    return res.status(401).json({ message: "無効なトークンです" });
  }
}

// ログイン処理
export async function login(req: Request, res: Response) {
  return new Promise<void>((resolve, reject) => {
    passport.authenticate("local", { session: false }, async (err: Error, user: User, info: any) => {
      if (err) {
        res.status(500).json({ message: "サーバーエラーが発生しました" });
        return reject(err);
      }

      if (!user) {
        res.status(401).json({ message: info.message || "認証に失敗しました" });
        return resolve();
      }

      try {
        // JWTトークンを生成
        const token = generateToken(user);

        // HTTPオンリークッキーとしてトークンを設定
        res.cookie("token", token, {
          httpOnly: config.jwt.cookieOptions.httpOnly,
          secure: config.jwt.cookieOptions.secure,
          sameSite: config.jwt.cookieOptions.sameSite,
          maxAge: config.session.cookieMaxAge, // 有効期限
          path: '/' // 全てのパスで利用可能にする
        });
        
        console.log("クッキー設定完了 - 認証情報:", {
          token: token ? "設定済み" : "未設定",
          httpOnly: config.jwt.cookieOptions.httpOnly,
          secure: config.jwt.cookieOptions.secure,
          sameSite: config.jwt.cookieOptions.sameSite,
          maxAge: config.session.cookieMaxAge
        });

        // ユーザー情報（パスワードを除く）を返す
        const { password, ...userInfo } = user;
        res.json(userInfo);
        resolve();
      } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ message: "サーバーエラーが発生しました" });
        reject(error);
      }
    })(req, res);
  });
}

// ログアウト処理
export function logout(req: Request, res: Response) {
  // クッキーを削除（設定と同じオプションでクリアする必要がある）
  res.clearCookie("token", {
    httpOnly: config.jwt.cookieOptions.httpOnly,
    secure: config.jwt.cookieOptions.secure,
    sameSite: config.jwt.cookieOptions.sameSite,
    path: '/' // 全てのパスで利用可能にする
  });
  console.log("ログアウト - クッキー削除完了");
  res.json({ message: "ログアウトしました" });
}

// パスワードのハッシュ化（12ソルトラウンド）
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

// Express Requestインターフェースの拡張
declare global {
  namespace Express {
    interface Request {
      userId?: number;
    }
  }
}