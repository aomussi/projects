import { 
  type User, type InsertUser, 
  type Task, type InsertTask,
  type TaskGroup, type InsertTaskGroup,
  type Reward, type InsertReward,
  type Achievement, type InsertAchievement,
  type GachaHistory, type InsertGachaHistory,
  type UserStats, type InsertUserStats,
  users, tasks, taskGroups, rewards, achievements, gachaHistory, userStats
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }

  // Tasks
  async getTasks(userId: number, date?: string): Promise<Task[]> {
    if (date) {
      return await db.select().from(tasks).where(and(eq(tasks.userId, userId), eq(tasks.date, date)));
    }
    return await db.select().from(tasks).where(eq(tasks.userId, userId));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set(task)
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask || undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Task Groups
  async getTaskGroups(userId: number): Promise<TaskGroup[]> {
    return await db.select().from(taskGroups).where(eq(taskGroups.userId, userId));
  }

  async getTaskGroup(id: number): Promise<TaskGroup | undefined> {
    const [group] = await db.select().from(taskGroups).where(eq(taskGroups.id, id));
    return group || undefined;
  }

  async createTaskGroup(group: InsertTaskGroup): Promise<TaskGroup> {
    const [newGroup] = await db
      .insert(taskGroups)
      .values(group)
      .returning();
    return newGroup;
  }

  async updateTaskGroup(id: number, group: Partial<InsertTaskGroup>): Promise<TaskGroup | undefined> {
    const [updatedGroup] = await db
      .update(taskGroups)
      .set(group)
      .where(eq(taskGroups.id, id))
      .returning();
    return updatedGroup || undefined;
  }

  async deleteTaskGroup(id: number): Promise<boolean> {
    const result = await db.delete(taskGroups).where(eq(taskGroups.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Rewards
  async getRewards(userId: number): Promise<Reward[]> {
    return await db.select().from(rewards).where(eq(rewards.userId, userId));
  }

  async getReward(id: number): Promise<Reward | undefined> {
    const [reward] = await db.select().from(rewards).where(eq(rewards.id, id));
    return reward || undefined;
  }

  async createReward(reward: InsertReward): Promise<Reward> {
    const [newReward] = await db
      .insert(rewards)
      .values(reward)
      .returning();
    return newReward;
  }

  async updateReward(id: number, reward: Partial<InsertReward>): Promise<Reward | undefined> {
    const [updatedReward] = await db
      .update(rewards)
      .set(reward)
      .where(eq(rewards.id, id))
      .returning();
    return updatedReward || undefined;
  }

  async deleteReward(id: number): Promise<boolean> {
    const result = await db.delete(rewards).where(eq(rewards.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Achievements
  async getAchievements(userId: number): Promise<Achievement[]> {
    return await db.select().from(achievements).where(eq(achievements.userId, userId));
  }

  async getAchievement(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db.select().from(achievements).where(eq(achievements.id, id));
    return achievement || undefined;
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    return newAchievement;
  }

  async updateAchievement(id: number, achievement: Partial<InsertAchievement>): Promise<Achievement | undefined> {
    const [updatedAchievement] = await db
      .update(achievements)
      .set(achievement)
      .where(eq(achievements.id, id))
      .returning();
    return updatedAchievement || undefined;
  }

  // Gacha History
  async getGachaHistory(userId: number): Promise<GachaHistory[]> {
    return await db.select().from(gachaHistory).where(eq(gachaHistory.userId, userId));
  }

  async createGachaHistory(history: InsertGachaHistory): Promise<GachaHistory> {
    const [newHistory] = await db
      .insert(gachaHistory)
      .values(history)
      .returning();
    return newHistory;
  }

  // User Stats
  async getUserStats(userId: number): Promise<UserStats | undefined> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    return stats || undefined;
  }

  async createUserStats(stats: InsertUserStats): Promise<UserStats> {
    const [newStats] = await db
      .insert(userStats)
      .values(stats)
      .returning();
    return newStats;
  }

  async updateUserStats(userId: number, stats: Partial<InsertUserStats>): Promise<UserStats | undefined> {
    const [updatedStats] = await db
      .update(userStats)
      .set(stats)
      .where(eq(userStats.userId, userId))
      .returning();
    return updatedStats || undefined;
  }
}