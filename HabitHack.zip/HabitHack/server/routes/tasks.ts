import express, { Request, Response } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { authenticateJWT } from "../auth";
import {
  taskCreateSchema,
  taskUpdateSchema,
  taskQuerySchema,
  taskGroupCreateSchema,
  taskGroupUpdateSchema,
  idParamSchema
} from "../validators";

const router = express.Router();

// すべてのエンドポイントにJWT認証を適用
router.use(authenticateJWT);

// タスク関連のルート
// タスク一覧を取得
router.get("/", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const query = taskQuerySchema.parse(req.query);
    const tasks = await storage.getTasks(userId, query.date);
    res.json(tasks);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なクエリパラメータ", errors: error.errors });
    } else {
      console.error("Get tasks error:", error);
      res.status(500).json({ message: "タスクの取得に失敗しました" });
    }
  }
});

// 新しいタスクを作成
router.post("/", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const taskData = { ...req.body, userId };
    const validatedData = taskCreateSchema.parse(taskData);
    
    const task = await storage.createTask(validatedData);
    res.status(201).json(task);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なタスクデータ", errors: error.errors });
    } else {
      console.error("Create task error:", error);
      res.status(500).json({ message: "タスクの作成に失敗しました" });
    }
  }
});

// タスクを更新
router.put("/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // タスクの所有権をチェック
    const existingTask = await storage.getTask(id);
    if (!existingTask) {
      return res.status(404).json({ message: "タスクが見つかりません" });
    }
    if (existingTask.userId !== userId) {
      return res.status(403).json({ message: "このタスクを編集する権限がありません" });
    }
    
    const validatedData = taskUpdateSchema.parse(req.body);
    const updatedTask = await storage.updateTask(id, validatedData);
    
    if (!updatedTask) {
      return res.status(404).json({ message: "タスクが見つかりません" });
    }
    
    res.json(updatedTask);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なタスクデータ", errors: error.errors });
    } else {
      console.error("Update task error:", error);
      res.status(500).json({ message: "タスクの更新に失敗しました" });
    }
  }
});

// タスクを削除
router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // タスクの所有権をチェック
    const existingTask = await storage.getTask(id);
    if (!existingTask) {
      return res.status(404).json({ message: "タスクが見つかりません" });
    }
    if (existingTask.userId !== userId) {
      return res.status(403).json({ message: "このタスクを削除する権限がありません" });
    }
    
    const result = await storage.deleteTask(id);
    if (!result) {
      return res.status(404).json({ message: "タスクが見つかりません" });
    }
    
    res.status(204).end();
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なIDパラメータ", errors: error.errors });
    } else {
      console.error("Delete task error:", error);
      res.status(500).json({ message: "タスクの削除に失敗しました" });
    }
  }
});

// タスクグループ関連のルート
// タスクグループ一覧を取得
router.get("/groups", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const taskGroups = await storage.getTaskGroups(userId);
    res.json(taskGroups);
  } catch (error) {
    console.error("Get task groups error:", error);
    res.status(500).json({ message: "タスクグループの取得に失敗しました" });
  }
});

// 新しいタスクグループを作成
router.post("/groups", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const groupData = { ...req.body, userId };
    const validatedData = taskGroupCreateSchema.parse(groupData);
    
    const taskGroup = await storage.createTaskGroup(validatedData);
    res.status(201).json(taskGroup);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なタスクグループデータ", errors: error.errors });
    } else {
      console.error("Create task group error:", error);
      res.status(500).json({ message: "タスクグループの作成に失敗しました" });
    }
  }
});

// タスクグループを更新
router.put("/groups/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // タスクグループの所有権をチェック
    const existingGroup = await storage.getTaskGroup(id);
    if (!existingGroup) {
      return res.status(404).json({ message: "タスクグループが見つかりません" });
    }
    if (existingGroup.userId !== userId) {
      return res.status(403).json({ message: "このタスクグループを編集する権限がありません" });
    }
    
    const validatedData = taskGroupUpdateSchema.parse(req.body);
    const updatedGroup = await storage.updateTaskGroup(id, validatedData);
    
    if (!updatedGroup) {
      return res.status(404).json({ message: "タスクグループが見つかりません" });
    }
    
    res.json(updatedGroup);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なタスクグループデータ", errors: error.errors });
    } else {
      console.error("Update task group error:", error);
      res.status(500).json({ message: "タスクグループの更新に失敗しました" });
    }
  }
});

// タスクグループを削除
router.delete("/groups/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // タスクグループの所有権をチェック
    const existingGroup = await storage.getTaskGroup(id);
    if (!existingGroup) {
      return res.status(404).json({ message: "タスクグループが見つかりません" });
    }
    if (existingGroup.userId !== userId) {
      return res.status(403).json({ message: "このタスクグループを削除する権限がありません" });
    }
    
    const result = await storage.deleteTaskGroup(id);
    if (!result) {
      return res.status(404).json({ message: "タスクグループが見つかりません" });
    }
    
    res.status(204).end();
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なIDパラメータ", errors: error.errors });
    } else {
      console.error("Delete task group error:", error);
      res.status(500).json({ message: "タスクグループの削除に失敗しました" });
    }
  }
});

export default router;