import express, { Request, Response } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { login, logout, hashPassword, authenticateJWT } from "../auth";
import { loginSchema, userCreateSchema } from "../validators";

const router = express.Router();

// ユーザー登録
router.post("/register", async (req: Request, res: Response) => {
  try {
    // バリデーション
    const validBody = loginSchema.parse(req.body);
    
    // 既存のユーザー名をチェック
    const existingUser = await storage.getUserByUsername(validBody.username);
    if (existingUser) {
      return res.status(400).json({ message: "このユーザー名は既に使用されています" });
    }

    // パスワードをハッシュ化
    const hashedPassword = await hashPassword(validBody.password);
    
    // データを検証
    const userData = { ...validBody, password: hashedPassword };
    const validatedData = userCreateSchema.parse(userData);
    
    // ユーザーを作成
    const user = await storage.createUser(validatedData);
    
    // パスワードを除いたユーザー情報を返す
    const { password, ...userInfo } = user;
    
    // ステータスコードを201に設定（リソース作成成功）
    res.status(201);
    
    // ログイン処理（レスポンスの送信を含む）
    await login(req, res);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なユーザーデータ", errors: error.errors });
    } else {
      console.error("User registration error:", error);
      res.status(500).json({ message: "ユーザー登録に失敗しました" });
    }
  }
});

// ログイン
router.post("/login", login);

// ログアウト
router.post("/logout", logout);

// ユーザー情報を取得するエンドポイント（認証済みユーザー向け）
router.get("/user", authenticateJWT, async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "ユーザーが見つかりません" });
    }
    
    // パスワードを除いたユーザー情報を返す
    const { password, ...userInfo } = user;
    res.json(userInfo);
  } catch (error) {
    res.status(500).json({ message: "ユーザー情報の取得に失敗しました" });
  }
});

export default router;