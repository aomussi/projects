import express, { Request, Response } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { authenticateJWT } from "../auth";
import {
  rewardCreateSchema,
  rewardUpdateSchema,
  gachaHistoryCreateSchema,
  gachaHistoryQuerySchema,
  userStatsUpdateSchema,
  achievementUpdateSchema,
  idParamSchema
} from "../validators";

const router = express.Router();

// すべてのエンドポイントにJWT認証を適用
router.use(authenticateJWT);

// 報酬関連のルート
// 報酬一覧を取得
router.get("/rewards", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const rewards = await storage.getRewards(userId);
    res.json(rewards);
  } catch (error) {
    console.error("Get rewards error:", error);
    res.status(500).json({ message: "報酬の取得に失敗しました" });
  }
});

// 新しい報酬を作成
router.post("/rewards", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const rewardData = { ...req.body, userId };
    const validatedData = rewardCreateSchema.parse(rewardData);
    
    const reward = await storage.createReward(validatedData);
    res.status(201).json(reward);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効な報酬データ", errors: error.errors });
    } else {
      console.error("Create reward error:", error);
      res.status(500).json({ message: "報酬の作成に失敗しました" });
    }
  }
});

// 報酬を更新
router.put("/rewards/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // 報酬の所有権をチェック
    const existingReward = await storage.getReward(id);
    if (!existingReward) {
      return res.status(404).json({ message: "報酬が見つかりません" });
    }
    if (existingReward.userId !== userId) {
      return res.status(403).json({ message: "この報酬を編集する権限がありません" });
    }
    
    const validatedData = rewardUpdateSchema.parse(req.body);
    const updatedReward = await storage.updateReward(id, validatedData);
    
    if (!updatedReward) {
      return res.status(404).json({ message: "報酬が見つかりません" });
    }
    
    res.json(updatedReward);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効な報酬データ", errors: error.errors });
    } else {
      console.error("Update reward error:", error);
      res.status(500).json({ message: "報酬の更新に失敗しました" });
    }
  }
});

// 報酬を削除
router.delete("/rewards/:id", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const { id } = idParamSchema.parse(req.params);
    
    // 報酬の所有権をチェック
    const existingReward = await storage.getReward(id);
    if (!existingReward) {
      return res.status(404).json({ message: "報酬が見つかりません" });
    }
    if (existingReward.userId !== userId) {
      return res.status(403).json({ message: "この報酬を削除する権限がありません" });
    }
    
    const result = await storage.deleteReward(id);
    if (!result) {
      return res.status(404).json({ message: "報酬が見つかりません" });
    }
    
    res.status(204).end();
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なIDパラメータ", errors: error.errors });
    } else {
      console.error("Delete reward error:", error);
      res.status(500).json({ message: "報酬の削除に失敗しました" });
    }
  }
});

// ガチャ履歴関連のルート
// ガチャ履歴を取得
router.get("/history", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const gachaHistory = await storage.getGachaHistory(userId);
    res.json(gachaHistory);
  } catch (error) {
    console.error("Get gacha history error:", error);
    res.status(500).json({ message: "ガチャ履歴の取得に失敗しました" });
  }
});

// 新しいガチャ履歴を作成
router.post("/history", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const historyData = { ...req.body, userId };
    const validatedData = gachaHistoryCreateSchema.parse(historyData);
    
    const history = await storage.createGachaHistory(validatedData);
    res.status(201).json(history);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なガチャ履歴データ", errors: error.errors });
    } else {
      console.error("Create gacha history error:", error);
      res.status(500).json({ message: "ガチャ履歴の作成に失敗しました" });
    }
  }
});

// ユーザー統計関連のルート
// ユーザー統計を取得
router.get("/user-stats", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const userStats = await storage.getUserStats(userId);
    
    // ユーザー統計が存在しない場合は作成
    if (!userStats) {
      // デフォルト値を設定
      const defaultStats = {
        userId,
        streak: 0,
        gachaThreshold: 70, // デフォルト閾値: 70%
        weeklyData: "[]", // 空の配列をJSON文字列として
        gachaDay: 0, // デフォルト: 日曜日
        lastGachaDayChange: null,
        showGachaDayChangeWarning: true,
        lastThresholdChange: null,
        showThresholdChangeWarning: true,
        gachaCount: 1, // デフォルト: 1回
        maxGachaCount: 1, // デフォルト: 最大1回
        lastGachaCountChange: null,
        showGachaCountChangeWarning: true,
        gachaMode: "fixed", // デフォルト: 固定値モード
        lastGachaModeChange: null,
        showGachaModeChangeWarning: true,
        maxDiceValue: 6, // デフォルト: 6面ダイス
        hasDiceRolled: false, 
        lastDiceRoll: null
      };
      
      const newStats = await storage.createUserStats(defaultStats);
      return res.json(newStats);
    }
    
    res.json(userStats);
  } catch (error) {
    console.error("Get user stats error:", error);
    res.status(500).json({ message: "ユーザー統計の取得に失敗しました" });
  }
});

// ユーザー統計を更新
router.put("/user-stats", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }
    
    const validatedData = userStatsUpdateSchema.parse(req.body);
    const updatedStats = await storage.updateUserStats(userId, validatedData);
    
    if (!updatedStats) {
      return res.status(404).json({ message: "ユーザー統計が見つかりません" });
    }
    
    res.json(updatedStats);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: "無効なユーザー統計データ", errors: error.errors });
    } else {
      console.error("Update user stats error:", error);
      res.status(500).json({ message: "ユーザー統計の更新に失敗しました" });
    }
  }
});

// 実績関連のルート
// 実績一覧を取得
router.get("/achievements", async (req: Request, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "認証が必要です" });
    }

    const achievements = await storage.getAchievements(userId);
    res.json(achievements);
  } catch (error) {
    console.error("Get achievements error:", error);
    res.status(500).json({ message: "実績の取得に失敗しました" });
  }
});

export default router;