import Database from "better-sqlite3";
import path from "path";
import fs from "fs";
import { config } from "../config";

// データベースパスを設定から取得
const dbFilePath = config.db.sqlitePath;
const dbDirectory = path.dirname(dbFilePath);

// データベースディレクトリが存在することを確認
if (!fs.existsSync(dbDirectory)) {
  fs.mkdirSync(dbDirectory, { recursive: true });
}

// SQLiteデータベースインスタンスを作成・エクスポート
const sqliteDb = new Database(dbFilePath);

// テーブルはDrizzleのマイグレーションで作成されるため、
// 手動でのテーブル作成は不要になりました

// マイグレーション実行用に関数定義だけ残しておく
function initDatabase() {
  // マイグレーションによってテーブルが作成されるため、ここでの操作は不要
  console.log('SQLite database initialized, tables will be created by migrations');
}

// Initialize the database
initDatabase();

// Export the database instance
export default sqliteDb;