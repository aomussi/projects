import { drizzle } from "drizzle-orm/better-sqlite3";
import { eq, and } from "drizzle-orm";
import { 
  users, tasks, taskGroups, rewards, achievements, gachaHistory, userStats,
  type User, type InsertUser, 
  type Task, type InsertTask,
  type TaskGroup, type InsertTaskGroup,
  type Reward, type InsertReward,
  type Achievement, type InsertAchievement,
  type GachaHistory, type InsertGachaHistory,
  type UserStats, type InsertUserStats
} from "../drizzle/schema";
import { IStorage } from "./storage";
import sqliteDb from "./sqlite-db";

export class SQLiteStorage implements IStorage {
  private db;

  constructor() {
    this.db = drizzle(sqliteDb);
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return await this.db.select().from(users).where(eq(users.id, id)).get();
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return await this.db.select().from(users).where(eq(users.username, username)).get();
  }

  async createUser(user: InsertUser): Promise<User> {
    const [result] = await this.db.insert(users).values(user).returning();
    return result;
  }

  // Tasks
  async getTasks(userId: number, date?: string): Promise<Task[]> {
    if (date) {
      return await this.db.select().from(tasks).where(
        and(
          eq(tasks.userId, userId),
          eq(tasks.date, date)
        )
      ).all();
    } else {
      return await this.db.select().from(tasks).where(eq(tasks.userId, userId)).all();
    }
  }

  async getTask(id: number): Promise<Task | undefined> {
    return await this.db.select().from(tasks).where(eq(tasks.id, id)).get();
  }

  async createTask(task: InsertTask): Promise<Task> {
    // Convert RecurrencePattern to JSON string if exists
    if (task.recurrencePattern && typeof task.recurrencePattern === 'object') {
      task = {
        ...task,
        recurrencePattern: JSON.stringify(task.recurrencePattern)
      };
    }
    
    const [result] = await this.db.insert(tasks).values(task).returning();
    
    // Parse JSON fields back to objects
    if (result.recurrencePattern && typeof result.recurrencePattern === 'string') {
      try {
        const parsedPattern = JSON.parse(result.recurrencePattern);
        result.recurrencePattern = parsedPattern;
      } catch (e) {
        // If parsing fails, keep the string value
      }
    }
    
    return result;
  }

  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined> {
    // Convert RecurrencePattern to JSON string if exists
    if (task.recurrencePattern && typeof task.recurrencePattern === 'object') {
      task = {
        ...task,
        recurrencePattern: JSON.stringify(task.recurrencePattern)
      };
    }
    
    const [result] = await this.db.update(tasks)
      .set(task)
      .where(eq(tasks.id, id))
      .returning();
    
    if (!result) return undefined;
    
    // Parse JSON fields back to objects
    if (result.recurrencePattern && typeof result.recurrencePattern === 'string') {
      try {
        const parsedPattern = JSON.parse(result.recurrencePattern);
        result.recurrencePattern = parsedPattern;
      } catch (e) {
        // If parsing fails, keep the string value
      }
    }
    
    return result;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await this.db.delete(tasks).where(eq(tasks.id, id)).returning();
    return result.length > 0;
  }

  // Task Groups
  async getTaskGroups(userId: number): Promise<TaskGroup[]> {
    return await this.db.select().from(taskGroups).where(eq(taskGroups.userId, userId)).all();
  }

  async getTaskGroup(id: number): Promise<TaskGroup | undefined> {
    return await this.db.select().from(taskGroups).where(eq(taskGroups.id, id)).get();
  }

  async createTaskGroup(group: InsertTaskGroup): Promise<TaskGroup> {
    const [result] = await this.db.insert(taskGroups).values(group).returning();
    return result;
  }

  async updateTaskGroup(id: number, group: Partial<InsertTaskGroup>): Promise<TaskGroup | undefined> {
    const [result] = await this.db.update(taskGroups)
      .set(group)
      .where(eq(taskGroups.id, id))
      .returning();
    
    return result;
  }

  async deleteTaskGroup(id: number): Promise<boolean> {
    const result = await this.db.delete(taskGroups).where(eq(taskGroups.id, id)).returning();
    return result.length > 0;
  }

  // Rewards
  async getRewards(userId: number): Promise<Reward[]> {
    return await this.db.select().from(rewards).where(eq(rewards.userId, userId)).all();
  }

  async getReward(id: number): Promise<Reward | undefined> {
    return await this.db.select().from(rewards).where(eq(rewards.id, id)).get();
  }

  async createReward(reward: InsertReward): Promise<Reward> {
    const [result] = await this.db.insert(rewards).values(reward).returning();
    return result;
  }

  async updateReward(id: number, reward: Partial<InsertReward>): Promise<Reward | undefined> {
    const [result] = await this.db.update(rewards)
      .set(reward)
      .where(eq(rewards.id, id))
      .returning();
    
    return result;
  }

  async deleteReward(id: number): Promise<boolean> {
    const result = await this.db.delete(rewards).where(eq(rewards.id, id)).returning();
    return result.length > 0;
  }

  // Achievements
  async getAchievements(userId: number): Promise<Achievement[]> {
    return await this.db.select().from(achievements).where(eq(achievements.userId, userId)).all();
  }

  async getAchievement(id: number): Promise<Achievement | undefined> {
    return await this.db.select().from(achievements).where(eq(achievements.id, id)).get();
  }

  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [result] = await this.db.insert(achievements).values(achievement).returning();
    return result;
  }

  async updateAchievement(id: number, achievement: Partial<InsertAchievement>): Promise<Achievement | undefined> {
    const [result] = await this.db.update(achievements)
      .set(achievement)
      .where(eq(achievements.id, id))
      .returning();
    
    return result;
  }

  // Gacha History
  async getGachaHistory(userId: number): Promise<GachaHistory[]> {
    return await this.db.select().from(gachaHistory).where(eq(gachaHistory.userId, userId)).all();
  }

  async createGachaHistory(history: InsertGachaHistory): Promise<GachaHistory> {
    const [result] = await this.db.insert(gachaHistory).values(history).returning();
    return result;
  }

  // User Stats
  async getUserStats(userId: number): Promise<UserStats | undefined> {
    const result = await this.db.select().from(userStats).where(eq(userStats.userId, userId)).get();
    
    if (!result) return undefined;
    
    // Parse JSON fields
    if (result.weeklyData && typeof result.weeklyData === 'string') {
      try {
        const parsedData = JSON.parse(result.weeklyData);
        result.weeklyData = parsedData;
      } catch (e) {
        // If parsing fails, default to empty array as string
        result.weeklyData = "[]";
      }
    }
    
    return result;
  }

  async createUserStats(stats: InsertUserStats): Promise<UserStats> {
    // Convert weeklyData to JSON string if needed
    let statsToInsert = { ...stats };
    if (statsToInsert.weeklyData && typeof statsToInsert.weeklyData === 'object') {
      statsToInsert.weeklyData = JSON.stringify(statsToInsert.weeklyData);
    }
    
    const [result] = await this.db.insert(userStats).values(statsToInsert).returning();
    
    // Parse JSON fields back to objects
    const resultCopy = { ...result };
    if (resultCopy.weeklyData && typeof resultCopy.weeklyData === 'string') {
      try {
        resultCopy.weeklyData = JSON.parse(resultCopy.weeklyData);
      } catch (e) {
        // If parsing fails, default to empty array as string
        resultCopy.weeklyData = "[]";
      }
    }
    
    return resultCopy;
  }

  async updateUserStats(userId: number, stats: Partial<InsertUserStats>): Promise<UserStats | undefined> {
    // Convert weeklyData to JSON string if needed
    let statsToUpdate = { ...stats };
    if (statsToUpdate.weeklyData && typeof statsToUpdate.weeklyData === 'object') {
      statsToUpdate.weeklyData = JSON.stringify(statsToUpdate.weeklyData);
    }
    
    const [result] = await this.db.update(userStats)
      .set(statsToUpdate)
      .where(eq(userStats.userId, userId))
      .returning();
    
    if (!result) return undefined;
    
    // Parse JSON fields back to objects
    const resultCopy = { ...result };
    if (resultCopy.weeklyData && typeof resultCopy.weeklyData === 'string') {
      try {
        resultCopy.weeklyData = JSON.parse(resultCopy.weeklyData);
      } catch (e) {
        // If parsing fails, default to empty array as string
        resultCopy.weeklyData = "[]";
      }
    }
    
    return resultCopy;
  }
}