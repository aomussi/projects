import express, { type Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // HTTPサーバーの作成
  const httpServer = createServer(app);
  
  return httpServer;
}