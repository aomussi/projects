import { 
  type User, type InsertUser, 
  type Task, type InsertTask,
  type TaskGroup, type InsertTaskGroup,
  type Reward, type InsertReward,
  type Achievement, type InsertAchievement,
  type GachaHistory, type InsertGachaHistory,
  type UserStats, type InsertUserStats
} from "@shared/schema";
import session from "express-session";

export interface IStorage {
  sessionStore: session.Store;

  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Tasks
  getTasks(userId: number, date?: string): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;

  // Task Groups
  getTaskGroups(userId: number): Promise<TaskGroup[]>;
  getTaskGroup(id: number): Promise<TaskGroup | undefined>;
  createTaskGroup(group: InsertTaskGroup): Promise<TaskGroup>;
  updateTaskGroup(id: number, group: Partial<InsertTaskGroup>): Promise<TaskGroup | undefined>;
  deleteTaskGroup(id: number): Promise<boolean>;

  // Rewards
  getRewards(userId: number): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  updateReward(id: number, reward: Partial<InsertReward>): Promise<Reward | undefined>;
  deleteReward(id: number): Promise<boolean>;

  // Achievements
  getAchievements(userId: number): Promise<Achievement[]>;
  getAchievement(id: number): Promise<Achievement | undefined>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  updateAchievement(id: number, achievement: Partial<InsertAchievement>): Promise<Achievement | undefined>;

  // Gacha History
  getGachaHistory(userId: number): Promise<GachaHistory[]>;
  createGachaHistory(history: InsertGachaHistory): Promise<GachaHistory>;

  // User Stats
  getUserStats(userId: number): Promise<UserStats | undefined>;
  createUserStats(stats: InsertUserStats): Promise<UserStats>;
  updateUserStats(userId: number, stats: Partial<InsertUserStats>): Promise<UserStats | undefined>;
}

// Import and use the PostgreSQL implementation for account-based data synchronization
import { DatabaseStorage } from "./database-storage";
export const storage = new DatabaseStorage();
